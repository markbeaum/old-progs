draft readme for Anti Vasemagi 21/6/02

This should be used in conjunction with the tm3 readme. 

There are two programs tmvp1p.exe and tmvp2p.exe, which take the gene
frequencies from an arbitrary number of temporal samples specified in
infile, and give respectively the posterior distribution of the harmonic
mean Ne over the interval, and the joint distribution of ancestral Ne
and current Ne, assuming a model of exponential growth/decline over the
interval. 

The infile (see example) has the following format:
<number of loci> 
then for each locus
<number of samples> <number of alleles>
<time (NBB in generations NBB) of most recent sample - suggest always
set to 0.0> <allele frequencies>

Once the specified number of loci are read in, then you can have
anything at the bottom of the file. 

ostate needs to be copied to STATE as with tm3, and looks the same. 

The format of STATE is slightly different from that of tm3. In
particular, the method does not give the ancestral frequencies. 

The output you want is in the file "out". This gives
<number of lines output> <log likelihood> <Ne at the time of the oldest
sample> <Ne at the time of the most recent sample>. 
(in the case of the tmvp1p.exe program these last two columns are the
same. 

When you run the program it asks for 3 things:

maxit - Size of importance sample - this controls to some extent the acceptance
rate of the MCMC - a small number means it runs quickly but the MCMC
converges badly, a big number means that it runs slowly but the MCMC
converges quicker. There is an optimal value of maxit, which will depend
on your data. I suggest use 100 for most data sets, but it may need to
be bigger if you have a lot of loci or large sample sizes. 

thinning interval - this controls the number of updates before printing
anything out. Suggest e.g. 10.

The size of the proposal distribution of parameter updates. Again this
controls convergence to some extent. I suggest 0.5 (perhaps a bit 
less for large sample sizes). If it is too
low, the program may be inefficient. 

Otherwise, the behaviour of the program is similar to tm3, 2mod, or
dlik. 

I attach the initial version of the manuscript describing the method
(currently in revision for Genetics). 


