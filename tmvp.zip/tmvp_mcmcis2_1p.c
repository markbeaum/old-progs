#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "myutil.h"

#define DO_LIK_BITTY 1.0e-6

struct hist{
	double time;
	int *freq;
	int ns;
};

void read_parlist(int *i012,int np[],double *mat[3],float *Ploidy);
void is_samp(double ne0/*ancestral*/,double ne/*current*/,double tmax,
int nloc,int noall[],int nsamp[],struct hist **samps,double *pval, 
double *pval_se);
double lmulti_d(int n,int a[],int len,double x);
double cosimE(double t1,int ni,double ne0,double tn,double ne);
void read_data(struct hist **samps,int noall[],int nsamp[],int nloc);
void read_state(int nloc,int noall[],double *ne,double *ne0,
int *succ,int *iter,int *itmax,double *lik, float *Ploidy, float *Nemax);
void write_state(int nloc,int noall[],double ne,double ne0,int
	succ,int iter,int itmax,double lik,float Ploidy, float Nemax);
void printstuff(FILE *timeout,int iter,double lik,double
	ne,double ne0,int *noall,int nloc);
void accept(double *lik,double newlik,double *ne,double
	*new_ne,double *ne0,double *new_ne0);
void scandata(int *nloc,int *nsamp);
void twiddle(int nloc,double ne0,double *new_ne0,double ne,double *new_ne,
	int noall[],double *return_ftrans,double *return_rtrans);
void lik_cal(double ne0,double ne,int noall[],int nsamp[],int nloc,
struct hist **samps,double *newlik);
double do_lik_sim(double ne0,double ne,int noall,int nsamp,struct hist samps[]);
double seq(double ne0,double ne,int noall,int nsamp,struct hist samps[],
	int *izero);



float Ploidy,Nemax;
int Illegal,Toosmall;
int Maxit = 500;
double Tmax;
FILE *Testout;
double Escale;

main()
{

	int noall[100],nsamp[100],nloc,iter,itmax,succ,thin;
	int j,k,i,l;
	double **afreq,ne,ne0,**new_afreq,new_ne,new_ne0,ftrans,rtrans,pval,lik,newlik;
	double oldlik;
	FILE *freqout,*timeout,*isout;	
	int testsum,testnc;
	double test_t,temprt;
	int nobj,q5,q20,q50,q80,q95;
	float ll,lr,lmax,loct,uoct;
	int burn_in,sampfreq;
	double cond_mle,cond_lo,cond_hi;
	int jj;
	double llik,dd,sum;
	struct hist **samps;
	int mcmc,i012,np[3];
	double *mat[3],pval_se;
	
	
	opengfsr();

	Testout = fopen("test.out","w");
	scandata(&nloc,nsamp);
	samps = (struct hist **)malloc(nloc*sizeof(struct hist *));
	for(j=0;j<nloc;++j)samps[j] = (struct hist *)
						malloc(nsamp[j]*sizeof(struct hist));
	read_data(samps,noall,nsamp,nloc);
	
	printf("give maxit   ");
	scanf("%d",&Maxit);
	printf("give thinning interval   ");
	scanf("%d",&thin);
	printf("sd of parameter update (suggest <= 0.5)   ");
	scanf("%lf",&Escale);
	read_state(nloc,noall,&ne,&ne0,&succ,&iter,&itmax,&lik,
	&Ploidy,&Nemax);
	
	
	if(iter == 0){
		timeout = fopen("out","w");
		lik_cal(ne0,ne,noall,nsamp,nloc,samps,&lik);
		nobj = 0;
	}
	else{
		timeout = fopen("out","a");
	}
	printf("Tmax  is %f \n",Tmax);
	for(;iter<itmax;++iter){
/*		temprt = pow(1.0007,(double)iter)*0.1; */
		twiddle(nloc,ne0,&new_ne0,ne,&new_ne,noall,&ftrans,&rtrans);
		lik_cal(new_ne0,new_ne,noall,nsamp,nloc,samps,&newlik);
	 	pval = newlik+rtrans-lik-ftrans;  
	 	if(Illegal /* || Toosmall*/)pval = -100.0;
	/*	pval = temprt*(newlik-lik) + rtrans - ftrans; */
		if(pval >= 0 || (pval > -15.0 && gfsr4() < exp(pval))){
			accept(&lik,newlik,&ne,&new_ne,&ne0,&new_ne0);
			++succ;
		}
		if((iter+1)%thin == 0){
			printstuff(timeout,(iter+1)/thin,lik,ne,ne0,noall,nloc);
		}
		if((iter+1)%(2*thin) == 0){
			write_state(nloc,noall,ne,ne0,succ,iter+1,itmax,lik,Ploidy,Nemax);
			closegfsr();
			fflush(timeout);
		}
	/*	PC only - if((iter+1)%100 == 0)printf("%d iterations\n",iter+1); */
			
	}
	closegfsr();
}



void twiddle(int nloc,double ne0,double *new_ne0,double ne,double *new_ne,
int noall[],double *return_ftrans,double *return_rtrans)
{
	static double Scale2 = 50.0;
	int j,ip,k;
	double rtrans,ftrans,scale,dd;
	
	Illegal = 0;
	rtrans = ftrans = 0.0;
	
/*	*new_ne = ne;
	*new_ne0 = ne0;
	return;*/
	
	scale = exp(dd=norm4()*Escale);
	*new_ne = ne*scale;
	if((*new_ne) > Nemax)Illegal = 1;
	ftrans += 0.0;
	rtrans += dd;
	
	*new_ne0 = *new_ne;
	
	
	*return_ftrans = ftrans;
	*return_rtrans = rtrans;
	return;
}



void lik_cal(double ne0, double ne,int noall[],int nsamp[],int nloc,
struct hist **samps,double *newlik)
{
	double lik,lik2;
	int j,k;
	
	lik = 0.0;
	for(j=0;j<nloc;++j){
		lik += do_lik_sim(ne0,ne,noall[j],nsamp[j],samps[j]);
	}
	*newlik = lik;
}



void accept(double *lik,double newlik,double *ne,double
	*new_ne,double *ne0,double *new_ne0)
{
	double temp,**afreq_temp;
	temp = *ne;
	*ne = *new_ne;
	*new_ne = temp;
	
	temp = *ne0;
	*ne0 = *new_ne0;
	*new_ne0 = temp;
	
	*lik = newlik;
	
	return;
}
	
	



void printstuff(FILE *timeout,int iter,double lik,double
ne,double ne0,int *noall,int nloc)
{
	int j,k;
	fprintf(timeout,"%d ",iter);
	fprintf(timeout,"%e ",lik);
	fprintf(timeout,"%f %f ",ne0,ne);
	fprintf(timeout,"\n");
		
}

void read_state(int nloc,int noall[],
double *ne,double *ne0,int *succ,int *iter,int *itmax,double
*lik, float *Ploidy, float *Nemax)
{
	FILE *stf;
	int ic,k,j;
	stf = fopen("STATE","r");
	if(stf == 0)printerr("error reading stf 1 - file not found");
	ic = fscanf(stf,"%d %d %d %lf %f %f",succ,iter,itmax,lik,Ploidy,Nemax);
	if(ic <= 2 || ic == EOF)printerr("error reading stf 2 (too short?)");
	if(*iter == 0){
		*ne = gfsr4()*(*Nemax);
		*ne0 = *ne;
		return;
	}
	ic = fscanf(stf,"%lf %lf",ne0,ne);
	if(ic <= 0 || ic == EOF)printerr("error reading stf 4 (too short?)");
	/*ic = fscanf(stf,"%d",&j);
	if(ic != EOF)printerr("error reading stf 5 - too long");*/
	fclose(stf);
	return;
}

void write_state(int nloc,int noall[],double ne,double ne0,int
succ,int iter,int itmax,double lik, float Ploidy, float Nemax)
{
	FILE *stf;
	int k,j;
	stf = fopen("STATE","w");
	fprintf(stf,"%d %d %d %e %f %f\n",succ,iter,itmax,lik,Ploidy,Nemax);
	fprintf(stf,"%f %f\n",ne0,ne);
	fclose(stf);
	return;
}

void scandata(int *nloc,int *nsamp)
{
	FILE *inp;	
	int i,j,k,ii,noall;
	double dd;
	
	inp = fopen("infile","r");
	if(inp == 0)printerr("scandata: no infile");
	fscanf(inp,"%d",nloc);
	for(j=0;j<*nloc;++j){
		fscanf(inp,"%d %d",&nsamp[j],&noall);
		for(i=0;i<nsamp[j];++i){
			fscanf(inp,"%lf",&dd);
			for(k=0;k<noall;++k){
				fscanf(inp,"%d",&ii);
			}
		}
	}
	
	return;
}



void read_data(struct hist **samps,int noall[],int nsamp[],int nloc)
{
	FILE *inp;	
	int byall,j,k,l,ic,i,ii,dummy,isum;
	char c;
	
	inp = fopen("infile","r");
	if(inp == 0){
		printf("no infile\n");
		exit(1);
	}
	fscanf(inp,"%d",&ii);
	Tmax = -1;
	for(j=0;j<nloc;++j){
		fscanf(inp,"%d %d",&ii,&noall[j]);
		for(i=0;i<nsamp[j];++i){
			samps[j][i].freq = (int *)malloc(noall[j]*sizeof(int));
			fscanf(inp,"%lf",&samps[j][i].time);
			if(samps[j][i].time > Tmax)Tmax = samps[j][i].time;
			for(k=0,isum=0;k<noall[j];++k){
				fscanf(inp,"%d",&samps[j][i].freq[k]);
				isum += samps[j][i].freq[k];
			}
			samps[j][i].ns = isum;
		}
	}
	
	return;
}

void read_parlist(int *i012,int np[],double *mat[3],float *Ploidy)/*sets Maxit*/
{
	FILE *parin;
	int j;
	double limu[3],liml[3],delta[3];
	
	parin = fopen("is_params","r");
	fscanf(parin,"%d %f %d",i012,Ploidy,&Maxit);
	if(*i012 == 0){
		fscanf(parin,"%d %lf %lf",&np[0],&liml[0],&limu[0]);
		mat[0] = (double *)malloc(np[0]*sizeof(double));
		if(np[0] == 1)delta[0] = 0;
		else delta[0] = (limu[0]-liml[0])/(np[0]-1);
		for(j=0;j<np[0];++j)mat[0][j] = liml[0] + delta[0]*j;
	}
	else if(*i012 == 1){
		
		fscanf(parin,"%lf %lf",&liml[0],&limu[0]);
		mat[0] = (double *)malloc(np[0]*sizeof(double));
		
		if(np[0] == 1)delta[0] = 0;
		else delta[0] = (limu[0]-liml[0])/(np[0]-1);
		for(j=0;j<np[0];++j)mat[0][j] = liml[0] + delta[0]*j;
		
		fscanf(parin,"%lf %lf",&liml[1],&limu[1]);
		mat[1] = (double *)malloc(np[1]*sizeof(double));
		if(np[1] == 1)delta[1] = 0;
		else delta[1] = (limu[1]-liml[1])/(np[1]-1);
		for(j=0;j<np[1];++j)mat[1][j] = liml[1] + delta[1]*j;
		
		mat[2] = (double *)malloc(sizeof(double));
		fscanf(parin,"%lf",&(mat[2][0])); /* for Tmax */
	}
	else if(*i012 == 2){
		
		fscanf(parin,"%lf %lf",&liml[0],&limu[0]);
		mat[0] = (double *)malloc(np[0]*sizeof(double));
		if(np[0] == 1)delta[0] = 0;
		else delta[0] = (limu[0]-liml[0])/(np[0]-1);
		for(j=0;j<np[0];++j)mat[0][j] = liml[0] + delta[0]*j;
		
		fscanf(parin,"%lf %lf",&liml[1],&limu[1]);
		mat[1] = (double *)malloc(np[1]*sizeof(double));
		if(np[1] == 1)delta[1] = 0;
		else delta[1] = (limu[1]-liml[1])/(np[1]-1);
		for(j=0;j<np[1];++j)mat[1][j] = liml[1] + delta[1]*j;
		
		fscanf(parin,"%lf %lf",&liml[2],&limu[2]);
		mat[2] = (double *)malloc(np[2]*sizeof(double));
		if(np[2] == 1)delta[2] = 0;
		else delta[2] = (limu[2]-liml[2])/(np[2]-1);
		for(j=0;j<np[2];++j)mat[2][j] = liml[2] + delta[2]*j;
		
		fscanf(parin,"%lf",&(mat[2][0])); /* for Tmax */
	}	
	else printerr("read_parlist: data type not 0,1 or 2");
	
	fclose(parin);
}


/*
------------------------------------------------------------------------------------
do_lik_sim and its helper function seq can be used in place of do_lik and
its helper functions to _simulate_ the likelihoods. They are generally faster. I also
used these to check that the analytical and simulated likelihoods were the
same within sampling error */


double do_lik_sim(double ne0,double ne,int noall,int nsamp,struct hist samps[])
{
	int i,j,nout1,izero;
	double esum,prob1;
	static int tgen[100];
	
	Toosmall = 0;

	esum = 0.0;
	for(i=0;i<Maxit;++i){
	
		prob1 = seq(ne0,ne,noall,nsamp,samps,&izero);
		if(izero)continue;
		
		esum += exp(prob1);
	}
	if(esum == 0.0)Toosmall = 1;
	esum /= Maxit;
	if(esum > 0.0)esum = log(esum);
	else esum = -1.0e100;
	return esum;
}

void is_samp(double ne0/*ancestral*/,double ne/*current*/,double tmax,
int nloc,int noall[],int nsamp[],struct hist **samps,double *pval, 
double *pval_se)
{
	int i,j,nout1,izero,firstpass;
	double esum,*prob1,sum2,gesum,gvarm,dd,offset;
	static int tgen[100];
	
	if(ne0 == 0 || ne == 0){
		*pval = 0.0;
		*pval_se = 0.0;
		return;
	}
	
	Tmax = tmax; /* global variable Tmax initially set to time of oldest sample,
					when data is read - used in cosimE */
	
	prob1 = (double *)malloc(Maxit*sizeof(double));
	
	gesum = 1.0;
	gvarm = 0.0;
	firstpass = 1;
	
	for(j=0;j<nloc;++j){
	
		esum = 0.0;
		for(i=0;i<Maxit;++i){

			dd = seq(ne0,ne,noall[j],nsamp[j],samps[j],&izero);
			if(izero){
				prob1[i] = 0; 
				continue;
			}
			if(firstpass){
				offset = dd;
				firstpass = 0;
			}
			
			prob1[i] = exp(dd-offset);
			esum += prob1[i];
		}
		esum /= Maxit;
		sum2 = 0.0;
		for(i=0;i<Maxit;++i)sum2 += (prob1[i]-esum)*(prob1[i]-esum);
		sum2 /= (Maxit-1)*Maxit;
		gvarm = gvarm*sum2 + gesum*gesum*sum2 + esum*esum*gvarm;
		gesum *= esum;
	
	}
	*pval = gesum*exp(nloc*offset);
	*pval_se = sqrt(gvarm)*exp(nloc*offset);
	
	free(prob1);
}


double lhyper(int noall,int n1,int n2,int a1[],int a2[])
{
	double tt;
	int j;
	
	tt = lgamma(n1+1.0) + lgamma(n2+1.0) - lgamma(n1+n2+1.0);
	for(j=0;j<noall;++j){
		tt += lgamma(a1[j]+a2[j]+1.0)-lgamma(a1[j]+1.0)-lgamma(a2[j]+1.0);
	}
	return tt;
}

	
double lmulti_d(int n,int a[],int len,double x)
{
	double t1,sum;
	int j;
	t1 = lgamma(n+1.0) + lgamma(len*x) - lgamma(n + len*x);
	sum = 0;
	for(j=0;j<len;++j){
		sum += lgamma(a[j]+x) - lgamma(a[j]+1) - lgamma(x);
	}
	return t1 + sum;
}



double seq(double ne0,double ne,int noall,int nsamp,struct hist samps[],
int *izero)
{
	double lfunc,gams,w1,konst,*pcol,tprob;
	double rt,ct,rtcum,ctcum;
	float colrate,mutrate,rni,rr;
	int ni,ip,j,k,nmut,ncol,icheck,ng1,itime,ir,cum;
	static int gen[100];
	ni = samps[0].ns;
	lfunc = 0.0;
	rtcum = 0.0;
	ctcum = 0.0;
	/* Fill up the initial distribution at time 0 */
	for(j=0,ng1=0;j<noall;++j){
		gen[j] = samps[0].freq[j];
		if(gen[j] > 0)++ng1;
	}
	itime = 1;
	
	*izero = 0;
	while(1){
		ctcum = cosimE(ctcum,ni,ne0*Ploidy,Tmax,ne*Ploidy);
		if(ctcum >= samps[itime].time){ /* add in the new samples */
			/* need to calculate probability of sampling the new samples
			without replacement from the combined set of lineages 
			need to remember to add to ng1 if necessary*/
			ctcum = samps[itime].time;
			lfunc += lhyper(noall,samps[itime].ns,ni,samps[itime].freq,
						gen); /* probability of getting the observed 
						frequencies when dividing the lineages into
						those that come from this sample and those
						that come from the more recent genealogical 
						history */
			for(j=0,ng1=0;j<noall;++j){
				gen[j] += samps[itime].freq[j];
				if(gen[j] > 0)++ng1;
			}
			ni += samps[itime].ns;
			if(itime == nsamp-1)break; /* last sample */
				               /* stop and calculate multinomial probs */
			++itime;
		}
		else{
			/* ng1 is the number of allelic categories that have at least
			1 lineage in them. This increases monotonically back in time because
			new lineages can be added within an allelic class, but they can
			never become less than 1 in a drift-based model*/
			
			if(ni == ng1) {  /* stop because prob of this path is zero */
				*izero = 1;
				return 0.0;
			}
			else if(ni < ng1)printerr("seq: ni < ng1");
			lfunc += log((double)(ni-ng1)/(ni-1.0)); 
			ir = disrand(1,(ni-ng1)); /* choose appropriate category in the usual way */
			for(j=0,cum=0;j<noall;++j){
				if(gen[j] < 1)continue;
				cum += gen[j]-1;
				if(ir <= cum)break;
			}
			if(gen[j] <= 1){
				printf("error\n");
				printf("gen[j] is %d, j is %d, noall is %d, rr is %f\npcol:\n",
					gen[j],j,noall,rr);
				for(j=0;j<noall;++j){
					printf("%f\n",pcol[j]);
				}
				exit(1);
			}
			--gen[j];
			--ni;
		}
	}
	lfunc += lmulti_d(ni,gen,noall,1.0);
	return lfunc;
}

double cosimE(double t1,int ni,double ne0,double tn,double ne)
{
	double rtf,cutoff,t2,deltat,dtop,tdash,logr,tf,rval;
	
	tf = tn/ne;
	t1 = t1/ne; /* remove scaling */
	rval = ne/ne0;
	
	dtop = (ni*(ni-1)*0.5);
	tdash = -log(gfsr8())/dtop;
	tdash += t1;
	
	
	if(fabs(1.0-rval) < 1.0e-5){ /*to avoid division by 0 */
		return tdash *ne ; /*put scaling back in */
	}
	deltat = tdash - t1;
	
	if(t1 < tf){
		logr = log(rval);
		cutoff = (rval - pow(rval,t1/tf))*tf/logr;
		/* this is the value of (tdash - t1) corresponding to a real time of
	   		tf - when t2 == tf */
		if(deltat < cutoff){
			t2 = log(deltat*logr/tf+pow(rval,t1/tf))*tf/logr;

			return t2 *ne;/*put scaling back in */
		}
		else {
			t2 = (deltat - cutoff)/rval + tf;
			return t2 *ne;/*put scaling back in */
		}
	}
	else {
		t2 = deltat/rval + t1;
		return t2 *ne;/*put scaling back in */
	}
}

			
