#read in the data
m1 <- data.matrix(read.table("fst.out"))
#read in two functions that will get pvals, fst per locus, and fst per population.
source("functions.r")

#the function getpvals() computes point estimates of FST (average over pops) and puts them in column
# 1 of the output matrix, and estimates of the transformed Bayesian p-vals (as in paper) and puts them in column 3 (col 2 has 
#untransformed p-vals).
# in this example there are 20 loci and 6 populations.
pvals <- getpvals(m1,20,6)

#the function getfsts() puts the FST for pops 1..d in columns 1..d. These are samples from the posterior distribution.
fstvals <- getfsts(m1,20,6)

#plot fst per locus against transformed p-vals
plot(pvals[,3],pvals[,1],xlab="transformed p-values",ylab="FST")
#these points were simulated to be under selection
points(pvals[1:5,3],pvals[1:5,1],pch=16,col="red") 
#plot critical p-value - in this case the 0.05 level.
x <- 2*abs(0.975 - 0.5)
abline(v=log(x/(1-x)))

# plot posterior distribution for population-specific FSTs
plot(density(fstvals[,1]),xlim=c(0,0.2),xlab="F",main="")
lines(density(fstvals[,2]),col="red")
lines(density(fstvals[,3]),col="green")
lines(density(fstvals[,4]),col="blue")
lines(density(fstvals[,5]),col="purple")
lines(density(fstvals[,6]),col="cyan")
q()
