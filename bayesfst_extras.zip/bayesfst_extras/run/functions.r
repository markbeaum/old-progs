getpvals <- function(m,nloci,npops)
{
	nsamp <- length(m[,1])
	locvec <- numeric(nloci)
	effect <- numeric(nloci)
	gm <- apply(m[,(1+nloci+1):(1+nloci+npops)],1,mean)
	for(j in 1:nloci){
		locvec[j] <- ecdf(m[,1+j])(0)
		if(locvec[j] <=0 )locvec[j] <- 1/(2*nsamp)
		if(locvec[j] >= 1)locvec[j] <- 1-1/(2*nsamp)
		x <- m[,1+j]+gm
		x <- exp(x)/(1+exp(x))
		effect[j] <- mean(x)
	}
	x <- 2*abs(locvec - 0.5)
	
	cbind(effect,locvec,log(x/(1-x)))

}

getfsts <- function(m,nloci,npops)
{

	fstmat <- matrix(nrow=length(m[,1]),ncol=npops)
	for(j in 1:npops){
		a <- exp(m[,j+1+nloci])
		fstmat[,j] <- a/(1+a)
	}
	fstmat

}