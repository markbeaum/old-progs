Context for this program is on page 324 of Beaumont et al (Molecular Ecology, 2001).
Mantreg does Mantel-type permutations for pvals
Randreg does ordinary permutations for pvals


You need the random number seed file INTFILE. The input files need to be called infile_x and
infile_y.
infile_y contains the response variable. 
It asks how many cases there are (ie number of objects that you are comparing)
and how many independent variables in infile_x.
It then asks how many of the x you want to use
It then asks you to pick that number of variables from the list 0...

Ie if there are 6 variables and you want to pick 3 you would enter 6 then 3 then
2 3 4 (say)
It then asks how many permutations (1000 is reasonable), and then outputs (to the
screen) regression coefficients, pvals, and R2 and an overall p value. I have
used the program for manual stepwise regression, to choose a best fitting model.

