#define PI  3.141592653589793
void opengfsr(void),
	closegfsr(void),sort(int n, float ra[]),isort(int n,float inar[],int index[]);
int disrand(int l, int t),intrand(void),poidev(float xm);
float expdev(void),gfsr4(void),gammln(float xx),norm4(void);
void mom(float x[],int n,float *x1,float *x2,float *x3,float *x4,
	float *min,float *max);
	
void printerr(char *s);
void isorti(int n,int inar[],int index[]);
void sorti(int n,int ra[]);

void locate(float *xx, unsigned long n, float x, int *j);
int bnldev(float pp, int n);

float gamdev(int ia);
double rgamma(double a, double scale);
