#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "myutil.h"

#define DO_LIK_BITTY 1.0e-6
#define MAXALL 100
#define MAXNSAMP 100

struct hist{
	double time;
	int *freq;
	int ns;
};

double lmulti_d(int n,int a[],int len,double x);
double ld_gammadens(double x,double shape, double scale);
double cosim(double t1,int ni,double ne);
void read_state(int nloc,int noall[],int *succ,int *iter,int *itmax,double *lik, float *Ploidy, float *Nemax);
void write_state(int nloc,int noall[],int
	succ,int iter,int itmax,double lik,float Ploidy, float Nemax);
void printstuff(FILE *timeout,int iter,double lik,int *noall,int nloc);
void accept(double *lik,double newlik);
void scandata(int *nloc);
void twiddle(int nloc,int noall[],double *return_ftrans,double *return_rtrans);
void lik_cal(int noall[],int nloc,double *newlik);
double seq(double ne0,double ne,int noall,int nsamp,struct hist samps[],int *return_ni,int *return_gen,
	int *izero);
struct hist *makesamp(int *vec,int n);
int *addvec(int *v1, int *v2,int n);
double lhyper(int noall,int n1,int n2,int a1[],int a2[]);
double do_lik_sim(int noall,int nsamp_C,int nsamp_F,int nsamp_G,struct hist samps_C[],struct hist samps_F[],struct hist samps_G[]);
void read_data(int noall[],int nloc);
void reject();



float Ploidy,Nemax;
int Illegal,Toosmall;
int Maxit = 500;
double Tmax;
FILE *Testout;
double Escale;
int Itop=1,Itop_old;
double NeC0,NeC1,NeF0,NeF1,NeG0,NeG1,NeC0_old,NeC1_old,NeF0_old,NeF1_old,NeG0_old,NeG1_old;
double MDscale=1.0,Currtime=0.0;
int Nsamp_C[MAXNSAMP],Nsamp_F[MAXNSAMP],Nsamp_G[MAXNSAMP];
struct hist **Samps_C,**Samps_F,**Samps_G;
double This_seg_time, J1, J2,J1_old, J2_old;
double Generation_time,Generation_time_old;
int Trial;
double Prior_new,Prior_old;


main()
{

	int noall[100],nloc,iter,itmax,succ,thin;
	int j,k,i,l;
	double ftrans,rtrans,pval,lik,newlik;
	double oldlik;
	FILE *freqout,*timeout,*isout;
	int testsum,testnc;
	double test_t,temprt;
	int nobj,q5,q20,q50,q80,q95;
	float ll,lr,lmax,loct,uoct;
	int burn_in,sampfreq;
	double cond_mle,cond_lo,cond_hi;
	int jj;
	double llik,dd,sum;
	int mcmc,i012,np[3];
	double *mat[3],pval_se;


	opengfsr();

	Testout = fopen("test.out","w");
	scandata(&nloc);// does Nsamp_C, Nsamp_F, Nsamp_G
	Samps_C = (struct hist **)malloc(nloc*sizeof(struct hist *));
	Samps_F = (struct hist **)malloc(nloc*sizeof(struct hist *));
	Samps_G = (struct hist **)malloc(nloc*sizeof(struct hist *));
	for(j=0;j<nloc;++j)Samps_C[j] = (struct hist *)
						malloc(Nsamp_C[j]*sizeof(struct hist));
	for(j=0;j<nloc;++j)Samps_F[j] = (struct hist *)
						malloc(Nsamp_F[j]*sizeof(struct hist));
	for(j=0;j<nloc;++j)Samps_G[j] = (struct hist *)
						malloc(Nsamp_G[j]*sizeof(struct hist));
	read_data(noall,nloc);

	printf("give maxit   ");
	scanf("%d",&Maxit);
	printf("give thinning interval   ");
	scanf("%d",&thin);
	printf("sd of parameter update (suggest <= 0.5)   ");
	scanf("%lf",&Escale);
	read_state(nloc,noall,&succ,&iter,&itmax,&lik,
	&Ploidy,&Nemax);


	if(iter == 0){
		timeout = fopen("out","w");
		lik_cal(noall,nloc,&lik);
		nobj = 0;
	}
	else{
		timeout = fopen("out","a");
	}
	printf("Tmax  is %f \n",Tmax);
	for(;iter<itmax;++iter){
/*		temprt = pow(1.0007,(double)iter)*0.1; */
		twiddle(nloc,noall,&ftrans,&rtrans);
		if(!Illegal){
			lik_cal(noall,nloc,&newlik);
	 		pval = newlik+rtrans-lik-ftrans+Prior_new-Prior_old;
		}
	 	else pval = -100.0;
	/*	pval = temprt*(newlik-lik) + rtrans - ftrans; */
		if(pval >= 0 || (pval > -15.0 && gfsr4() < exp(pval))){
			accept(&lik,newlik);
			++succ;
		}
		else reject();
		if((iter+1)%thin == 0){
			printstuff(timeout,(iter+1)/thin,lik,noall,nloc);
		}
		if((iter+1)%(2*thin) == 0){
			write_state(nloc,noall,succ,iter+1,itmax,lik,Ploidy,Nemax);
			closegfsr();
			fflush(timeout);
		}
	/*	PC only - if((iter+1)%100 == 0)printf("%d iterations\n",iter+1); */

	}
	closegfsr();
}

void reject()
{

	switch(Trial){
		case 1:
			Itop = Itop_old;break;
		case 2:
			NeC0 = NeC0_old;break;
		case 3:
			NeC1 = NeC1_old; break;
		case 4:
			NeF0 = NeF0_old; break;
		case 5:
			NeF1 = NeF1_old; break;
		case 6:
			NeG0 = NeG0_old; break;
		case 7:
			NeG1 = NeG1_old; break;
		case 8:
			J1 = J1_old; J2 = J2_old; break;
		case 9:
			J2 = J2_old; break;
		case 10:
			Generation_time = Generation_time_old; break;
		default :
			printerr("Trial is wrong");
	}
}



void twiddle(int nloc,int noall[],double *return_ftrans,double *return_rtrans)
{
	static double Scale2 = 50.0;
	int j,ip,k;
	double rtrans,ftrans,scale,dd,rr;

	Illegal = 0;
	rtrans = ftrans = 0.0;

	rr = gfsr8();
	/* Need to change:
		Itop
		NeC0
		NeC1
		NeF0
		NeF1
		NeG0
		NeG1
		J1
		J2
		Generation_time
	*/

	if(rr < 0.1){ // change Itop
		Trial = 1;
		Itop_old = Itop;
		Itop = Itop == 1 ? 2: 1;
	}
	else if(rr < 0.2){ // change NeC0
		Trial = 2;
		NeC0_old = NeC0;
		scale = exp(dd=norm4()*Escale);
		NeC0 = NeC0*scale;
		if(NeC0 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
		Prior_old = ld_gammadens(NeC0_old,12.0,2.0);// this prior gives roughly a range 10 to 50 for champion
		Prior_new = ld_gammadens(NeC0,12.0,2.0);
	}
	else if(rr < 0.3){ // change NeC1
		Trial = 3;
		NeC1_old = NeC1;
		scale = exp(dd=norm4()*Escale);
		NeC1 = NeC1*scale;
		if(NeC1 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
		Prior_old = ld_gammadens(NeC1_old,12.0,2.0);// this prior gives roughly a range 10 to 50 for champion
		Prior_new = ld_gammadens(NeC1,12.0,2.0);
	}
	else if (rr < 0.4){ // change NeF0
		Trial = 4;
		NeF0_old = NeF0;
		scale = exp(dd=norm4()*Escale);
		NeF0 = NeF0*scale;
		if(NeF0 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
	}
	else if (rr < 0.5){ // change NeF1
		Trial = 5;
		NeF1_old = NeF1;
		scale = exp(dd=norm4()*Escale);
		NeF1 = NeF1*scale;
		if(NeF1 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
	}
	else if (rr < 0.6){ // change NeG0
		Trial = 6;
		NeG0_old = NeG0;
		scale = exp(dd=norm4()*Escale);
		NeG0 = NeG0*scale;
		if(NeG0 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
		Prior_old = ld_gammadens(NeG0_old,8.0,30.0);// this prior gives roughly a range 50 to 500 for Gardner
		Prior_new = ld_gammadens(NeG0,8.0,30.0);
	}
	else if (rr < 0.7){ // change NeG1
		Trial = 7;
		NeG1_old = NeG1;
		scale = exp(dd=norm4()*Escale);
		NeG1 = NeG1*scale;
		if(NeG1 > Nemax)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
		Prior_old = ld_gammadens(NeG1_old,8.0,30.0);// this prior gives roughly a range 50 to 500 for Gardner
		Prior_new = ld_gammadens(NeG1,8.0,30.0);
	}
	else if (rr < 0.8){ // change J1-Tmax interval
		Trial = 8;
		J1_old = J1;
		J2_old = J2;
		scale = exp(dd=norm4()*Escale);
		J1 = (J1-Tmax)*scale+Tmax;
		J2 = J2_old - J1_old + J1;
		if(J1 > Tmax + 1000.0 || J2 > J1 + 1000.0)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;

	}
	else if (rr < 0.9){ // change J2-J1 interval
		Trial = 9;
		J2_old = J2;
		scale = exp(dd=norm4()*Escale);
		J2 = (J2-J1)*scale+J1;
		if(J2 > J1 + 1000.0)Illegal = 1;
		ftrans += 0.0;
		rtrans += dd;
	}
	else { // change Generation_time
		Trial = 10;
		Generation_time_old = Generation_time;
		Generation_time = gfsr4()*2.0 + 2.0;
	}

/*	*new_ne = ne;
	*new_ne0 = ne0;
	return;*/

/*	scale = exp(dd=norm4()*Escale);
	*new_ne = ne*scale;
	if((*new_ne) > Nemax)Illegal = 1;
	ftrans += 0.0;
	rtrans += dd;

	scale = exp(dd=norm4()*Escale);
	*new_ne0 = ne0*scale;
	if((*new_ne0) > Nemax)Illegal = 1;
	ftrans += 0.0;
	rtrans += dd;*/
/*	*new_ne0 = *new_ne; */

	*return_ftrans = ftrans;
	*return_rtrans = rtrans;
	return;
}

double ld_gammadens(double x,double shape, double scale)
{

	return -shape*log(scale) - lgamma(shape) + (shape - 1.0)*log(x) - x/scale;  
}


void lik_cal(int noall[],int nloc,double *newlik)
{
	double lik,lik2;
	int j,k;

	lik = 0.0;
	for(j=0;j<nloc;++j){ // samps and nsamp needs also to be indexed by location
		lik += do_lik_sim(noall[j],Nsamp_C[j],Nsamp_F[j],Nsamp_G[j],Samps_C[j],Samps_F[j],Samps_G[j]);
	}
	*newlik = lik;
}



void accept(double *lik,double newlik)
{
	double temp,**afreq_temp;

	*lik = newlik;

	return;
}





void printstuff(FILE *timeout,int iter,double lik,int *noall,int nloc)
{
	int j,k;
	fprintf(timeout,"%d ",iter);
	fprintf(timeout,"%e ",lik);
	fprintf(timeout,"%d %f %f %f %f %f %f %f %f %f ",Itop,NeC0,NeC1,NeF0,NeF1,NeG0,NeG1,J1,J2,Generation_time);
	/* Need to print:
		Itop
		NeC0
		NeC1
		NeF0
		NeF1
		NeG0
		NeG1
		J1
		J2
		Generation_time
	*/

	//fprintf(timeout,"%f %f ");
	fprintf(timeout,"\n");

}

void read_state(int nloc,int noall[],int *succ,int *iter,int *itmax,double *lik, float *Ploidy, float *Nemax)
{
	FILE *stf;
	int ic,k,j;
	stf = fopen("STATE","r");
	if(stf == 0)printerr("error reading stf 1 - file not found");
	ic = fscanf(stf,"%d %d %d %lf %f %f",succ,iter,itmax,lik,Ploidy,Nemax);
	if(ic <= 2 || ic == EOF)printerr("error reading stf 2 (too short?)");
	if(*iter == 0){
		Itop = 1;// maybe randomize
		NeC0 = rgamma(12.0,2.0);
		NeC1 = rgamma(12.0,2.0);
		NeF0 = gfsr4()*(*Nemax-20.0) + 20.0;
		NeF1 = gfsr4()*(*Nemax-20.0) + 20.0;
		NeG0 = rgamma(8.0,30.0);
		NeG1 = rgamma(8.0,30.0);
		J1 = Tmax + gfsr4()*10.0;
		J2 = J1 + gfsr4()*10.0;
		//J1 = Tmax;
		//J2 = Tmax;
		Generation_time = gfsr4()*2.0 + 2.0;
		return;
	}
	ic = fscanf(stf,"%d %lf %lf %lf %lf %lf %lf %lf %lf %lf ",&Itop,&NeC0,&NeC1,&NeF0,&NeF1,&NeG0,&NeG1,&J1,&J2,&Generation_time);
	if(ic <= 0 || ic == EOF)printerr("error reading stf 4 (too short?)");
	/*ic = fscanf(stf,"%d",&j);
	if(ic != EOF)printerr("error reading stf 5 - too long");*/
	fclose(stf);
	return;
}

void write_state(int nloc,int noall[],int
succ,int iter,int itmax,double lik, float Ploidy, float Nemax)
{
	FILE *stf;
	int k,j;
	stf = fopen("STATE","w");
	fprintf(stf,"%d %d %d %e %f %f\n",succ,iter,itmax,lik,Ploidy,Nemax);
	fprintf(stf,"%d\n%f %f %f %f %f %f\n%f %f\n%f\n",Itop,NeC0,NeC1,NeF0,NeF1,NeG0,NeG1,J1,J2,Generation_time);
	//fprintf(stf,"%f %f\n",ne0,ne);
	fclose(stf);
	return;
}

void scandata(int *nloc)
{
	FILE *inp_C,*inp_G,*inp_F;
	int i,j,k,ii,noall,nloc2;
	double dd;

	inp_C = fopen("infile_champion.txt","r");
	if(inp_C == 0)printerr("scandata: no Champion infile");
	fscanf(inp_C,"%d",nloc);// assume number of loci are the same
	for(j=0;j<*nloc;++j){
		fscanf(inp_C,"%d %d",&Nsamp_C[j],&noall);
		for(i=0;i<Nsamp_C[j];++i){
			fscanf(inp_C,"%lf",&dd);
			for(k=0;k<noall;++k){
				fscanf(inp_C,"%d",&ii);
			}
		}
	}
	inp_F = fopen("infile_floreana.txt","r");
	if(inp_F == 0)printerr("scandata: no Floreana infile");
	fscanf(inp_F,"%d",&nloc2);// assume number of loci are the same
	if(nloc2 != *nloc)printerr("number of loci different - floreana");
	for(j=0;j<*nloc;++j){
		fscanf(inp_F,"%d %d",&Nsamp_F[j],&noall);
		for(i=0;i<Nsamp_F[j];++i){
			fscanf(inp_F,"%lf",&dd);
			for(k=0;k<noall;++k){
				fscanf(inp_F,"%d",&ii);
			}
		}
	}
	inp_G = fopen("infile_gardner.txt","r");
	if(inp_G == 0)printerr("scandata: no Gardner infile");
	fscanf(inp_G,"%d",&nloc2);// assume number of loci are the same
	if(nloc2 != *nloc)printerr("number of loci different - gardner");
	for(j=0;j<*nloc;++j){
		fscanf(inp_G,"%d %d",&Nsamp_G[j],&noall);
		for(i=0;i<Nsamp_G[j];++i){
			fscanf(inp_G,"%lf",&dd);
			for(k=0;k<noall;++k){
				fscanf(inp_G,"%d",&ii);
			}
		}
	}
	fclose(inp_C);
	fclose(inp_F);
	fclose(inp_G);

	return;
}



void read_data(int noall[],int nloc)
{
	FILE *inp;
	int byall,j,k,l,ic,i,ii,dummy,isum;
	char c;

	inp = fopen("infile_champion.txt","r");
	if(inp == 0){
		printf("no infile for Champion\n");
		exit(1);
	}
	fscanf(inp,"%d",&ii);
	Tmax = -1;
	for(j=0;j<nloc;++j){
		fscanf(inp,"%d %d",&ii,&noall[j]);
		for(i=0;i<Nsamp_C[j];++i){
			Samps_C[j][i].freq = (int *)malloc(noall[j]*sizeof(int));
			fscanf(inp,"%lf",&Samps_C[j][i].time);
			if(Samps_C[j][i].time > Tmax)Tmax = Samps_C[j][i].time;
			for(k=0,isum=0;k<noall[j];++k){
				fscanf(inp,"%d",&Samps_C[j][i].freq[k]);
				isum += Samps_C[j][i].freq[k];
			}
			Samps_C[j][i].ns = isum;
		}
	}
	fclose(inp);

	inp = fopen("infile_gardner.txt","r");
	if(inp == 0){
		printf("no infile for Gardner\n");
		exit(1);
	}
	fscanf(inp,"%d",&ii);
	for(j=0;j<nloc;++j){
		fscanf(inp,"%d %d",&ii,&noall[j]);
		for(i=0;i<Nsamp_G[j];++i){
			Samps_G[j][i].freq = (int *)malloc(noall[j]*sizeof(int));
			fscanf(inp,"%lf",&Samps_G[j][i].time);
			if(Samps_G[j][i].time > Tmax)Tmax = Samps_G[j][i].time;
			for(k=0,isum=0;k<noall[j];++k){
				fscanf(inp,"%d",&Samps_G[j][i].freq[k]);
				isum += Samps_G[j][i].freq[k];
			}
			Samps_G[j][i].ns = isum;
		}
	}
	fclose(inp);

	inp = fopen("infile_floreana.txt","r");
	if(inp == 0){
		printf("no infile for Floreana\n");
		exit(1);
	}
	fscanf(inp,"%d",&ii);
	for(j=0;j<nloc;++j){
		fscanf(inp,"%d %d",&ii,&noall[j]);
		for(i=0;i<Nsamp_F[j];++i){
			Samps_F[j][i].freq = (int *)malloc(noall[j]*sizeof(int));
			fscanf(inp,"%lf",&Samps_F[j][i].time);
			if(Samps_F[j][i].time > Tmax)Tmax = Samps_F[j][i].time;
			for(k=0,isum=0;k<noall[j];++k){
				fscanf(inp,"%d",&Samps_F[j][i].freq[k]);
				isum += Samps_F[j][i].freq[k];
			}
			Samps_F[j][i].ns = isum;
		}
	}
	fclose(inp);
	return;
}



/*
------------------------------------------------------------------------------------
do_lik_sim and its helper function seq can be used in place of do_lik and
its helper functions to _simulate_ the likelihoods. They are generally faster. I also
used these to check that the analytical and simulated likelihoods were the
same within sampling error */


double do_lik_sim(int noall,int nsamp_C,int nsamp_F,int nsamp_G,struct hist samps_C[],struct hist samps_F[],struct hist samps_G[])
{
	int i,j,nout1,izero;
	double esum;
	static int tgen[100];
	static int nf_C,found_C[MAXALL],nf_G,found_G[MAXALL],nf_F,found_F[MAXALL],anc1[MAXALL],nf_a1,found_a1[MAXALL];
	double totprob,prob1,prob2,prob3,prob4,prob5,prob6,prob7,prob8,prob9,prob10,prob11,prob12,prob13,prob14;

	Toosmall = 0;

	esum = 0.0;
	for(i=0;i<Maxit;++i){

		// there are two topologies: ((cf),g) and (c,(fg))

		// if topology 1 ((cf),g)
		if(Itop == 1){
			This_seg_time = J1;
			prob1 = seq(NeC0,NeC1,noall,nsamp_C,samps_C,&nf_C,found_C,&izero);if(izero)continue; /* Champion: This goes up to its time of union with Floreana - nb upper
														  time is unknown, but greater than Floreana sample of 1835.
														  Get Ne for current sample (t known), t/ne for older sample. t has a minimum prior for joining with
														  Floreana of 1906  to 1835. Need prior for Ne for this period.*/
			prob2 = seq(NeF0,NeF0,noall,nsamp_F,samps_F,&nf_F,found_F,&izero);if(izero)continue; /* Floreana: This goes up to time of join with Champion*/
			prob3 = lhyper(noall,nf_C,nf_F,found_C,found_F);
			for(j=0;j<noall;++j)anc1[j] = found_C[j]+found_F[j];
			This_seg_time = J2;
			Currtime = J1;
			prob4 = seq(NeF1,NeF1,noall,1,makesamp(anc1,noall),&nf_a1,found_a1,&izero);if(izero)continue;// this does drift between the two joins
			prob5 = seq(NeG0,NeG1,noall,nsamp_G,samps_G,&nf_G,found_G,&izero);if(izero)continue; /* Gardener: This goes up to its time of join with (Floreana, Champion) - nb
																		   upper time is unknown, but greater than join of Floreana with Champion*/
			prob6 = lhyper(noall,nf_a1,nf_G,found_a1,found_G); // join prob (get from dlik stuff...)
			prob7 = lmulti_d(nf_a1+nf_G,addvec(found_a1,found_G,noall),noall,MDscale); // prob founder lineages from prior. (Multinomial Dirichlet).
			totprob = prob1 + prob2 + prob3 + prob4 + prob5 + prob6 + prob7;
		}

		// else if topology (c,(fg))
		else if(Itop == 2){
			This_seg_time = J2;
			prob8 = seq(NeC0,NeC1,noall,nsamp_C,samps_C,&nf_C,found_C,&izero);if(izero)continue; /* Champion: This goes up to its time of union with (Floreana, Gardener)*/
			This_seg_time = J1;
			prob9 = seq(NeF0,NeF0,noall,nsamp_F,samps_F,&nf_F,found_F,&izero);if(izero)continue; /* Floreana: This goes up to time of join with Gardener*/
			prob10 = seq(NeG0,NeG1,noall,nsamp_G,samps_G,&nf_G,found_G,&izero);if(izero)continue; /* Gardener: This goes up to its time of join with Floreana */
			prob11 = lhyper(noall,nf_F,nf_G,found_F,found_G); // join prob Floreana, Gardener(get from dlik stuff...)
			for(j=0;j<noall;++j)anc1[j] = found_F[j] + found_G[j];
			This_seg_time = J2;
			Currtime = J1;
			prob12 = seq(NeF1,NeF1,noall,1,makesamp(anc1,noall),&nf_a1,found_a1,&izero);if(izero)continue;// this does drift between the two joins
			prob13 = lhyper(noall,nf_a1,nf_C,found_a1,found_C);  // join prob Champion with (Floreana, Gardner) (get from dlik stuff...)
			prob14 = lmulti_d(nf_a1+nf_C,addvec(found_a1,found_C,noall),noall,MDscale); // prob founder lineages from prior. (Multinomial Dirichlet).
			totprob = prob8 + prob9 + prob10 + prob11 + prob12 + prob13 + prob14;
		}
		else printerr("Itop wrong");
		///////////////////////////////////

		esum += exp(totprob);
	}
	if(esum == 0.0)Toosmall = 1;
	esum /= Maxit;
	if(esum > 0.0)esum = log(esum);
	else esum = -1.0e100;
	return esum;
}

int *addvec(int *v1, int *v2,int n)
{
	static int myvec[MAXALL];
	int j;
	for(j=0;j<n;++j)myvec[j] = v1[j] + v2[j];
	return myvec;

}
struct hist *makesamp(int *vec,int n)
{
	static struct hist myhist;
	int j,isum;
	static firstime=1;
	if(firstime){
		myhist.freq = (int *)malloc(MAXALL*sizeof(int));
		firstime = 0;
	}
	myhist.time = Currtime;
	for(j=0,isum=0;j<n;++j){
		myhist.freq[j] = vec[j];
		isum += vec[j];
	}
	myhist.ns = isum;
	return &myhist;
}


double lhyper(int noall,int n1,int n2,int a1[],int a2[])
{
	double tt;
	int j;

	tt = lgamma(n1+1.0) + lgamma(n2+1.0) - lgamma(n1+n2+1.0);
	for(j=0;j<noall;++j){
		tt += lgamma(a1[j]+a2[j]+1.0)-lgamma(a1[j]+1.0)-lgamma(a2[j]+1.0);
	}
	return tt;
}


double lmulti_d(int n,int a[],int len,double x)
{
	double t1,sum;
	int j;
	t1 = lgamma(n+1.0) + lgamma(len*x) - lgamma(n + len*x);
	sum = 0;
	for(j=0;j<len;++j){
		sum += lgamma(a[j]+x) - lgamma(a[j]+1) - lgamma(x);
	}
	return t1 + sum;
}



double seq(double ne0,double ne,int noall,int nsamp,struct hist samps[],int *return_ni,int *return_gen,
int *izero)
{
	double lfunc,gams,w1,konst,*pcol,tprob;
	double rt,ct,rtcum,ctcum;
	double cur_ne;
	float colrate,mutrate,rni,rr;
	int ni,ip,j,k,nmut,ncol,icheck,ng1,itime,ir,cum,is_segment = 0;
	static int gen[100];
	ni = samps[0].ns;
	lfunc = 0.0;
	rtcum = 0.0;
	ctcum = samps[0].time;
	/* Fill up the initial distribution at time 0 */
	for(j=0,ng1=0;j<noall;++j){
		gen[j] = samps[0].freq[j];
		if(gen[j] > 0)++ng1;
	}
	itime = 1;
	cur_ne = ne0;

	*izero = 0;
	while(1){
		ctcum = cosim(ctcum,ni,cur_ne*Ploidy); //
		if(nsamp == itime && ctcum >= This_seg_time)break;
		else if(itime < nsamp && ctcum >= samps[itime].time){ /* add in the new samples */
			/* need to calculate probability of sampling the new samples
			without replacement from the combined set of lineages
			need to remember to add to ng1 if necessary*/
			ctcum = samps[itime].time;
			lfunc += lhyper(noall,samps[itime].ns,ni,samps[itime].freq,
						gen); /* probability of getting the observed
						frequencies when dividing the lineages into
						those that come from this sample and those
						that come from the more recent genealogical
						history */
			for(j=0,ng1=0;j<noall;++j){
				gen[j] += samps[itime].freq[j];
				if(gen[j] > 0)++ng1;
			}
			ni += samps[itime].ns;
				               /* stop and calculate multinomial probs */
			++itime;
			if(itime == nsamp)cur_ne = ne; // careful about this! 15/7/09 small change here. Idea is that only if we are at last
			                               // time do we switch to ne from ne0
			if(itime > 3)printerr("probs at this point - 1"); // this is very specific for this problem! 15/7/09 - changed from 2 to 3
		}
		else if(itime > nsamp){
			printerr("itime > nsamp");
		}
		else{
			/* ng1 is the number of allelic categories that have at least
			1 lineage in them. This increases monotonically back in time because
			new lineages can be added within an allelic class, but they can
			never become less than 1 in a drift-based model*/

			if(ni == ng1) {  /* stop because prob of this path is zero */
				*izero = 1;
				return 0.0;
			}
			else if(ni < ng1)printerr("seq: ni < ng1");
			lfunc += log((double)(ni-ng1)/(ni-1.0));
			ir = disrand(1,(ni-ng1)); /* choose appropriate category in the usual way */
			for(j=0,cum=0;j<noall;++j){
				if(gen[j] < 1)continue;
				cum += gen[j]-1;
				if(ir <= cum)break;
			}
			if(gen[j] <= 1){
				printf("error\n");
				//printf("gen[j] is %d, j is %d, noall is %d, rr is %f\npcol:\n",
				//	gen[j],j,noall,rr);
				//for(j=0;j<noall;++j){
				//	printf("%f\n",pcol[j]);
				//}
				exit(1);
			}
			--gen[j];
			--ni;
		}
	}
	*return_ni = ni;
	for(j=0;j<noall;++j)return_gen[j] = gen[j];
	return lfunc;
}

double cosim(double t1,int ni,double ne)
{
	double rtf,cutoff,t2,deltat,dtop,tdash,logr,tf,rval;

	t1 = t1/Generation_time/ne;

	dtop = (ni*(ni-1)*0.5);
	tdash = -log(gfsr8())/dtop;
	tdash += t1;
	return tdash*Generation_time*ne ;

}


