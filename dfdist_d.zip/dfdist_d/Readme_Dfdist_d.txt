
note 17/9/08
------------

(no changes other than this note)

Before using this software I strongly recommend that you read 

Caballero, A., Quesada, H., Rolan-Alvarez, E. (2008) Impact of Amplified Fragment Length 
Polymorphism Size Homoplasy on the Estimation of Population Genetic Diversity and the
Detection of Selective Loci. Genetics 179: 539-554. DOI: 10.1534/genetics.107.083246

These authors assess the performance of the method and provide recommendations on its use, with 
which I agree. The authors highlight a) the need to keep control of the false discovery rate; b) 
the importance of using the 'correct' (insofar as is possible) baseline FST for the simulations. 

Concerning the false-discovery rate, I think it is worth noting that if you are, for example, 
involved in applied, clinical, or live-stock work, with money to burn, and the sole purpose 
of your research is to discover genes that are affected by selection then you can tolerate 
large FDRs because the initial scan is the starting point of further, more confirmatory, 
work. However, most of us are using programs such as dfdist to make general evolutionary 
statements about adaptive divergence in obscure species, and confirmatory experiments are more 
of a longer term aim. In which case you want to be sure that the FDR << 10%, otherwise there is
very little credibility in these statements. 

Concerning the baseline FST, I would like to reiterate the point in the note below that a good method
of model checking, is to examine the distribution of p-values from the pv2.exe program. If we accept 
the null hypothesis for the 'neutral' loci, then, if the model is good, roughly half the 'neutral' points
should be greater than/ less than the median, conditional on heterozygosity (i.e. half the p-values 
should be above/below 0.5). Furthermore, if the model is fitting well, there should be no trend in the 
proportion of p-values greater than 0.5 with increasing heterozygosity. 

note 30/1/08
------------

Some users (see also Caballero et al, Genetics, in press) have noted that the simulated distribution 
of estimates of FST from Dfdist can be systematically shifted (towards lower values of FST) from 
the distribution observed in the data, which may increase the false discovery rate, particularly 
when too liberal a critical p-value is used to assess whether a locus is an 'outlier'. 

This is primarily a consequence of asking Dfdist to simulate
data to have the same mean FST as the trimmed mean computed from the real data. This was 
introduced into Dfdist, but is not part of the Fdist program. Because the distribution across 
loci of FST estimates is skewed, if there are no true outliers, the trimmed mean will tend to always 
be lower than the true mean. Asking Dfdist to simulate data with this target mean FST implies that 
it will simulate a distribution that has a mean FST close to that target, which will be lower 
than the untrimmed mean in the data. 

The most extreme trimmed mean is the median. This was used for a version of Fdist in Beaumont and 
Balding (2004), and  appeared to perform well in comparison to a hierarchical Bayesian model (BayesFST). 
The reason the tendency for a higher false positive rate was not noted in these simulations is that very 
low critical p-values were used (alpha=0.0005), so the false discovery rate was generally low
given the number  of loci simulated, and the proportion that were under selection. I.e. if 99%
of outliers are true-positives, a doubling of the false positive rate may make little difference. However, if 
you look at the tables in this paper you can see that there is a tendency for more loci to be 
inferred to have FST above the critical limit than below.

The conclusion to be drawn from this is to use the trimmed mean with caution, but it probably 
will not have a big effect providing a sufficiently conservative critical p-value is used.
The original paper of Beaumont and Nichols (1996) suggested an iterative procedure, using the untrimmed
mean, and refitting after excluding/including outliers. The Readme to Fdist suggests making sure
that the median, conditional on heterozygosity, is matched as closely as possible. Either of
these two procedures may be preferable to the use of the trimmed mean. Certainly, as a check for consistency, 
it is probably a good idea to examine the p-values from the pv program to see that the number of p-values 
> 0.5 is similar to the number < 0.5, and to report this. 


change 15/8/07
--------------
- cured bugs in Ddatacal and Dfdist when there are missing data (i.e. when 
  not all loci are scored in all populations). There were two problems: 
  	(1) Fst was incorrectly computed (symptoms: '-100' output as an Fst 
  	value for some loci; some Fst values << -1; the average Fst reported to 
  	be >> 1)
  	(2) Additionally, in Dfdist, the program could potentially freeze and
  	not produce an output when there was missing data. 
  	
- cured bug in Dfdist in which the calculation for migration rate for a given
  Fst was only correct when the number of samples and the total number of demes 
  was the same. In other cases the migration rates were set too low (i.e. the 
  symptom would be that the output Fsts were higher than desired). The effect
  would be largest if the number of samples was 2 and the total number of demes 
  was 100, and negligible when the number of samples >> 10. 

Change 19/4/06
---------------
- cured a bug in Ddatacal which meant that you could not have more
than 1000 loci. Should now be able to have any number of loci. The other programs
(Dfdist, cplot2, pv2) are unaffected.
- binaries have been compiled under cygwin with -mno-cygwin, and so the cygwin1.dll
  has been removed (this may affect input/output if run in a cygwin xterm, but if you 
  are using cygwin you can recompile as you like). 
----------------------------------------------------------------------------------


**Note this is a draft readme to get you going. I need to write more 
extensive descriptions of exactly what the program is doing.**

Note - although superficially similar, there are large differences
between this and other versions of fdist. The data and parameter files
are incompatible between the versions, and there are many subtle differences.


This distribution contains the files
README_Dfdist
INTFILE
Dfdist_params
infile
Ddatacal.exe
cplot2.exe
pv2.exe
Dfdist.exe
cplot2.c  
Ddatacal.c  
Dfdist.c	
pv2.c
cygwin1.dll

The .exe files are pc binaries. 

The cygwin1.dll is just if you want to use the pc binaries (compiled using cygwin). You
will get faster performance with binaries compiled using intel or Borland compilers. 

The file INTFILE  contains the state of the random number generator, and
copies of it should live in the same directory as the data you are analysing.

infile and Dfdist_params describe an example data set

Dfdist - this is the simulation program. It reads a file
"Dfdist_params", which consists of 9 items. This file must only contain
numbers in the format described: 
1) Total number of demes (100 max). 
2) No of populations sampled (must be less than or equal to total number of demes).
3) Target average W&C Fst. 
4) Sample size. If this is > 0 it is then assumed the same in all populations. Otherwise
it read a sample size file "ss_file", usually generated by Ddatacal.exe.
5) Theta (=2Nmu) for the metapopulation N. 
6) The number of realisations (loci)
7, 8) The parameters for the beta prior described in Zhivotovsky (1999). 
9) The maximum allowable frequency, pooling across samples, of the commonest allele.

I recommend a minimum of 50,000 realisations. 0.25 and 0.25 seem OK for the
Zhivotovsky priors, but you may want to fiddle with this. 

If sample sizes are read into a file, then fdist will choose sizes for a particular
realisation by choosing a locus at random from among those represented in ss_file. 


Output in "out.dat". 2 columns: heterozygosity, Fst. These are calculated for dominant 
markers using the approach by Zhivotovsky (1999). A BIG change from previous versions
of Fdist is that the reported heterozygosity (but NOT FST) is the overall heterozygosity 
of the pooled sample NOT 1-fhat_1 as in previous versions of Fdist. This makes the
conditional density of Fst behave better, particularly for biallelic markers in a 
small number of subpopulations. 



Ddatacal - this program will take input from a file "infile" and give you the
heterozygosity and fst estimates for each locus in a file "data_fst_outfile",
which can then be compared with the simulation output. infile should have the
following format
1/0 indicator. alleles by rows in data matrix (1), or pops by rows (0).
No of pops
no of loci
no of alleles at locus 1
matrix of data at locus 1 either with each row corresponding to the same 
allele or to the same population. 
no of alleles at locus 2
matrix...
.
.
.
etc.

NBB - It is important to note that the null (recessive) frequency MUST appear first in
either the rows or columns of the matrix above (depending on orientation). The program 
assumes that the null homozygote frequency is read in first for any population. 

Ddatacal asks for 

* critical frequency for the most common allele (globally)
* P for trimmed mean. This attempts to get a 'good' estimate of Fst
uninfluenced by outliers. 0.3 seems a good choice.
*Parameters for beta in Zhivotovsky estimate


Ddatacal outputs information to screen (also kept in datacal_log.txt) that can 
be used for Dfdist, particularly the trimmed mean. 

Ddatacal outputs a file "data_fst_outfile", which has 4 columns: heterozygosity
calculated as in fdist above, Fst (as above), heterozygosity as 1-fhat_1 (as in previous
versions of fdist), the locus number (NBB starting at 0). The reason for the locus number 
is that some loci may not be used if their common allele is greater than the set value. 

Ddatacal produces a file "ss_file", which contains the sample size of each locus - to
be used in fdist. 


It will also produce pairwise mean fsts for pairs of populations in a file "pdist.dat".
These can then be ordinated. pdist.dat consists of one column of pairwise Fsts
corresponding to the upper triangle of a symmetric matrix in row order. The
data matrices can contain pairs of populations for which no loci were genotyped,
these should be indicated by NA.  Undefined Fsts are not included in any
averages. 

cplot2 and pv2 are different from their counterparts in previous fdist distributions
in that they do not approximate densities using Johnson curves, but use the empirical
cdf, and empirical quantiles. This is because it is now much easer (with faster)
computers to simulate many points. The Johnson distributions are fine for multi-allelic
data with many populations because the distribution of Fst is effectively continuous
whereas it is clearly discontinuous with many ties when there are only 2 alleles and 
2 populations. 

To do the approximations, both programs make bins of size Px X (number of simulated 
points from fdist - length of "out.dat") around the het/fst for each observed
locus. With Px = 0.04 and 50,000 points this is  2000 points for each observed
locus. 

cplot2 - This will calculate the conditional quantiles from the output of fdist. 
It will prompt  you for data file (e.g. "data_fst_outfile"), 
output file (any name you want), and simulated data file (e.g. "out.dat"). 
It will then prompt you for the probability level. Call this pval. It will then
prompt you for the smoothing proportion (Px above). The important point to note is
that, unlike previous versions of cplot, it will give the quantiles evaluated only
at the points corresponding to heterozygosity estimated in the original data. 
The structure of the output is as follows: the first two columns are the 
heterozygosity and fst from the data file ordered by increasing heterozygosity, then 
0.5(1-pval) quantile, median, 0.5(1+pval) quantile. The quantiles are calculated as 
by the 'quantile()' function in R.

pv2 - This will give approximate p-values for each data point. p-value  means
the probability of getting values as small as or smaller than the data point
(call this P1). Because of the ubiquity of ties when there are only two alleles 
in a pair of populations, it will also give the probability of getting values greater 
than or equal to the data point (call this P2). The total number of ties at this point
is then given by P1 + P2 -1. Also given is the more extreme of the two 
(defined as: if P1 >= 0.5, then the greater of P1 and P2; if P1 < 0.5 the lesser of 
P1 and P2) - call this P3. I favour this latter as the quotable 'p-value', since it 
is the most conservative in the presence of ties).
The program will prompt you for data file (e.g. "data_fst_outfile"), output file 
(any name you want), and simulated data  file (e.g. "out.dat").
The structure of the output is sample het, sample fst, P1, P2, P3. 

To run example data
(1) Double click on Ddatacal.exe - This will produce the observed Fst and
heterozygosities in "data_fst_outfile")
(1) Double click on Dfdist.exe. Wait for it to stop.
(2) Double click on cplot2.exe. Follow prompts, (save output in e.g. "cout.txt")
(3) You can then visualize cout.txt in your favourite plotting program.
(4) Double click on pv. Follow prompts (save output in e.g. "pvout.txt")
(5) Inspect the p-values in pvout.txt.

Example R script for plotting this is 

m2 <- read.table("data_fst_outfile")
m3 <- read.table("pvout.txt")
m4 <- read.table("cout.txt")
lo <- m3[,5] < 0.005
hi <- m3[,5] > 0.995
plot(m3[,1],m3[,2],ylim=c(-0.05,1),xlim=c(0,0.6),xlab="heterozygosity",ylab= expression(F[ST]))
lines(m4[,1],m4[,3])
lines(m4[,1],m4[,4])
lines(m4[,1],m4[,5])
points(m3[,1][hi],m3[,2][hi],col="red",pch=16)
points(m3[,1][lo],m3[,2][lo],col="blue",pch=16)
text(m3[,1][hi],m3[,2][hi],as.character(m2[,4][hi]+1),pos=4,cex=0.6)
text(m3[,1][lo],m3[,2][lo],as.character(m2[,4][lo]+1),pos=4,cex=0.6)


A unix vs. windows problem is that the window disappears the
instant a program stops. I've put in an ad hoc prompt in datacal and
fdist2 to stop this happening if the program runs normally, because
these programs type out informative messages. However if the program dies
with an error message you won't see the message. In which case it may be better
to run the program from the dos prompt. 

