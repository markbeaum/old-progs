#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "myutil.h"

int main(int argc,char *argv[])
{
	FILE *inp,*out,*out2;
	int k,j,noall,freq[100],val[100],sfreq[100],totsize,ss,cumsum,ic,i,
		ofreq[100],nloc,sst;
		
	if(argc < 2)printerr("what file do you want to sample from?");
	opengfsr();
	inp = fopen(argv[1],"r");
	if(inp == NULL)printerr("can't find file");
	out = fopen("sampfile","w");
	out2 = fopen("remainderfile","w");
	printf("give sample size   ");
	scanf("%d",&sst);
	
	fscanf(inp,"%d",&nloc);
	fprintf(out,"%d\n",nloc);
	fprintf(out2,"%d\n",nloc);
	for(k=0;k<nloc;++k){
	ss = sst;
	fscanf(inp,"%d",&noall);
	totsize = 0;
	for(j=0;j<noall;++j){
		fscanf(inp,"%d",&freq[j]);
		ofreq[j] = freq[j];
		totsize += freq[j];
	}
	for(j=0;j<noall;++j)fscanf(inp,"%d",&val[j]);
	
	if(ss >= totsize){
		printf("locus %d: requested size larger than actual"
			" size - using actual size\n",k+1);
		ss = totsize;
	}
	for(j=0;j<noall;++j)sfreq[j] = 0;
	for(i=0;i<ss;++i){
		ic = disrand(0,totsize-i-1);
		cumsum = 0;
		for(j=0;j<noall;++j){
			cumsum += freq[j];
			if(ic < cumsum){
				++sfreq[j];
				--freq[j];
				if(freq[j] < 0)printerr("freq[j] < 0");
				break;
			}
		}
		if(j==noall)printerr("fallen through loop");
	}
	fprintf(out,"%d\n",noall);
	for(j=0;j<noall;++j){
		fprintf(out,"%4d ",sfreq[j]);
	}
	fprintf(out,"\n");
	for(j=0;j<noall;++j){
		fprintf(out,"%4d ",val[j]);
	}
	fprintf(out,"\n");
	
	
	fprintf(out2,"%d\n",noall);
	for(j=0;j<noall;++j){
		fprintf(out2,"%4d ",ofreq[j] - sfreq[j]);
	}
	fprintf(out2,"\n");
	for(j=0;j<noall;++j){
		fprintf(out2,"%4d ",val[j]);
	}
	fprintf(out2,"\n");
	
	}/*end of locus loop */
	
	printf("finished\n");
	closegfsr();
}
	
