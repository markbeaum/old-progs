HISTORY
-------

Original windows executable compiled with mingw in june 2002.
Recompiled june 2004 with Borland C++. This necessitated a small change in the
code to cope with Borland fp system (to make it ieee compliant). Also a bug in
printerr2 in myutil.c (opening already open files) was corrected.

Rough draft readme updated June 2004.


README

14 June 2002.
Updated 30 June 2004

This needs to be read in conjunction with the readme for msvar0.4.x

The basic structure of the program is the same. The parameterisation is however
now in terms of the effective sizes and times etc rather than the scaled
parameters, theta, r, and tf

Run it in a similar way to msvar0.4.x.

The program now outputs
a new file called hpars.dat, which has the following columns

1 output line number
2 (ignore)
3 Total log likelihood (over all loci)
4 mean current population size (over loci)
5 variance (among loci) of current population size
6 mean ancestral population size
7 variance of ancestral population size
8 mean mutation rate
9 variance in mutation rate
10 mean time (in years) since population started to decline/expand
11 variance of time since population started to decline/expand

It is these parameters that you are going to want to report. The parameters for
the individual loci are in out1..n as before. In these files the demographic
parameters will vary between loci because, this time, the model is assuming that
there is some variation in each parameter among loci (your prior for the amount
of this can be set in the parameter file). In principle, you could detect
selection if one locus is behaving wildly differently from the others for e.g.
growth rate.

So, to summarise, each out1..n file contains:
line number
number of mutations
tmrca
log10(N0) for that locus
log10(N1) for that locus
log10(mu) for that locus
log10(tfa) for that locus
log likelihood
proportion of mutations in terminal lineages
proportion of total tree size in terminal lineages
proportion of coalescences in ancestral pop

NBB don't expect the 'means' and 'variances' in hpars to be exactly the same as
those calculated across out1..outn - the latter are assumed to be
random draws from distributions with means and variances given in hpars.


The init_v_file is changed. It has the following structure
number of 'turns' of the random number generator
ploidy number
generation time
starting values for current size for all loci
starting values for ancestral size for all loci
starting values for mutation rate for all loci
starting values for time since decline/expansion for all loci
indicators (0,1) whether to update values of these parameters.
Starting values for prior mean and variance for current size
..... ancestral size
..... mutation rate
..... time
hyperprior mean and variance for means and variances for:
ancestral size
current size
mutation rate
time since decline/expansion
An indicator as in msvar0.4.x - 0=linear growth; 1=exponential
number of lines of output
number of iterations between lines of output (example gives 10000,
but you will probably want this 10 or 100 times larger to get good convergence
with large numbers of loci or sample sizes).


Further points to note
----------------------

There is an arbitrary upper limit on the events in a genealogy set at 1995
(events = no mutations + sample size -1). Any trial update that makes it bigger
than that is not accepted (think of it as a prior on the number of mutations
permissable). This is done just because it is computationally convenient to set
at the outset the maximum 'size' of the genealogy, and 2000 seems a reasonable
number.

**If this limit is reached when setting up the initial genealogy at the start of
the run, the program stops. Otherwise if it reaches it as part of a trial update
it just doesn't accept the update and the program continues to run. Generally
this latter is a rare occurence - most problems occur at the beginning because
of the setting of the initial parameter values.

**To solve the problem if it occurs right at the beginning, you just need to set
the initial values to something that won't give initial genealogies with too
many mutations (e.g. just keep adding an extra 0 to the mutation rates for each
locus until the problem goes away).



