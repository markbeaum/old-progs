/* This program performs a Hierarchical Bayesian analysis using multilocus
microsatellite data to infer population growth and decline


*/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef __BORLANDC__
	#include <float.h>
#endif
#include "myutil.h"

#define M_LOG10E        0.43429448190325182765

/* original set */
#define MUTLIN_ADD_P 0.1
#define MUTLIN_DEL_P 0.1
#define MUTNODE_ADD_P 0.2
#define MUTNODE_DEL_P 0.2
#define ESWAP_PROB  0.2 
#define LSWAP_PROB  0.2 
#define CUM_MUTLIN_DEL_P 0.2
#define CUM_MUTNODE_ADD_P 0.4
#define CUM_MUTNODE_DEL_P 0.6
#define CUM_ESWAP_PROB 0.8
#define CUM_LSWAP_PROB 1.0

#define MCONS 12

struct node{
	int val;
	int val2;
	int type;   /* 0=sample,1=mutation,2=coalescence,3=ancestor */
	double time;
	double time2;
	int nlin;
	int nlin2;
	int pos;
	struct cnode *cp;
	int mark;
	int lno;
	int lno2;
	int linswap;
	int linswap2;
	int evswap;
	int evswap2;
	struct node *tlr;
	struct node *tlr2;
	struct node *tlf;
	struct node *tlf2;
	struct node *a;
	struct node *a2;
	struct node *dl;
	struct node *dl2;
	struct node *dr;
	struct node *dr2;
};


typedef struct node Node;

struct cnode{
	Node *p;
	Node *u;
	Node *u2;
	Node *l;
	Node *l2;
	Node *r;
	Node *r2;
	Node *tf;
	Node *tf2;
	Node *tr;
	Node *tr2;
	int mlin[3][3];
	int mlin2[3][3];
	int linmut[2];
	int linmut2[2];
	int nodemut;
	int nodemut2;
	double nwt;
	double nwt2;
	double lwt[2];
	double lwt2[2];
	int cpos;
	int mark[2];
};
	
typedef struct cnode Cnode;

struct hierpars{
	double ln0mean;
	double ln0var;
	double ln1mean;
	double ln1var;
	double lmumean;
	double lmuvar;
	double ltfamean;
	double ltfavar;

	double ln0mean2;
	double ln0var2;
	double ln1mean2;
	double ln1var2;
	double lmumean2;
	double lmuvar2;
	double ltfamean2;
	double ltfavar2;
	
	double ln0mm;
	double ln0mv;
	
	double ln0vm;
	double ln0vv;
	
	double ln1mm;
	double ln1mv;
	
	double ln1vm;
	double ln1vv;
	
	double lmumm;
	double lmumv;
	
	double lmuvm;
	double lmuvv;
	
	double ltfamm;
	double ltfamv;
	
	double ltfavm;
	double ltfavv;
	
	double prior;
	double prior2;


};

typedef struct hierpars Hierpars;

struct genpars{
	int evswap_indic;
	int evswap_indic2;
	int linmut_indic;
	int linmut_indic2;
	int nodemut_indic;
	int nodemut_indic2;
	int linswap_indic;
	int linswap_indic2;
	double nwt_tot;
	double nwt_tot2;
	double lwt_tot;
	double lwt_tot2;
	double nwt_max;
	double nwt_max2;
	double lwt_max;
	double lwt_max2;
	double pspace;
	double pspace2;
	double tpf;
	double tpr;
	double lik;
	double lik2;
	
	double theta;
	double theta2;
	double r;
	double r2;
	double tf;
	double tf2;
	
	
	int which_model;
	
	
	double n0;
	double n0_2;
	double n1;
	double n1_2;
	double mu;
	double mu2;
	double gen;
	double gen2;
	double tfa;
	double tfa2;
	
	Node *base;
	double prior;
	double prior2;
	double pplus;
	double pplus2;
	int sno ;
	
};

typedef struct genpars Genpars;

struct Gplist{
	int keeptime;
	int keepn0;
	int keepn1;
	int keepmu;
	int keeptfa;
	int keeppplus;
	int scale_r;
	int scale_tf;
	int tfuni;
	double dd;
	double ppval;
};

void twidpars_var(struct Gplist *ptlist,Genpars *pars,Hierpars *hpars);
void untwidhpars(Hierpars *hpars);
double twidhpars(struct Gplist *ptlist,Hierpars *hpars);
void copyhpars(Hierpars *hpars);
void inithpars(Hierpars *hpars);
void treesummary(int nn,Genpars *pars,Node **list,double *above, double
*mutbc, double *blpc);
void choosepar(struct Gplist *ptlist,Hierpars *hpars,int oneonly,
int *mtype) ;
void copypars(Genpars *pars);
void priorcalc(Genpars *pars,Hierpars *hpars);
void hpriorcalc(Hierpars *hpars);
void twidpars(struct Gplist *ptlist,Genpars *pars,Hierpars *hpars,int doprior);
void untwidpars(Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars);
double boundcheck(double l1,int nn,Genpars *pars,Hierpars *hpars);
void initpars(Genpars *pars,int j);
void fillpars(Genpars *pars);
double lwt_cal(Node *pp,int irl);
double nwt_cal(Node *pp);
double rejprob(Node *pp,int nc);
double tdens(double t1,double t2,int nl,double theta,double r,double tf,int which_model);
double tdensL(double t1,double t2,int nl,double theta,double r,double tf);
double tdensE(double t1,double t2,int nl,double theta,double r,double tf);
double cosim(double t1,int ni,double rval,double tf,int which_model);
double cosimL(double t1,int ni,double rval,double tf);
double cosimE(double t1,int ni,double rval,double tf);
void assimlin(Cnode *cpt,int vec[],int lr);
void linswap(Node **list,int nn,Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars);
double lik_cal(Node *pt,Node *out,Genpars *pars);
double lik_calL(Node *pt,Node *out,Genpars *pars);
double lik_calE(Node *pt,Node *out,Genpars *pars);
void proptchange(struct Gplist *ptlist,Genpars *pars,Cnode *clist,Node **mlist,int *mm,
	Cnode **cmlist,int *cmm);
void tchange(Genpars *pars,Cnode *clist,Node **mlist,int *mm,Cnode **cmlist,int *cmm);
int swapable(Node *p);
void eventswap(Node **list,int nn,Node **mlist,int *mm,Cnode **cmlist,int *cmm,
	Genpars *pars);
int cal_nodeprob(int mlin[3][3],int indic);
int cal_linprob(int mlin[3][3],int rl);
int findinclist(Node *pp);
void checktree(Node *pt,int ulim,int sno,Cnode *clist,int nc,Genpars *pars,int ismark);
void read_data(int ***freq,int ***val, int **noall,int *nloc,int **sums);
void fill_tree(Node **list,int *freq,int *val,int noall,int sno,int *nn,int
	*nc,Cnode *clist,Genpars *pars);
void fill_tree_old(Node **list,int *freq,int *val,int noall,int sno,int *nn,int
	*nc,Cnode *clist,Genpars *pars);
void getevent(double t0,int nlin, int *event_type,double *event_time,Genpars *pars);
Node *mutate(Node **list,int *nn,Node *n1,double tt,int mutval,int lno);
Node *coalesce(Node **list,int *nn,Node *n1,Node *n2,double tt);
void twiddle(Node **list,int *oldnn, int *nn, Cnode *clist,int nc,Node **mlist,
	int *mm,Cnode **cmlist,int *cmm,int *mtype,
	Genpars *pars);
void mutlin_add2(Node **list,int *nn, Cnode *clist,int nc,Node **mlist,int *mm,
	Cnode **cmlist,int *cmm,Genpars *pars);
void mutlin_del2(Node **list,int *nn, Cnode *clist,int nc,int *ifail,Node **mlist,
	int *mm,Cnode **cmlist,int *cmm,
	Genpars *pars);
void mutnode_add3(Node **list,int *nn, Cnode *clist,int nc,Node **mlist,int *mm,
	Cnode **cmlist,int *cmm,int *mtype,Genpars *pars);
void mutnode_del3(Node **list,int *nn, Cnode *clist,int nc,int *ifail,Node **mlist,
	int *mm,Cnode **cmlist,int *cmm,int *mtype,
	Genpars *pars);
Node *insertmut(Node **list,int *nn,double mt1,Node *pt,int mutval,
	Node **mlist,int *mm,int lno);
void deletemut(Node *pp,Node **list,int *nn,Node **mlist,int *mm);
Node *cfind_down(Node *pt,int indic);
Node *cfind_up(Node *pt,int *rl);
void markup(Node *pt,char *str,Node *target,Node **mlist,int *mm);
void cmarkup(Cnode *pt,char *str,Cnode *target,Cnode **cmlist,int *cmm);
int make_mark(int mark,int val);
int inside(int ic,int mark);
void untwiddle(Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars,int *nn,int oldnn);
void restore(Node *pp);
void crestore(Cnode *pp);
int decomp(int *mark);
void resit(Node *pp,int ic);
void cresit(Cnode *pp,int ic,int ip);
void accept(Node **mlist,int *mm,Cnode **cmlist,int *cmm);
Node *getmnode(Node *pp,char *ss,int val);
double log_normdev(double x,double mu,double s);
int linswap_cal(Node *p1);
double normdev(double x,double mu,double s);
double lndev(double x,double mu,double s);
void read_params();


int CHeck=0;

int Mod_type;
int Itno;
double Init_n0[100],Init_n1[100],
		Init_mu[100],Init_gen,Init_tfa[100];
double Init_ln0mean,Init_ln0var,Init_ln1mean,Init_ln1var,
       Init_lmumean,Init_lmuvar,Init_ltfamean,Init_ltfavar,
       Init_ln0mm,Init_ln0mv,Init_ln0vm,Init_ln0vv,
       Init_ln1mm,Init_ln1mv,Init_ln1vm,Init_ln1vv,
       Init_lmumm,Init_lmumv,Init_lmuvm,Init_lmuvv,
       Init_ltfamm,Init_ltfamv,Init_ltfavm,Init_ltfavv;
       
int Thin;
int Nloc;
double Usum[10];


Node **Block;
FILE *checkout;

#ifdef __MWERKS__
int MTspeed = 500;
float MaxMTspeed = 10000.0;
float MinMTspeed = 25.0;
#endif
int Illegal;
int Ploidy;
int PredictDiffpair_tot,PredictNode3_tot,PredictCswaptot,PredictEswaptot;
double PredictPspace;
int main(void)
{
	Node **list[50],**mlist[50];
	Cnode *clist[50],**cmlist[50];
	Genpars *pars[50],realpars[50];
	Hierpars *hpars,realhpars;
	int j,k,i,**freq,**val,*noall,*sno,nloc,nn[50],nc[50],iter,mm[50],cmm[50],
		oldnn[50],mtype,mtlist[30],mplist[30],mtypecount,
		twidtheta;
	double l1,likold,liknew,ldiff,ldiff2,tdiff,pdiff,mutbc,above,blpc;
	double Scale2=100.0;
	int rcheck;
	double lcheck1,lsum;
	int iloc,counter;
	FILE *lfile[50],*mpout,*hfile;
	char fstring[50][10],ncharstr[100];
	struct Gplist ptlist;
	double hsucc=0.0,htot=0.0;
	
	int oneonly,bl,ul;
	
	#ifdef __BORLANDC__

	_control87(MCW_EM,MCW_EM);

	#endif



	opengfsr();
	
	read_data(&freq,&val,&noall,&nloc,&sno);
	Nloc = nloc;
	read_params();
	
	for(j=0;j<nloc;++j){
		sprintf(ncharstr,"%d",j+1);
		strcpy(fstring[j],"out");
		lfile[j] = fopen(strcat(fstring[j],ncharstr),"w");
	}
	hfile = fopen("hpars.dat","w");

	Block = (Node **)malloc(nloc*sizeof(Node *));
	for(j=0;j<nloc;++j)Block[j] = (Node *)malloc(2000*sizeof(Node));



	for(j=0;j<nloc;++j)pars[j] = &realpars[j];
	hpars = &realhpars;
	
	
	for(j=0;j<nloc;++j)list[j] = (Node **)malloc(2000*sizeof(Node *));
	for(j=0;j<nloc;++j)mlist[j] = (Node **)malloc(2000*sizeof(Node *));
	
	for(j=0;j<30;++j){mtlist[j] = 0;mplist[j] = 0;}
	mtypecount = 0;
	
	
	
	for(k=0;k<nloc;++k){
		for(j=0;j<2000;++j){
			list[k][j] = &Block[k][j];
		}
	}
	
	for(j=0;j<nloc;++j){pars[j]->sno = sno[j];}
	for(j=0;j<nloc;++j)clist[j] = (Cnode *)malloc((sno[j]-1)*sizeof(Cnode));
	for(j=0;j<nloc;++j)cmlist[j] = (Cnode **)malloc((sno[j]-1)*sizeof(Cnode *));
	
	
	for(j=0;j<nloc;++j)initpars(pars[j],j);
	
	inithpars(hpars);
	
	for(j=0;j<nloc;++j)fill_tree(list[j],freq[j],val[j],
		noall[j],sno[j],&nn[j],&nc[j],clist[j],pars[j]);
	for(j=0;j<nloc;++j)checktree(list[j][0],nn[j],sno[j],clist[j],nc[j],pars[j],0);
		
	for(j=0;j<nloc;++j)pars[j]->base = list[j][0];
	for(j=0;j<nloc;++j)priorcalc(pars[j],hpars);
	hpriorcalc(hpars);
	hpars->prior2 = hpars->prior;
	for(j=0;j<nloc;++j)pars[j]->prior2 = pars[j]->prior;
	likold = 0.0;
	for(j=0;j<nloc;++j)likold += lik_cal(list[j][0]->tlf,NULL,pars[j]);
	
	for(j=0;j<nloc;++j)cmm[j] = mm[j] = 0;
	counter = 0;
	
	#ifdef __MWERKS__
	firstime = clock()/(3600.0*CLOCKS_PER_SEC);	
	itcounter = 100;
	firstiter = 0;
	itdiff = Itno/100;
	itcounter = itdiff;
	#endif
	printf("starting MCMC\n");
	for(iter=0;iter<Thin;++iter){
		Illegal = 0;
		if(counter == Itno)break;
	
		#ifdef __MWERKS__
		if((Rk++)%MTspeed==0)MyEventLoop(&MyTick);
		if((iter+1) == itcounter){
			ruptime = clock()/(3600.0*CLOCKS_PER_SEC);
			printf("iter is %d      running for %f hours\n",iter+1,ruptime-firstime);
			togo = Itno-iter;
			idone = iter-firstiter;
			estogo = (ruptime-firstime)/idone*togo;
			printf("estimate %f hours to go\n",estogo);
			itcounter = itcounter+itdiff;
		}
		#endif
		
		if((iter+1)%500 == 0)rcheck = 1;
		else rcheck = 0;
		twidtheta = 0; /* change G */
		if(gfsr8() < 0.01)twidtheta = 1; /* change params for one locus
										without changing hierarchical params */
		else if(gfsr8() < 0.01)twidtheta = 2; /* change params for all loci and
		                                       change prior mean */
		else if(gfsr8() < 0.01)twidtheta = 3; /* Change params for all loci and 
										change prior variance*/
		iloc = disrand(0,nloc-1);
		if(twidtheta == 1){ /* change params for one locus
										without changing hierarchical params */
			choosepar(&ptlist,hpars,1,&mtype); /* This determines
						type of updates for mutation and demographic
						parameters. */
			pars[iloc]->lik2 = lik_cal(pars[iloc]->base->tlf,
				NULL,pars[iloc]);
			copypars(pars[iloc]);
			
			twidpars(&ptlist,pars[iloc],hpars,0);
			if(!ptlist.keeptime)
				tchange(pars[iloc],clist[iloc],mlist[iloc],&mm[iloc],
					cmlist[iloc],&cmm[iloc]);
			
			if((CHeck || rcheck)){
				checktree(list[iloc][0],nn[iloc],sno[iloc],clist[iloc],
					nc[iloc],pars[iloc],1);
			}

			pars[iloc]->lik = lik_cal(pars[iloc]->base->tlf,
												NULL,pars[iloc]);
			
			priorcalc(pars[iloc],hpars);
			
			pdiff = ldiff = tdiff = 0.0;
			pdiff += pars[iloc]->prior - pars[iloc]->prior2;
			
			ldiff += pars[iloc]->lik-pars[iloc]->lik2;
			tdiff += pars[iloc]->tpr - pars[iloc]->tpf;

			if(mtype == 22 && fabs(ldiff) > 0.00001){
				printf("probs with mtype = 22; ldiff is %f\n",ldiff);
			}
		}
		else if(twidtheta == 2){
			choosepar(&ptlist,hpars,0,&mtype); /* This determines
						type of updates for mutation and demographic
						parameters. */
			for(j=0;j<nloc;++j)pars[j]->lik2 = lik_cal(pars[j]->base->tlf,
				NULL,pars[j]);
			for(j=0;j<nloc;++j)copypars(pars[j]);
			copyhpars(hpars);
			
			/* if we are changing all of them need to change prior means, 
			   but only want to set it once - so do it for the first */
			for(j=0;j<nloc;++j)twidpars(&ptlist,pars[j],hpars,j==0 ? 1 : 0);
			if(!ptlist.keeptime)
				for(j=0;j<nloc;++j)tchange(pars[j],clist[j],mlist[j],&mm[j],
					cmlist[j],&cmm[j]);
			
			if((CHeck || rcheck)){
				for(j=0;j<nloc;++j)checktree(list[j][0],nn[j],sno[j],clist[j],
					nc[j],pars[j],1);
			}

			for(j=0;j<nloc;++j)pars[j]->lik = lik_cal(pars[j]->base->tlf,
												NULL,pars[j]);
						
			/* the reason for this is that when we change all loci, we change
			the prior mean, and so everything should be the same */
			
			for(j=0;j<nloc;++j)priorcalc(pars[j],hpars);

			pdiff = ldiff = tdiff = 0.0;
			for(j=0;j<nloc;++j)pdiff += pars[j]->prior - pars[j]->prior2;
			if(fabs(pdiff) > 0.00001)printerr("main: abs(pdiff) too "
												"large");
			hpriorcalc(hpars);
			pdiff += hpars->prior - hpars->prior2;
			
			for(j=0;j<nloc;++j)ldiff += pars[j]->lik-pars[j]->lik2;
			for(j=0;j<nloc;++j)tdiff += pars[j]->tpr - pars[j]->tpf;

			if(mtype == 22 && fabs(ldiff) > 0.00001){
				printf("probs with mtype = 22; ldiff is %f\n",ldiff);
			}
		}
		else if(twidtheta == 3){
			++htot;
			for(j=0;j<nloc;++j)pars[j]->lik2 = lik_cal(pars[j]->base->tlf,
				NULL,pars[j]);
			for(j=0;j<nloc;++j)copypars(pars[j]);
			copyhpars(hpars);
			/*this is because it's not done in copyhpars*/
			for(j=0;j<nloc;++j)pars[j]->prior2 = pars[j]->prior;
			tdiff = twidhpars(&ptlist,hpars);
			
			for(j=0;j<nloc;++j)twidpars_var(&ptlist,pars[j],hpars);
			if(!ptlist.keeptime)
				for(j=0;j<nloc;++j)tchange(pars[j],clist[j],mlist[j],&mm[j],
					cmlist[j],&cmm[j]);
			
			if((CHeck || rcheck)){
				for(j=0;j<nloc;++j)checktree(list[j][0],nn[j],sno[j],clist[j],
					nc[j],pars[j],1);
			}

			for(j=0;j<nloc;++j)pars[j]->lik = lik_cal(pars[j]->base->tlf,
												NULL,pars[j]);
			
			
			
			
			for(j=0;j<nloc;++j)priorcalc(pars[j],hpars);
			pdiff = ldiff = 0.0; /*tdiff initialised in twidhpars */
			for(j=0;j<nloc;++j)pdiff += pars[j]->prior - pars[j]->prior2;
			hpriorcalc(hpars);
			pdiff += hpars->prior - hpars->prior2;
			
			for(j=0;j<nloc;++j)ldiff += pars[j]->lik-pars[j]->lik2;
			for(j=0;j<nloc;++j)tdiff += pars[j]->tpr - pars[j]->tpf;
		}
		else{
			if(!(mm[iloc] == 0 && cmm[iloc] == 0))printerr("main: mm/cmm != 0");
			twiddle(list[iloc],&oldnn[iloc],&nn[iloc],clist[iloc],nc[iloc],mlist[iloc],&mm[iloc],
			cmlist[iloc],&cmm[iloc],&mtype,pars[iloc]);
			if(!Illegal && (CHeck || rcheck))checktree(list[iloc][0],nn[iloc],sno[iloc],clist[iloc],nc[iloc],
				pars[iloc],1);

			pdiff = 0.0;
			ldiff = pars[iloc]->lik-pars[iloc]->lik2;
			tdiff = pars[iloc]->tpr - pars[iloc]->tpf;
		}
		if(CHeck && !Illegal){
			liknew = 0.0;
			for(j=0;j<nloc;++j)liknew += lik_cal(list[j][0]->tlf,NULL,pars[j]);
			ldiff2 = liknew - likold;
			if(fabs(ldiff-ldiff2) > 1.0e-9){
				printf("mtype is %d\n",mtype);
				printerr("main: ldiff wrong");
			}
		}
		l1 = ldiff + tdiff + pdiff; 
		for(j=0;j<nloc;++j)l1 = boundcheck(l1,nn[j],pars[j],hpars); 
		if(mtype >= 0 && mtype <= 30){
			++mtlist[mtype];
			++mtypecount;
		}
		if(!Illegal && ( l1 >= 0.0 || (l1 > -15.0 && gfsr8() < exp(l1)) )){
			if(mtype >= 0 && mtype <= 30){
				++mplist[mtype];
			}
			if(twidtheta == 0){
				accept(mlist[iloc],&mm[iloc],cmlist[iloc],&cmm[iloc]);
				if(CHeck || rcheck)checktree(list[iloc][0],nn[iloc],sno[iloc],
					clist[iloc],nc[iloc],pars[iloc],0); 
			}
			else if(twidtheta == 1){
				accept(mlist[iloc],&mm[iloc],cmlist[iloc],&cmm[iloc]);
			}
			else for(j=0;j<nloc;++j)accept(mlist[j],&mm[j],cmlist[j],&cmm[j]);
			if(CHeck)likold = liknew;
			if(twidtheta == 3)hsucc += 1.0;
		}
		else{
			if(twidtheta == 0){
				untwiddle(mlist[iloc],&mm[iloc],cmlist[iloc],&cmm[iloc],pars[iloc],
					&nn[iloc],oldnn[iloc]);
				if(mtype == 0 || CHeck || rcheck)
					checktree(list[iloc][0],nn[iloc],sno[iloc],clist[iloc],nc[iloc],pars[iloc],0);
			}
			else  if(twidtheta == 1){
				untwidpars(mlist[iloc],&mm[iloc],cmlist[iloc],
					&cmm[iloc],pars[iloc]);
			}
			else if(twidtheta == 2){
				untwidhpars(hpars);
				for(j=0;j<nloc;++j)untwidpars(mlist[j],&mm[j],cmlist[j],&cmm[j],pars[j]);
			}
			else {
				untwidhpars(hpars);
				for(j=0;j<nloc;++j)pars[j]->prior = pars[j]->prior2;
				for(j=0;j<nloc;++j)untwidpars(mlist[j],&mm[j],cmlist[j],&cmm[j],pars[j]);
			}
			mtype = 0;
		}
		
		if((iter+1)%Thin == 0){
			++counter;iter=0;
			if(counter%10 == 0){
				mpout = fopen("mtype.dat","w");
				for(j=0;j<30;++j){
					fprintf(mpout,"%d %f %f\n", j,
					(double)mtlist[j]/mtypecount,
						mtlist[j] > 0 ? (double)mplist[j]/mtlist[j] : -1.0);
				}
				for(j=0;j<30;++j){mtlist[j] = 0;mplist[j] = 0;}
				mtypecount = 0;
				fclose(mpout);
			}
				
			lsum = 0.0;
			for(j=0;j<nloc;++j){
				lcheck1 = lik_cal(pars[j]->base->tlf,NULL,pars[j]);
				lsum += lcheck1;
   				treesummary(nn[j],pars[j],list[j],&above,&mutbc,&blpc);
				fprintf(lfile[j],"%d %d %e %f %f %f %f %f %f %f %f\n",counter,
				nn[j]-(sno[j] + nc[j]),clist[j][nc[j]-1].p->time,log10(pars[j]->n0),
				log10(pars[j]->n1),log10(pars[j]->mu),log10(pars[j]->tfa),lcheck1,
				mutbc,blpc,above);
			}
			fprintf(hfile,"%d %f %f %f %f %f %f %f %f %f %f\n",
				counter,hsucc/htot,lsum,hpars->ln0mean,hpars->ln0var,hpars->ln1mean,
				hpars->ln1var,hpars->lmumean,hpars->lmuvar,hpars->ltfamean,
				hpars->ltfavar);
			hsucc = htot = 0.0;
			if(counter%10 == 0){
				for(j=0;j<nloc;++j)fflush(lfile[j]);
				fflush(hfile);
				closegfsr();
			}
		}
	}
	
	closegfsr(); 

}


 void treesummary(int nn, Genpars *pars,Node **list,double *above, double
 *mutbc,double *blpc)
{
	Node *pp,*pt;
	int mutno=0,coalno=0,cmutno=0,cabove=0,j,nm1;
	double tsum1,tsuma;
	pp = pars->base->tlf;
	while(pp != NULL){
		if(pp->type == 0)printerr("treesummary: pp->type == 0");
		if(pp->type == 1){
			++mutno;
			if(coalno == 0)++cmutno;
		}
		if(pp->type == 2){
			++coalno;
			if(pp->time >= pars->tf)++cabove;
		}
		pp = pp->tlf;
	}
/*	*mutbc = cmutno/(double)mutno;*/
	*above = cabove/(double)coalno;
 	
	tsum1 = 0.0;
	nm1 = 0;
	for(j=0;j<pars->sno;++j){
		pt = list[j]->a;
		while(1){
			if(pt->type == 2)break;
			++nm1;
			pt = pt->a;
		}
		tsum1 += pt->time;
	} 
	tsuma = 0.0;
	for(j=pars->sno;j<nn;++j){
		if(list[j]->type != 2)continue;
		tsuma += 2.0*list[j]->time - list[j]->cp->l->time - 
					list[j]->cp->r->time;
	}

 	if(mutno > 0)*mutbc = nm1/(double)mutno;
	else *mutbc = -1.0;
 	*blpc = tsum1/tsuma;
 	
	return;
	
}



double boundcheck(double l1,int nn,Genpars *pars,Hierpars *hpars)
{
	if(nn > 1995 )l1 = -20.0;
	if(hpars->ln0var <= 0.0 || hpars->ln1var <= 0.0 || hpars->lmuvar <= 0.0 ||
		hpars->ltfavar <= 0.0)l1 = -20.0;
	return l1;
}



void read_params()
{
	double up[10],sum;
	FILE *initf;
	int ic,j,kn0,kn1,kmu,ktfa,turno;
	float ftest;
	
	up[0] = 0.1;up[1] = 0.1;up[2] = 0.4;up[3] = 0.1;up[4] = 0.1;up[5] = 0.1,up[6] = 0.1;
	
	initf = fopen("init_v_file","r");
	if(initf == NULL)printerr("no init_v_file");
	fscanf(initf,"%d",&turno);
	if(turno < 0)turno = 0;
	if(turno > 100000000)printerr("turno too big");
	for(j=0;j<turno;++j)intrand();
	ic = 0;
	ic += fscanf(initf,"%d",&Ploidy);
	if(Ploidy <= 0)printerr("ploidy is wrong");
	if(Ploidy > 2)printf("Warning: ploidy is greater than 2 - "
	"is this reasonable?\n");
	ic += fscanf(initf,"%lf",&Init_gen);
	for(j=0;j<Nloc;++j)ic += fscanf(initf,"%lf",&Init_n0[j]);
	for(j=0;j<Nloc;++j)ic += fscanf(initf,"%lf",&Init_n1[j]);
	for(j=0;j<Nloc;++j)ic += fscanf(initf,"%lf",&Init_mu[j]);
	for(j=0;j<Nloc;++j)ic += fscanf(initf,"%lf",&Init_tfa[j]);
	ic += fscanf(initf,"%d %d %d %d",&kn0,&kn1,&kmu,&ktfa);
	
	if(kn0){
		up[2] = 0.0;
	}
	if(kn1){
		up[0] = 0.0;
		up[2] = 0.0;
		up[3] = 0.0;
		up[4] = 0.0;
	}
	if(kmu){
		up[0] = 0.0;
		up[1] = 0.0;
		up[2] = 0.0;
		up[4] = 0.0;
		up[5] = 0.0;
	}
	if(ktfa){
		up[1] = 0.0;
		up[2] = 0.0;
		up[4] = 0.0;
		up[6] = 0.0;
	}
	sum = 0.0;
	for(j=0;j<7;++j)sum += up[j];
	if(sum <= 0.000001){
		for(j=0;j<7;++j)Usum[j] = 0.0;
	}
	else{
		for(j=0;j<7;++j)up[j] /= sum;
		Usum[0] = up[0];
		for(j=1;j<7;++j)Usum[j] = Usum[j-1] + up[j];
	}
	
	ic += fscanf(initf,"%lf %lf",&Init_ln0mean,&Init_ln0var);
	ic += fscanf(initf,"%lf %lf",&Init_ln1mean,&Init_ln1var);
	ic += fscanf(initf,"%lf %lf",&Init_lmumean,&Init_lmuvar);
	ic += fscanf(initf,"%lf %lf",&Init_ltfamean,&Init_ltfavar);
	
	ic += fscanf(initf,"%lf %lf %lf %lf",&Init_ln0mm,&Init_ln0mv,&Init_ln0vm,&Init_ln0vv);
	ic += fscanf(initf,"%lf %lf %lf %lf",&Init_ln1mm,&Init_ln1mv,&Init_ln1vm,&Init_ln1vv);
	ic += fscanf(initf,"%lf %lf %lf %lf",&Init_lmumm,&Init_lmumv,&Init_lmuvm,&Init_lmuvv);
	ic += fscanf(initf,"%lf %lf %lf %lf",&Init_ltfamm,&Init_ltfamv,&Init_ltfavm,&Init_ltfavv);
	
		
	ic += fscanf(initf,"%d",&Mod_type);
	if(!(Mod_type == 0 || Mod_type == 1))printerr("init_v_file: mod_type wrong");
	
	ic += fscanf(initf,"%d",&Itno);
	
	ic += fscanf(initf,"%d",&Thin);
	if(ic != 4*Nloc+33){
		printf("ic is %d\n",ic);
		printerr("init_v_file probably too short");
	}
	if(Thin <= 0 )printerr("init_v_file: Thin seems funny");
	
	fclose(initf);
}


void initpars(Genpars *pars,int j)
{
	FILE *initf;
	
	pars->pplus=pars->pplus2 = 0.5;
	
		
	pars->n0_2 = pars->n0 = Init_n0[j];
	pars->n1_2 = pars->n1 = Init_n1[j];
	pars->mu2 = pars->mu = Init_mu[j];
	pars->gen2 = pars->gen = Init_gen;
	pars->tfa2 = pars->tfa = Init_tfa[j];
	pars->which_model = Mod_type;
	
	fillpars(pars);
	
}

void inithpars(Hierpars *hpars)
{
	hpars->ln0mean = hpars->ln0mean2 = Init_ln0mean;
	hpars->ln0mm = Init_ln0mm;
	hpars->ln0mv = Init_ln0mv;
	hpars->ln0var = hpars->ln0var2 = Init_ln0var;
	hpars->ln0vm = Init_ln0vm;
	hpars->ln0vv = Init_ln0vv;
	hpars->ln1mean = hpars->ln1mean2 = Init_ln1mean;
	hpars->ln1mm = Init_ln1mm;
	hpars->ln1mv = Init_ln1mv;
	hpars->ln1var = hpars->ln1var2 = Init_ln1var;
	hpars->ln1vm = Init_ln1vm;
	hpars->ln1vv = Init_ln1vv;
	hpars->lmumean = hpars->lmumean2 = Init_lmumean;
	hpars->lmumm = Init_lmumm;
	hpars->lmumv = Init_lmumv;
	hpars->lmuvar = hpars->lmuvar = Init_lmuvar;
	hpars->lmuvm = Init_lmuvm;
	hpars->lmuvv = Init_lmuvv;
	hpars->ltfamean = hpars->ltfamean2 = Init_ltfamean;
	hpars->ltfamm = Init_ltfamm;
	hpars->ltfamv = Init_ltfamv;
	hpars->ltfavar = hpars->ltfavar2 = Init_ltfavar;
	hpars->ltfavm = Init_ltfavm;
	hpars->ltfavv = Init_ltfavv;
}

void untwidhpars(Hierpars *hpars)
{
	hpars->ln0mean = hpars->ln0mean2;
	hpars->ln0var = hpars->ln0var2;
	hpars->ln1mean = hpars->ln1mean2;
	hpars->ln1var = hpars->ln1var2;
	hpars->lmumean = hpars->lmumean2;
	hpars->lmuvar = hpars->lmuvar2;
	hpars->ltfamean = hpars->ltfamean2;
	hpars->ltfavar = hpars->ltfavar2;
	hpars->prior = hpars->prior2;
}

void copyhpars(Hierpars *hpars)
{
	hpars->ln0mean2 = hpars->ln0mean;
	hpars->ln0var2 = hpars->ln0var;
	hpars->ln1mean2 = hpars->ln1mean;
	hpars->ln1var2 = hpars->ln1var;
	hpars->lmumean2 = hpars->lmumean;
	hpars->lmuvar2 = hpars->lmuvar;
	hpars->ltfamean2 = hpars->ltfamean;
	hpars->ltfavar2 = hpars->ltfavar;
	hpars->prior2 = hpars->prior;
}

void untwidpars(Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars)
{
	int j;
	
	pars->prior = pars->prior2;
	
	pars->n0 = pars->n0_2;
	pars->n1 = pars->n1_2;
	pars->mu = pars->mu2;
	pars->gen = pars->gen2;
	pars->tfa = pars->tfa2;
	pars->pplus = pars->pplus2;
	
	pars->lwt_max = pars->lwt_max2;
	pars->lwt_tot = pars->lwt_tot2;
	pars->nwt_max = pars->nwt_max2;
	pars->nwt_tot = pars->nwt_tot2;
	
	fillpars(pars);

	for(j=0;j<*mm;++j)restore(mlist[j]);
	*mm  = 0;
	for(j=0;j<*cmm;++j)crestore(cmlist[j]);
	*cmm = 0;
	
}

void choosepar(struct Gplist *ptlist,Hierpars *hpars,int oneonly,
int *mtype) 
{

	double dd,parwt,ddscale,rr,rr2,temp1;
	
	*mtype = 0;
	
	ptlist->keeptime 
		= ptlist->keepn0 
		= ptlist->keepn1 
		= ptlist->keepmu 
		= ptlist->keeptfa 
		= ptlist->keeppplus
		= 1;
		

	rr = gfsr8();
	if(rr < 1.0){
	
	
	
		
		ddscale = 1.0;
		if(oneonly)ddscale *= 0.5;
	/*	ptlist->dd = ddscale*norm4(); */
		rr2 = gfsr4();
		parwt = 0.5;
		if(Usum[5] <= 0.0)parwt = 0.0;
		if(rr2 < parwt){
			rr2 = gfsr4(); 
			if(rr2 < Usum[0]){
			/*	keepn0 = 0; */
			/*	if(oneonly){
					ddscale = hpars->ln1var < hpars->lmuvar ? 
					          hpars->ln1var : hpars->lmuvar ;
				}*/
				ptlist->dd = ddscale*norm4();
				ptlist->keepn1 = 0; 
				ptlist->keepmu = 0;
				if(gfsr4() < 0.5)ptlist->keeptime = 0;
				*mtype = 20;
			}
			else if(rr2 < Usum[1]){
			/*	if(oneonly){
					ddscale = hpars->ltfavar < hpars->lmuvar ?
								hpars->ltfavar : hpars->lmuvar;
				}*/
				ptlist->dd = ddscale*norm4();
				ptlist->keepmu = 0;
				ptlist->keeptfa = 0;
				if(gfsr4() < 0.5)ptlist->keeptime = 0;
				*mtype = 21;
			}
			else if (rr2 < Usum[2]){
			/*	if(oneonly){
					temp1 = hpars->ln0var < hpars->ln1var ?
							hpars->ln0var : hpars->ln1var;
					ddscale = hpars->ltfavar < hpars->lmuvar ?
							hpars->ltfavar : hpars->lmuvar;
					ddscale = ddscale < temp1 ? ddscale : temp1;
				}*/
				ptlist->dd = ddscale*norm4();
				ptlist->keepn0 = 0;
				ptlist->keepn1 = 0;
				ptlist->keeptfa = 0;
				ptlist->keepmu = 0;
				*mtype = 22;
			}
			else if (rr2 < Usum[3]){
			/*	if(oneonly)ddscale = hpars->ln1var ;*/
				ptlist->dd = ddscale*norm4();
				ptlist->keepn1 = 0;
				if(gfsr4() < 0.5)ptlist->keeptime = 0;
				*mtype = 23;
			}
			else if(rr2 < Usum[4]){
			/*	if(oneonly){
					ddscale = hpars->ln1var < hpars->lmuvar ?
							  hpars->ln1var : hpars->lmuvar;
					ddscale = ddscale < hpars->ltfavar ? ddscale :
								hpars->ltfavar;	
				} */
				ptlist->dd = ddscale*norm4();
			/* I think an equivalent change is to just change
			   n0 rather than the other 3, so I do that here
				ptlist->keepn1 = 0;
				ptlist->keepmu = 0;
				ptlist->keeptfa = 0; */
				ptlist->keepn0 = 0;
				if(gfsr4() < 0.5)ptlist->keeptime = 0;
				*mtype = 29;
			}
			else if (rr2 < Usum[5]){
			/*	if(oneonly)ddscale = hpars->lmuvar;*/
				ptlist->dd = ddscale*norm4();
				ptlist->keepmu = 0;
				ptlist->keeptime = 0;
				*mtype = 24;
			}
			else {
			/*	if(oneonly)ddscale = hpars->ltfavar;*/
				ptlist->dd = ddscale*norm4();
				if(!oneonly)ptlist->dd = 5*ptlist->dd; /* to try to leap around more */
				ptlist->keeptfa = 0;
				
				if(gfsr4() < 0.5)ptlist->keeptime = 0;
				*mtype = 25;
			}
		}
		else {
			ptlist->keeptime=0;
			*mtype = 26;
		}
	}
	else{
		ptlist->keeppplus = 0;
		ptlist->ppval = gfsr4();
		*mtype = 29;
	}
	

}

void twidpars(struct Gplist *ptlist,Genpars *pars,Hierpars *hpars,int doprior)
{
	double dd;
	static double ltrans=M_LOG10E;
	dd = ptlist->dd;
	
	pars->tpr = pars->tpf = 0.0; 
	if(!ptlist->keepn0){
		pars->n0 = pars->n0*exp(dd);
		if(doprior)hpars->ln0mean += ltrans*dd;	
	}
	if(!ptlist->keepn1){
		pars->n1 = pars->n1*exp(dd);
		if(doprior)hpars->ln1mean += ltrans*dd;
	}
	if(!ptlist->keepmu){
		pars->mu = pars->mu*exp(-dd);
		if(doprior)hpars->lmumean -= ltrans*dd;
	}
	if(!ptlist->keeptfa){
		pars->tfa = pars->tfa*exp(dd); 
		if(doprior)hpars->ltfamean += ltrans*dd;
	}
	if(!ptlist->keeppplus){
		pars->pplus = ptlist->ppval;
	}
	fillpars(pars);

}

void twidpars_var(struct Gplist *ptlist,Genpars *pars,Hierpars *hpars)
{
	double dd,xx;
	static double ltrans=M_LOG10E;
	dd = ptlist->dd;
	
	pars->tpr = pars->tpf = 0.0; 
	if(!ptlist->keepn0){
		xx = exp(dd)*(log10(pars->n0) - hpars->ln0mean) + hpars->ln0mean;
		pars->n0 = /*pars->n0*/pow(10.0,xx);
	}
	if(!ptlist->keepn1){
		xx = exp(dd)*(log10(pars->n1) - hpars->ln1mean) + hpars->ln1mean;
		pars->n1 = /*pars->n1*/pow(10.0,xx);
	}
	if(!ptlist->keepmu){
		xx = exp(dd)*(log10(pars->mu) - hpars->lmumean) + hpars->lmumean;
		pars->mu = /*pars->mu*/pow(10.0,xx);
	}
	if(!ptlist->keeptfa){
		xx = exp(dd)*(log10(pars->tfa) - hpars->ltfamean) + hpars->ltfamean;
		pars->tfa = /*pars->tfa*/pow(10.0,xx);
	}
	if(!ptlist->keeppplus){
		pars->pplus = ptlist->ppval;
	}
	fillpars(pars);
	pars->tpr = dd;
	
	/* question - do we need to do anything for tpr/tpf? */

}

double twidhpars(struct Gplist *ptlist,Hierpars *hpars)
{
	/* using gaussian updates means that the variances need to be checked 
	with boundcheck */
	double dd,rr;
	double scale=0.5;
	

	ptlist->keeptime 
		= ptlist->keepn0 
		= ptlist->keepn1 
		= ptlist->keepmu 
		= ptlist->keeptfa 
		= ptlist->keeppplus
		= 1;


	rr = gfsr4();
	dd = norm4()*scale;
	ptlist->dd = dd;
	if(rr < 0.25){
		hpars->ln0var *= exp(dd);
		ptlist->keepn0 = 0;
	}
	else if(rr < 0.5){
		hpars->ln1var *= exp(dd);
		ptlist->keepn1 = 0;
		
	}
	else if(rr < 0.75){
		hpars->lmuvar *= exp(dd);
		ptlist->keepmu = 0;
	}
	else {
		hpars->ltfavar *= exp(dd);
		ptlist->keeptfa = 0;
	}
	if(gfsr4() < 0.5)ptlist->keeptime = 0;
	
	return dd;

}

void priorcalc(Genpars *pars,Hierpars *hpars)
{
/*The idea behind this is that, say, for each locus the  mutation rate is different, but
it is drawn from some distribution common to all loci with  mean lmumean, and 
variance lmuvar. If we have a number of loci then we can also say something about the
distribution of lmumean and lmuvar. For example there may be little variation between loci 
and therefore lmuvar will be small. 
 
 */
	pars->prior = log_normdev(log10(pars->n0),hpars->ln0mean,hpars->ln0var);
	pars->prior += log_normdev(log10(pars->n1),hpars->ln1mean,hpars->ln1var);
	pars->prior += log_normdev(log10(pars->mu),hpars->lmumean,hpars->lmuvar);
	pars->prior += log_normdev(log10(pars->tfa),hpars->ltfamean,hpars->ltfavar);
	
}

void hpriorcalc(Hierpars *hpars)
{
/*The idea behind this is that, say, for each locus the  mutation rate is different, but
it is drawn from some distribution common to all loci with  mean lmumean, and 
variance lmuvar. If we have a number of loci then we can also say something about the
distribution of lmumean and lmuvar. For example there may be little variation between loci 
and therefore lmuvar will be small. 
 
 */
	hpars->prior = log_normdev(hpars->ln0mean,hpars->ln0mm,hpars->ln0mv);
	hpars->prior += log_normdev(hpars->ln0var,hpars->ln0vm,hpars->ln0vv);
	hpars->prior += log_normdev(hpars->ln1mean,hpars->ln1mm,hpars->ln1mv);
	hpars->prior += log_normdev(hpars->ln1var,hpars->ln1vm,hpars->ln1vv);
	hpars->prior += log_normdev(hpars->lmumean,hpars->lmumm,hpars->lmumv);
	hpars->prior += log_normdev(hpars->lmuvar,hpars->lmuvm,hpars->lmuvv);
	hpars->prior += log_normdev(hpars->ltfamean,hpars->ltfamm,hpars->ltfamv);
	hpars->prior += log_normdev(hpars->ltfavar,hpars->ltfavm,hpars->ltfavv);
}


void copypars(Genpars *pars)
{
	pars->prior2 = pars->prior;
	pars->n0_2 = pars->n0;
	pars->n1_2 = pars->n1;
	pars->mu2 = pars->mu;
	pars->gen2 = pars->gen;
	pars->tfa2 = pars->tfa;
	pars->pplus2 = pars->pplus;
	
	pars->lwt_tot2 = pars->lwt_tot;
	pars->nwt_tot2 = pars->nwt_tot;
	pars->lwt_max2 = pars->lwt_max;
	pars->nwt_max2 = pars->nwt_max;
	
	fillpars(pars);
}

void fillpars(Genpars *pars)
{
	pars->theta = Ploidy*pars->n0*2.0*pars->mu;
	pars->theta2 = Ploidy*pars->n0_2*2.0*pars->mu2;
	pars->r = pars->n0/pars->n1;
	pars->r2 = pars->n0_2/pars->n1_2;
	pars->tf = pars->tfa/(pars->gen*Ploidy*pars->n0);
	pars->tf2 = pars->tfa2/(pars->gen2*Ploidy*pars->n0_2);
}
		


void untwiddle(Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars,int *nn,int oldnn)
{
	int j;
	for(j=0;j<(*mm);++j){
		restore(mlist[j]);
	}
	(*mm) = 0;
	
	for(j=0;j<(*cmm);++j){
		crestore(cmlist[j]);
	}
	(*cmm) = 0;
	
	pars->evswap_indic = pars->evswap_indic2;
	pars->linmut_indic = pars->linmut_indic2;
	pars->nodemut_indic = pars->nodemut_indic2;
	pars->linswap_indic = pars->linswap_indic2;
	pars->nwt_tot = pars->nwt_tot2;
	pars->nwt_max = pars->nwt_max2;
	pars->lwt_tot = pars->lwt_tot2;
	pars->lwt_max = pars->lwt_max2;
	pars->pspace = pars->pspace2;
	
	*nn = oldnn;
}

void accept(Node **mlist,int *mm,Cnode **cmlist,int *cmm)
{
	int j;
	
	for(j=0;j<*mm;++j)mlist[j]->mark = -1;
	(*mm) = 0;
	for(j=0;j<*cmm;++j){cmlist[j]->mark[0] = -1;cmlist[j]->mark[1] = -1;}
	(*cmm) = 0;
	
}


int cal_nodeprob(int mlin[3][3],int indic)
{
	int prob;
	if(indic){
		prob = mlin[0][0]*mlin[1][0] + mlin[0][1]*mlin[1][1] > 0;
	}
	else{
		prob = mlin[0][0]*mlin[1][0]*mlin[2][1] + mlin[0][1]*mlin[1][1]*mlin[2][0] > 0;
	}
	return prob;
}

int cal_linprob(int mlin[3][3],int rl)
{
	int prob;
	prob = mlin[rl][0]*mlin[rl][1] > 0;
	return prob;
}

double nwt_cal(Node *pp)
{
	double tim1;
	
	if(pp == NULL || pp->type != 2)printerr("nwt_cal: wrong input");
/*	return 1.0; */
	if(pp->a == NULL)tim1 = (pp->time - pp->cp->l->time)*(pp->time -
	pp->cp->r->time);
	else tim1 = (pp->cp->u->time - pp->time)*
		(pp->time - pp->cp->l->time)*(pp->time - pp->cp->r->time);
	return tim1;

}

double lwt_cal(Node *pp,int irl)
{
	if(pp == NULL || pp->type != 2)printerr("lwt_cal: wrong input pp");
	if(!(irl == 0 || irl == 1))printerr("lwt_cal: wrong input irl");
/*	return 1.0; */
	if(irl == 0)return (pp->time - pp->cp->l->time)*(pp->time -
	pp->cp->l->time);
	else return (pp->time - pp->cp->r->time)*(pp->time - pp->cp->r->time);
	
}


int findinclist(Node *pp)
{
	Cnode *cp;
	if(pp == NULL)return -1;
	if(pp->type == 0)return -1;
	cp = pp->cp;
	if(cp == NULL)return -1;
	return cp->cpos;
}

void checktree(Node *pt,int ulim,int sno,Cnode *clist,int nc,Genpars *pars,int ismark)
{
	int nl,blim,ic,lastval1,lastval2,j,nminus,nplus,n3sum,pairsum,ll;
	int ncheck,  sumswn,  swn,ltot;
	double pscheck,lwtot,lwmax,nwtot,nwmax,tim1;
	Node *pp,*pv,*startpp;
	Cnode *cp,*cpt,*cpp;
	blim = pt->pos;
	ulim = ulim-1;
	ic = 0;
	if(pt->type != 0){
		printerr("treecheck: error 000");
	}
	else{
		if(blim == 0 && pt->pos > sno)printerr("treecheck: error 00");
		nl = pt->nlin;
		pt = pt->tlf;
		startpp = pt;
	}
	ltot = 0;
	sumswn = 0;
	while(pt != NULL){
		if(!ismark && pt->mark != -1)printerr("treecheck: error a00");
		if(pt->type == 0)printerr("treecheck: error 00");
		if(pt->pos < blim || pt->pos > ulim)printerr("treecheck: error 0");
		if(pt->a != NULL && (pt->a->pos < blim || pt->pos > ulim))
			printerr("treecheck: error 0a");
		if(pt->nlin != nl)printerr("treecheck: error 1");
		if(pt->type == 1){
			if(pt->dr != NULL)printerr("treecheck: relate error 1");
			if(pt->dl == NULL)printerr("treecheck: relate error 2");
			if(pt->dl->a != pt)printerr("treecheck: relate error 3");
			if(pt->a == NULL)printerr("treecheck: relate error 4");
			if(pt->a->type == 1 && pt->a->dl != pt)
				printerr("treecheck: relate error 5");
			if(pt->a->type == 2 && !(pt->a->dl == pt || pt->a->dr == pt))
				printerr("treecheck: relate error 6");
			if(pt->time < pt->dl->time)printerr("treecheck: error 2");
			if(pt->val == pt->dl->val)printerr("treecheck: error 3");
			if(pt->dl->pos < blim || pt->dl->pos > ulim)
						printerr("treecheck: error 3a");
			if(pt->lno < 0 || pt->lno >= 2*sno-1)
					printerr("treecheck: lno error 0");
			if(pt->lno != pt->dl->lno)printerr("treecheck: lno error 1");
		}
		else if(pt->type == 2){
			if(pt->dr == NULL || pt->dl == NULL)
				printerr("treecheck: relate error 7");
			if(pt->lno == pt->dl->lno || pt->lno == pt->dr->lno)
					printerr("treecheck: lno error 2");
			if(pt->lno < 0 || pt->lno >= 2*sno-1)printerr("treecheck: lno error 3");
			if(!(pt->dr->a == pt && pt->dl->a == pt))
				printerr("treecheck: relate error 8");
			if(pt->a != NULL){
				if(pt->a->type == 1 && pt->a->dl != pt)
					printerr("treecheck: relate error 9");
				if(pt->a->type == 2 && !(pt->a->dl == pt || pt->a->dr == pt))
					printerr("treecheck: relate error 10");
			}
			else{
				if(pt->tlf != NULL)printerr("treecheck: mrca->tlf != NULL");
			}
			if(pt->time < pt->dl->time)printerr("treecheck: error 4");
			if(pt->time < pt->dr->time)printerr("treecheck: error 5");
			if(pt->val != pt->dl->val)printerr("treecheck: error 6");
			if(pt->val != pt->dr->val)printerr("treecheck: error 7");
			if(pt->dl->pos < blim || pt->dl->pos > ulim)
						printerr("treecheck: error 7a");
			if(pt->dr->pos < blim || pt->dr->pos > ulim)
						printerr("treecheck: error 7b");
			--nl;
		}
		else printerr("treecheck: error 7ba");
		if(pt->mark < -2 || pt->mark == 0 )
						printerr("treecheck: error 7c");
		ll = linswap_cal(pt);
		if(ll != pt->linswap)printerr("treecheck: linswap error");
		ltot += ll;
		sumswn += swn = swapable(pt);
		if(swn != pt->evswap)printerr("treecheck: evswap error");
		
		pt = pt->tlf;
		++ic;
		if(ic > 5000)printerr("treecheck: loop too long");
	}
	if(nl != 1)printerr("treecheck: error 8");
	if(blim == 0){
		if(ic != ulim+1-sno)printerr("treecheck: error 9");
	}
	else if(ic != ulim+1-(blim+sno))printerr("treecheck: error 10");
	if(pars->linswap_indic != ltot)printerr("treecheck: pars->linswap_indic wrong");
	if(sumswn != pars->evswap_indic)printerr("treecheck: pars->evswap_indic wrong");
	
	lwmax = -1.0;
	nwmax = -1.0;
	lwtot = 0.0;
	nwtot = 0.0;
	
	lastval1 = 0;
	lastval2 = 0;
	n3sum = 0;
	pairsum = 0;
	for(j=0;j<nc;++j){  /* this loop checks mutation parameters */
		cp = &(clist[j]);
		if(!ismark && cp->mark[0] != -1 && cp->mark[1] != -1)
				printerr("treecheck: mlin check, error 00");
		pv = clist[j].p;
		if(pv == NULL || pv->type != 2)printerr("treecheck:mlin check, error 0");
		
		
		tim1 = lwt_cal(pv,0);
		if(cp->lwt[0] != tim1)printerr("treecheck: lwt[0] wrong");
		if(lwmax < tim1)lwmax = tim1;
		lwtot += tim1;
		
		tim1 = lwt_cal(pv,1);
		if(cp->lwt[1] != tim1)printerr("treecheck: lwt[1] wrong");
		if(lwmax < tim1)lwmax = tim1;
		lwtot += tim1;
		
		tim1 = nwt_cal(pv);
		if(cp->nwt != tim1)printerr("treecheck: nwt wrong");
		if(nwmax < tim1)nwmax = tim1;		
		nwtot += tim1;
		
		
		pp = pv->a;
		if(pp == NULL){
			if(!(clist[j].mlin[2][0] == 0 && clist[j].mlin[2][1] == 0 && 
				clist[j].mlin[2][2] == 0)){
				printerr("treecheck: mlin check, error 1");
			}
		}
		else{
			nminus = nplus = 0;
			while(pp->type == 1){
				if(pp->val - pp->dl->val == -1){
					++nminus;
				}
				else ++nplus;
				pp = pp->a;
			}
			if(!(cp->mlin[2][0] == nminus && cp->mlin[2][1] == nplus && 
			cp->mlin[2][2] == nplus+nminus)){
				printerr("treecheck: mlin check, error 2"); /* cf below */
			}
		}
		
		pp = pv->dl;
		nminus = nplus = 0;
		while(pp->type == 1){
			if(pp->val - pp->dl->val == -1){
				++nminus;
			}
			else ++nplus;
			pp = pp->dl;
		}
		if(!(cp->mlin[0][0] == nminus && cp->mlin[0][1] == nplus && 
		cp->mlin[0][2] == nplus+nminus)){
			printerr("treecheck: mlin check, error 3");
							 /* need to change last bit if more than 
			                     1-step mutation */
		}
		
		pp = pv->dr;
		nminus = nplus = 0;
		while(pp->type == 1){
			if(pp->val - pp->dl->val == -1){
				++nminus;
			}
			else ++nplus;
			pp = pp->dl;
		}
		if(!(cp->mlin[1][0] == nminus && cp->mlin[1][1] == nplus && /* cf above */
		cp->mlin[1][2] == nplus+nminus)){
			printerr("treecheck: mlin check, error 4");
		}
		
		lastval1 = cp->mlin[0][0]*cp->mlin[0][1] > 0;
		if(lastval1 != clist[j].linmut[0])printerr("treecheck: mlin check, error 5");
		pairsum += lastval1;
		
		lastval1 = cp->mlin[1][0]*cp->mlin[1][1] > 0;
		if(lastval1 != clist[j].linmut[1])printerr("treecheck: mlin check, error 6");
		pairsum += lastval1;
		
		lastval2 = cal_nodeprob(cp->mlin,clist[j].u == NULL);
		if(lastval2 != clist[j].nodemut)printerr("treecheck: mlin check, error 7");
		n3sum += lastval2;
	}
	if(pars->nodemut_indic != n3sum)printerr("treecheck:mlin check, error, 8");
	if(pars->linmut_indic != pairsum)printerr("treecheck: mlin check, error, 9");
	
	if(lwmax > pars->lwt_max)printerr("treecheck: pars->lwt_max wrong");
	if(fabs(pars->lwt_tot - lwtot)/lwtot > 1.0e-5)printerr("treecheck: pars->lwt_tot wrong");
	if(fabs(pars->nwt_tot - nwtot)/nwtot > 1.0e-5)printerr("treecheck: pars->nwtot wrong");
	if(nwmax > pars->nwt_max)printerr("treecheck: pars->nwt_max wrong");
	
	/* for rounding errors - also correction of nwt_max, lwt_max*/
	
	pars->lwt_max = lwmax;
	pars->lwt_tot = lwtot;
	pars->nwt_tot = nwtot;
	pars->nwt_max = nwmax;

	
	ncheck = 0;
	cpt = &clist[nc-1];
	while(1){
		
		if(cpt->cpos < 0 || cpt->cpos >= nc)printerr("treecheck: clist check, error 3");
		if(cpt->p == NULL)printerr("treecheck: clist check, error 4");
		if(cpt->cpos == nc-1){
			 if(cpt->u != NULL)printerr("treecheck: clist check, error 5");
			 if(cpt->tf != NULL)printerr("treecheck: clist check, error 5b");
		}
		if(cpt->cpos != nc-1){
			if(cpt->u == NULL)printerr("treecheck: clist check, error 6");
			if(cpt->u->cp == NULL)printerr("treecheck: clist check, error 7");
			if(cpt->u->cp->l == cpt->u->cp->r)
								printerr("treecheck: clist check, error 8");
			if(!(cpt->u->cp->l == cpt->p || cpt->u->cp->r == cpt->p))
								printerr("treecheck: clist check, error 9");
			if(cpt->tf == NULL)printerr("trecheck: clist check, error 9b");
			if(cpt->tf->cp == NULL)printerr("treecheck: clist check, error 9c");
			if(cpt->tf->cp->tr != cpt->p)printerr("treecheck: clist check, error 9d");
			if(cpt->tf->time <= cpt->p->time)
				printerr("treecheck: clist check, error 9e");
			if(cpt->tr->time >= cpt->p->time)
				printerr("treecheck: clist check, error 9f");
				
		}
		if(cpt->l == NULL)printerr("treecheck: clist check, error 9e");
		if(cpt->l->type != 0){
			if(cpt->l->cp == NULL)printerr("treecheck: clist check, error 10");
			if(cpt->l->cp->u != cpt->p)printerr("treecheck: clist check, error11");
		}
		if(cpt->r == NULL)printerr("treecheck: clist check, error 11b");
		if(cpt->r->type != 0){
			if(cpt->r->cp == NULL)printerr("treecheck: clist check, error 12");
			if(cpt->r->cp->u != cpt->p)printerr("treecheck: clist check, error13");
		}
		++ncheck;
		if(cpt->tr == NULL)printerr("treecheck: clist check, error 13b");
		if(cpt->tr->type != 0){
			if(cpt->tr->cp == NULL)printerr("treecheck: clist check, error 13c");
			if(cpt->tr->cp->tf != cpt->p)printerr("treecheck: clist check, error 14");
			cpt = cpt->tr->cp;
		}
		else break;
	}
	if(ncheck != nc)printerr("treecheck: clist check, error 14b");
	
	pscheck = MUTLIN_ADD_P + MUTNODE_ADD_P;
	if(pars->evswap_indic)pscheck += ESWAP_PROB;
	if(pars->linmut_indic)pscheck += MUTLIN_DEL_P;
	if(pars->nodemut_indic)pscheck += MUTNODE_DEL_P;
	if(pars->linswap_indic)pscheck += LSWAP_PROB;
	
	if(fabs(pscheck - pars->pspace) > 1.0e-9)printerr("treecheck: clist check, error 17");
	
	
	/* Extra checks */
	
	pp = startpp;	
	while(pp->type != 2)pp = pp->tlf;
	if(pp->cp->tr->type != 0)printerr("treecheck extras: not first coalescence");
	cpp = pp->cp;
	while(cpp != NULL){
		pp = pp->tlf;
		if(pp==NULL)break;
		while(pp->type != 2)pp=pp->tlf;
		if(pp->cp->p != cpp->tf)printerr("treecheck extras: pp->cp != cpp->tf");
		if(pp->cp->tr != cpp->p)printerr("trecheck extras: pp->cp->tr != cpp");
		cpp = cpp->tf->cp;
	}		
		
}

double tdens(double t1,double t2,int nl,double theta,double r,double tf,int which_model)
{
	if(which_model == 0)return tdensL(t1,t2,nl,theta,r,tf);
	else if(which_model == 1)return tdensE(t1,t2,nl,theta,r,tf);
	else printerr("tdens: which_model wrong");
}



double tdensL(double t1,double t2,int nl,double theta,double r,double tf)
{
/* this gives the log density. It is slightly inefficient for last two cases because
usually we want the ratio and coeff cancels out */
	double fx,coeff;
	if(t1 >= t2)printerr("tdensL: t1 >= t2");
	if(fabs(r-1.0) < 0.00001) tf = 0.0; /* to avoid division by zero */
	if(tf > 1.e10){r=1;tf=0.0;} /* to trap rounding errors with large tf */
	if(t1 < tf && t2 < tf){
		fx = nl*theta*(t2-t1)*0.5 + (nl*(nl-1.0)*r*tf/(2.0*(1.0-r)))*
				log((r*tf+t2-r*t2)/(r*tf+t1-r*t1));
		coeff = (nl*theta*0.5 + (nl-1.0)*nl*r*tf*0.5/(r*tf+t2-r*t2));
	}
	else if(t1 < tf && t2 >= tf){
		fx = nl*theta*(tf-t1)*0.5 + (nl*(nl-1.0)*r*tf/(2.0*(1.0-r)))*
				log(tf/(r*tf+t1-r*t1)) + nl*(r*(nl-1)+theta)*0.5*(t2-tf);
		coeff = nl*(r*(nl-1)+theta)*0.5;
	}
	else if(t1 >= tf && t2 >= tf){
		coeff = nl*(r*(nl-1)+theta)*0.5;
		fx = coeff*(t2-t1);
	}
	return log(coeff) - fx;
}

double tdensE(double t1,double t2,int nl,double theta,double r,double tf)
{
/* this gives the log density. It is slightly inefficient for last two cases
because
usually we want the ratio and coeff cancels out */
	double fx,coeff,logr,rtf,powrt2tf;
	
	logr = log(r);
	rtf = r*tf;
	if(t1 >= t2)printerr("tdens: t1 >= t2");
	if(fabs(r-1.0) < 0.00001) tf = 0.0; /* to avoid division by zero */
	if(tf > 1.e10){r=1;tf=0.0;} /* to trap rounding errors with large tf */
	if(t1 < tf && t2 < tf){
		powrt2tf = pow(r,t2/tf);
     	fx = 0.5*nl*(theta*(t1-t2) + (nl-1)*tf/logr*(pow(r,t1/tf)-
     			powrt2tf));
     	/* this is -probfunc -> hence different from fx in linear model */
		coeff = powrt2tf*nl*(nl-1)/2+nl*theta/2;	
	}
	else if(t1 < tf && t2 >= tf){
      	fx = (nl*(rtf*(logr-1)*(nl-1) + tf*pow(r,t1/tf)*(nl-1) +
      	logr*(theta*t1
      		+t2*(r*(1 -nl) - theta))))/(2*logr);
     	/* this is -probfunc -> hence different from fx in linear model */
		coeff = nl*(r*(nl-1)+theta)*0.5;
	}
	else if(t1 >= tf && t2 >= tf){
		coeff = nl*(r*(nl-1)+theta)*0.5;
		fx = -coeff*(t2-t1); /* note different sign from linear model */
	}
	return log(coeff) + fx; /* note different sign from linear model */
}


double lik_cal(Node *pt,Node *out,Genpars *pars)
{
	if(Illegal){
		return -1.0e100;
	}
	if(pars->which_model == 0)return lik_calL(pt,out,pars);
	else if(pars->which_model == 1)return lik_calE(pt,out,pars);
	else printerr("lik_cal: which_model wrong");
}


double lik_calL(Node *pt,Node *out,Genpars *pars)
{
	int nl,nlcheck,mdir;               
	double lik,t1,t2,pcdfx1,pmdfx1,fx,complik,l1,pmval;
	double logmut,logplus,logminus,logr;
	double theta,r,tf;
	Node *stp;
	
	if(pt == NULL)printerr("lik_calL: pt == NULL");
	if(pt->type == 0)pt = pars->base->tlf; /* lik_calL assumes 
	we start from the first event, not baseline */
	if(out == NULL)stp = NULL;
	else stp = out->tlf;
	lik = 0.0;
	complik = 0.0;
	nlcheck = pt->nlin;
	theta = pars->theta;
	r = pars->r;
	tf = pars->tf;
	if(fabs(r-1.0) < 0.0001)tf = 0.0;
	if(tf > 1.e10){r=1;tf=0.0;} /* to trap rounding errors with large tf */
	logmut = log(theta*0.5);
	if(pars->pplus > 0.0)logplus = log(pars->pplus);
	else logplus = -10000.0;
	if(1.0 - pars->pplus > 0.0)logminus = log(1.0-pars->pplus);
	logr = log(r);
	while(1){
		nl = pt->nlin;
		if(nl != nlcheck)printerr("lik_calL: nlcheck wrong");
		if(pt->time < pt->tlr->time)printerr("lik_calL: time wrong");
		if(pt->time == pt->tlr->time){ /* bodge to fix times */
			printerr2("lik_calL: time wrong - equal to, try to fix",0);
			if(pt->tlf == NULL){
				pt->time += 0.00001;
			}
			else if(pt->tlf == stp)printerr
					("lik_calL: time wrong - equal to, can't fix");
					/* because this might make likelihoods inconsistent */
			else{
				pt->time = pt->tlr->time + 
					0.5*(pt->tlf->time - pt->tlr->time);
				if(pt->time == pt->tlr->time)printerr
					("lik_calL: time wrong - equal to, can't fix");
			}
		}
		
		t1 = pt->tlr->time;
		t2 = pt->time;
		if(t1 < tf && t2 < tf){
			fx = nl*theta*(t2-t1)*0.5 + (nl*(nl-1.0)*r*tf/(2.0*(1.0-r)))*
					log((r*tf+t2-r*t2)/(r*tf+t1-r*t1));
			if(pt->type == 1){
				
				pmdfx1 = theta*0.5;
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_calL: mdir bigger than 1 step");
				l1 = logmut + pmval  -fx; 
				
				/* pmval chance of mut in that direction, 1/nl choose that
				      						lineage */
				lik +=  l1;
			}
			else if(pt->type == 2){
				pcdfx1 = r*tf/(r*tf + t2 - r*t2);
				l1 = log(pcdfx1) - fx;
				
				/*last bit -  prob choosing that 
													pair of lins */
				lik += l1;
				--nlcheck;
			}
		}
		else if(t1 < tf && t2 >= tf){
			fx = nl*theta*(tf-t1)*0.5 + (nl*(nl-1.0)*r*tf/(2.0*(1.0-r)))*
					log(tf/(r*tf+t1-r*t1)) + nl*(r*(nl-1)+theta)*0.5*(t2-tf);
			if(pt->type == 1){
				
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_calL: mdir bigger than 1 step");
				l1 = logmut + pmval  - fx	; 
				/* pmval chance of mut in that direction, 1/nl choose that
				      						lineage */
				lik +=  l1;
			}
			else if(pt->type == 2){
				l1 = logr -fx;
				
				/*last bit -  prob choosing that 
													pair of lins */
				lik += l1;
				--nlcheck;
			}
		}
		else if(t1 >= tf && t2 >= tf){
			if(pt->type == 1){
				
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_calL: mdir bigger than 1 step");
				l1 = -0.5*nl*(t2 - t1)*(theta+r*(nl-1))+ pmval + logmut;
				lik +=  l1;
			}
			else if(pt->type == 2){
				l1 = -0.5*nl*(t2 - t1)*(theta+r*(nl-1))+
							logr; 
				lik += l1;
				--nlcheck;
			}
		}
			
		pt = pt->tlf;
		if(pt == stp)break; 
	}
	tf = 1.0;
	return lik;
} 


double lik_calE(Node *pt,Node *out,Genpars *pars)
{
	int nl,nlcheck,mdir;               
	double lik,t1,t2,pcdfx1,pmdfx1,fx,complik,l1,pmval,rtf,logrvaltf;
	double logmut,logplus,logminus,logr;
	double theta,r,tf;
	Node *stp;
	
	if(pt == NULL)printerr("lik_cal: pt == NULL");
	if(pt->type == 0)pt = pars->base->tlf; /* lik_cal assumes 
	we start from the first event, not baseline */
	if(out == NULL)stp = NULL;
	else stp = out->tlf;
	lik = 0.0;
	complik = 0.0;
	nlcheck = pt->nlin;
	theta = pars->theta;
	r = pars->r;
	tf = pars->tf;
	if(fabs(r-1.0) < 0.0001)tf = 0.0;
	if(tf > 1.e10){r=1;tf=0.0;} /* to trap rounding errors with large tf */
	logmut = log(theta*0.5);
	if(pars->pplus > 0.0)logplus = log(pars->pplus);
	else logplus = -10000.0;
	if(1.0 - pars->pplus > 0.0)logminus = log(1.0-pars->pplus);
	logr = log(r);
	rtf = r*tf;
	while(1){
		nl = pt->nlin;
		if(nl != nlcheck)printerr("old_lik_cal: nlcheck wrong");
		if(pt->time < pt->tlr->time)printerr("old_lik_cal: time wrong");
		if(pt->time == pt->tlr->time){ /* bodge to fix times */
			printerr2("lik_calL: time wrong - equal to, try to fix",0);
			if(pt->tlf == NULL){
				pt->time += 0.00001;
			}
			else if(pt->tlf == stp)printerr
					("lik_calL: time wrong - equal to, can't fix");
					/* because this might make likelihoods inconsistent */
			else{
				pt->time = pt->tlr->time + 
					0.5*(pt->tlf->time - pt->tlr->time);
				if(pt->time == pt->tlr->time)printerr
					("lik_calL: time wrong - equal to, can't fix");
			}
		}
		
		t1 = pt->tlr->time;
		t2 = pt->time;
		if(t1 < tf && t2 < tf){
/*			fx = (nl*theta*t1)/2 - (nl*theta*t2)/2 + 
     				((-1 + nl)*nl*pow(r,t1/tf)*tf)/(2*logr) - 
     				((-1 + nl)*nl*pow(r,t2/tf)*tf)/(2*logr); */
     		fx = 0.5*nl*(theta*(t1-t2) + (nl-1)*tf/logr*(pow(r,t1/tf)-
     				pow(r,t2/tf)));
     	/* this is -probfunc -> hence different from fx in linear model */
			if(pt->type == 1){
				
			/*	pmdfx1 = theta*0.5; */
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_cal: mdir bigger than 1 step");
				l1 = logmut + pmval  +fx;  
				
				/* pmval chance of mut in that direction, 1/nl choose that
				      						lineage */
				lik +=  l1;
			}
			else if(pt->type == 2){
			/*	pcdfx1 = pow(r,t2/tf); can avoid pow by multiplying log with
			t2/tf */
				l1 = t2/tf*logr + fx; 
				
				lik += l1;
				--nlcheck;
			}
		}
		else if(t1 < tf && t2 >= tf){			
		/*	fx = (nl*(rtf - nl*rtf - rpow*tf + nl*rpow*tf - rtf*logr +
		nl*rtf*logr + 
      			theta*t1*logr + r*t2*logr - nl*r*t2*logr -
      			theta*t2*logr))/(2*logr); */
      			      			
      		fx = (nl*(rtf*(logr-1)*(nl-1) + tf*pow(r,t1/tf)*(nl-1) +
      		logr*(theta*t1
      			+t2*(r*(1 -nl) - theta))))/(2*logr);
     	/* this is -probfunc -> hence different from fx in linear model */
      		/*  rtf = r*tf
      			rpow = pow(r,t1/tf)
      			logr = log(r)	*/	
      		if(pt->type == 1){
				
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_cal: mdir bigger than 1 step");
				l1 = logmut + pmval + fx	; 
				/* pmval chance of mut in that direction, 1/nl choose that
				      						lineage */
				lik +=  l1;
			}
			else if(pt->type == 2){
				l1 = logr +fx;
				lik += l1;
				--nlcheck;
			}
		}
		else if(t1 >= tf && t2 >= tf){
			if(pt->type == 1){
				
				mdir = pt->dl->val - pt->val;
				if(mdir == 1)pmval = logplus;
				else if(mdir == -1)pmval = logminus;
				else printerr("lik_cal: mdir bigger than 1 step");
				l1 = -0.5*nl*(t2 - t1)*(theta+r*(nl-1))+ pmval + logmut;
				lik +=  l1;
			}
			else if(pt->type == 2){
				l1 = -0.5*nl*(t2 - t1)*(theta+r*(nl-1))+
							logr; 
				lik += l1;
				--nlcheck;
			}
		}
			
		pt = pt->tlf;
		if(pt == stp)break; 
	}
	tf = 1.0;
	return lik;
} 



double cosim(double t1,int ni,double rval,double tf,int which_model)
{
	switch(which_model){
		case 0:
			return cosimL(t1,ni,rval,tf);
			break;
		case 1:
			return cosimE(t1,ni,rval,tf);
			break;
		default:
			printerr("cosim: which_model wrong");
	}
			
}

double cosimL(double t1,int ni,double rval,double tf)
{
	double rtf,cutoff,t2,deltat,dtop,tdash;
	
	dtop = (ni*(ni-1)*0.5);
	tdash = -log(gfsr8())/dtop;
	tdash += t1;
	
	
	rtf = rval*tf;
	deltat = tdash - t1;
	if(fabs(rval-1.0) < 0.00001 || tf > 1.0e10){ /* to avoid division by zero */
		return deltat + t1;
	}
	
	t2 = (exp(deltat*(1-rval)/rtf)*(rtf+t1-rval*t1) - rtf)/(1.0 - rval);
	if(t1 < tf && t2 < tf)return t2;
	else if(t1 < tf && t2 > tf){
		cutoff = rtf/(1-rval)*log(tf/(rtf+t1*(1.0-rval)));
		t2 = (deltat - cutoff)/rval + tf;
	}
	else t2 = deltat/rval + t1;
	return t2;
}



double cosimE(double t1,int ni,double rval,double tf)
{
	double rtf,cutoff,t2,deltat,dtop,tdash,logr;
	
	dtop = (ni*(ni-1)*0.5);
	tdash = -log(gfsr8())/dtop;
	tdash += t1;
	
	
	if(fabs(1.0-rval) < 1.0e-5 || tf > 1.0e10){ /*to avoid division by 0 */
		return tdash;
	}
	deltat = tdash - t1;
	
	if(t1 < tf){
		logr = log(rval);
		cutoff = (rval - pow(rval,t1/tf))*tf/logr;
		/* this is the value of (tdash - t1) corresponding to a real time of
	   		tf - when t2 == tf */
		if(deltat < cutoff){
			t2 = log(deltat*logr/tf+pow(rval,t1/tf))*tf/logr;

			return t2;
		}
		else {
			t2 = (deltat - cutoff)/rval + tf;
			return t2;
		}
	}
	else {
		t2 = deltat/rval + t1;
		return t2;
	}
}



void read_data(int ***freq,int ***val, int **noall,int *nloc,int **sums)
{
	FILE *inp;	
	int j,k,l,ic,imin,i;
	char c;
	
	inp = fopen("infile","r");
	if(inp == 0){
		printf("no infile\n");
		exit(1);
	}
	fscanf(inp,"%d",nloc);
	while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
	
	(*noall) = (int *)malloc((*nloc)*sizeof(int));
	(*sums) = (int *)malloc((*nloc)*sizeof(int ));
	(*freq) = (int **)malloc((*nloc)*sizeof(int *));
	(*val) = (int **)malloc((*nloc)*sizeof(int *));
	for(j=0;j<(*nloc);++j){
		fscanf(inp,"%d",&(*noall)[j]);
		(*freq)[j] = (int *)malloc((*noall)[j]*sizeof(int ));
		(*val)[j] = (int *)malloc((*noall)[j]*sizeof(int ));
		while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
		for(k=0;k<(*noall)[j];++k){
			ic = fscanf(inp,"%d",&(*freq)[j][k]);
			if(ic <= 0 || ic == EOF){
				printerr("error reading data");
			}
		}
		for(k=0;k<(*noall)[j];++k){
			ic = fscanf(inp,"%d",&(*val)[j][k]);
			if(ic <= 0 || ic == EOF){
				printerr("error reading data");
			}
		}
		imin = 10000000;
		for(i=0;i<(*noall)[j];++i){
			if((*val)[j][i] < imin)imin = (*val)[j][i];
		}
		for(i=0;i<(*noall)[j];++i){
			(*val)[j][i] -= imin;
		}
		(*sums)[j] = 0;
		for(i=0;i<(*noall)[j];++i){
			(*sums)[j] += (*freq)[j][i];
		}
	}
	fclose(inp);
	return;
}



	

void fill_tree_old(Node **list,int *freq,int *val,int noall,int sno,int *nn,int
				*nc,Cnode *clist,Genpars *pars)
{
	Node *lastp,*p1,*pt,*pn,*p2,*pp;
	Cnode *cp;
	int i,k,cumt,up,numlin,mutval,ic,nplus,nminus,j,*tvec,itemp,it1,it2,it3;
	double tt,tim1;
	int icount;
	double rr,rcheck;
	
	tvec = (int *)malloc(sno*sizeof(int));
	for(i=0,k=0,cumt=freq[0];i<sno;++i){
		while(i>=cumt){
			++k;
			if(k>=noall)printerr("fill_tree: k>=noall");
			cumt += freq[k];
		}
		tvec[i] = val[k];
	}
	for(i=0;i<sno-1;++i){
		itemp = tvec[i];
		ic = disrand(i+1,sno-1);
		tvec[i] = tvec[ic];
		tvec[ic] = itemp;
	}
	for(i=0;i<sno;++i){
		list[i]->val = tvec[i];
		list[i]->type = 0;
		list[i]->time = 0.0;
		list[i]->time2 = 0.0;
		list[i]->nlin = 0;
		list[i]->tlr = NULL;
		list[i]->tlf = NULL;
		list[i]->a = NULL;
		list[i]->dl = NULL;
		list[i]->dr = NULL;
		list[i]->pos = i;
		list[i]->mark = -1;
		list[i]->lno = i;
		list[i]->cp = NULL;
	}
	free(tvec);
	*nn = sno;
	tt = 0.0;
	list[0]->nlin = sno;
	lastp = list[0];
	*nc = 0;
	pars->linmut_indic = 0;
	while(*nc < sno-1){
		numlin = sno - *nc;
		icount = 0;
		while(1){
			it3 = it1 = disrand(0,numlin-1);
			for(i=0;i<*nn;++i){
				if(list[i]->a == NULL){
					if(it1 == 0)break;
					--it1;
				}
			}
			if(i == *nn)printerr("fill_tree: fallen through loop 1");
			p1 = list[i];
			it2 = disrand(0,numlin-2);
			if(it2 == it3)it2 = numlin-1;
			for(i=0;i<*nn;++i){
				if(list[i]->a == NULL){
					if(it2 == 0)break;
					--it2;
				}
			}
			if(i == *nn)printerr("fill_tree: fallen through loop 1");
			p2 = list[i];
			if(p1 == p2)printerr("fill_tree: p1 == p2");
			rr = pow(0.1,sqrt((double)abs(p1->val-p2->val)));
			rcheck = gfsr4();
			if(rcheck <= rr || *nc >= sno-2)break;
			if(icount > 1000000)printerr("fill_tree: icount > 1000000");
			++icount;
		}
		while(p1->val != p2->val){
			it1 = disrand(0,1);
			if(it1){
				pn = p1;
				up = p1->val < p2->val;
			}
			else{
				pn = p2;
				up = p2->val < p1->val;
			}
			tt += expdev()/(numlin*((numlin-1)+pars->theta)*0.5);
			if(up)mutval = pn->val+1;
			else mutval = pn->val-1;
			pn = mutate(list,nn,pn,tt,mutval,pn->lno);
			pn->dl->a = pn;
			pn->nlin = numlin;
			pn->tlr = lastp;
			lastp->tlf = pn;
			lastp = pn;
			if(it1)p1 = pn;
			else p2 = pn;
		}
		
		tt += expdev()/(numlin*((numlin-1)+pars->theta)*0.5);
		p1 = coalesce(list,nn,p1,p2,tt);
		p1->lno = sno + *nc;
		p1->nlin = numlin;
		p1->tlr = lastp;
		lastp->tlf = p1;
		lastp = p1;
		++(*nc);
		
/*--------------------------------------------------------
This bit added to load mlin, cumdpmlist, and diffpairtot 
--------------------------------------------------------*/
		/* left branch */
		ic = (*nc)-1;/* ic is the clist entry */
		clist[ic].mark[0] = -1;
		clist[ic].mark[1] = -1;
		nplus = 0;
		nminus = 0;
		pt = p1->dl;
		while(pt->type == 1){
			if(pt->val-pt->dl->val < 0)++nminus;
			else ++nplus;
			pt = pt->dl;
		}
		clist[ic].mlin[0][0] = nminus; 
		 	/* NB: minus (-1) refers back in time : ie the ancestor is 
				shorter; the descendent is longer */
		clist[ic].mlin[0][1] = nplus;
		clist[ic].mlin[0][2] = nminus + nplus;
		clist[ic].p = p1;
		p1->cp = &(clist[ic]);
		clist[ic].cpos = ic;
		clist[ic].l = pt;
		if(pt->type == 2){/*pt should be either type 0 or type 2 */
			pt->cp->u = p1;  
		}
		
		pt = p1->tlr;
		while(!(pt->type == 0  || pt->type == 2))pt=pt->tlr;
		clist[ic].tr = pt;
		if(pt ->type != 0)pt->cp->tf = p1;
		clist[ic].linmut[0] = (nminus*nplus > 0);
		pars->linmut_indic += clist[ic].linmut[0];
		
		
		/* right branch */
		nplus = 0;
		nminus = 0;
		pt = p1->dr;
		while(pt->type == 1){
			if(pt->val-pt->dl->val < 0)++nminus;
			else ++nplus;
			pt = pt->dl;
		}
		clist[ic].r = pt;
		if(pt->type == 2){
			pt->cp->u = p1;
		}
		clist[ic].mlin[1][0] = nminus;
		clist[ic].mlin[1][1] = nplus;
		clist[ic].mlin[1][2] = nplus + nminus;
		clist[ic].linmut[1] = (nminus*nplus > 0);
		pars->linmut_indic += clist[ic].linmut[1];
		
	}
	lastp->tlf = NULL;
	if(*nc != sno-1)printerr("fill_tree: nc != sno-1");
	clist[*nc-1].u = NULL;
	clist[*nc-1].tf = NULL;
	/* this bit fills in the upper lineage for mlin, 
			and gives node3_tot and cumnode3list */
	pars->nodemut_indic = 0;
	pars->linswap_indic = 0;
	pars->evswap_indic = 0;
	for(j=0;j<*nn;++j){
		if(linswap_cal(list[j])){
			list[j]->linswap = 1;
			++pars->linswap_indic;
		}
		else list[j]->linswap = 0;
		list[j]->evswap = swapable(list[j]);
		pars->evswap_indic += list[j]->evswap;
	}
	
	pars->lwt_tot = 0.0;
	pars->nwt_tot = 0.0;
	pars->lwt_max = -1.0;
	pars->nwt_max = -1.0;
	
	for(j=0;j<*nc;++j){
		cp = &(clist[j]);
		pp = cp->p;

		if(pars->lwt_max < (tim1 = lwt_cal(pp,0)))
			pars->lwt_max = tim1;
		cp->lwt[0] = tim1;
		pars->lwt_tot += tim1;
		if(pars->lwt_max < (tim1 = lwt_cal(pp,1)))
			pars->lwt_max = tim1;
		cp->lwt[1] = tim1;
		pars->lwt_tot += tim1;
		
		if(pars->nwt_max < (tim1 = nwt_cal(pp)))
			pars->nwt_max = tim1;
		pars->nwt_tot += tim1;
		cp->nwt = tim1;
		
		pt = cp->p->a;
		if(pt==NULL){
			cp->mlin[2][0] = 0;
			cp->mlin[2][1] = 0;
			cp->mlin[2][2] = 0;
			cp->nodemut = (cp->mlin[0][0]*cp->mlin[1][0] +
								cp->mlin[0][1]*cp->mlin[1][1] > 0);
			pars->nodemut_indic += cp->nodemut;
		}
		else{
			nplus = nminus = 0;
			while(pt->type == 1){
				if(pt->val-pt->dl->val < 0)++nminus;
				else ++nplus;
				pt = pt->a;
			}
			cp->mlin[2][0] = nminus;
			cp->mlin[2][1] = nplus;
			cp->mlin[2][2] = nminus+nplus;
			cp->nodemut =  (
								cp->mlin[0][0]*cp->mlin[1][0]*cp->mlin[2][1] +
								cp->mlin[0][1]*cp->mlin[1][1]*cp->mlin[2][0] > 0);
			pars->nodemut_indic += cp->nodemut;
		}
		
	}

	pars->pspace = MUTLIN_ADD_P + MUTNODE_ADD_P;
	if(pars->evswap_indic)pars->pspace += ESWAP_PROB;
	if(pars->linmut_indic)pars->pspace += MUTLIN_DEL_P;
	if(pars->nodemut_indic)pars->pspace += MUTNODE_DEL_P;
	if(pars->linswap_indic)pars->pspace += LSWAP_PROB;
}

void fill_tree(Node **list,int *freq,int *val,int noall,int sno,int *nn,int
				*nc,Cnode *clist,Genpars *pars)
{
	Node *lastp,*p1,*pt,*pn,*p2,*pp;
	Cnode *cp;
	int i,k,cumt,up,numlin,mutval,ic,nplus,nminus,j,*tvec,itemp,it1,it2,it3;
	double tt,tim1;
	int *ix,event_type,mut_target;
	double rr,rcheck,event_time;
	
	tvec = (int *)malloc(sno*sizeof(int));
	ix = (int *)malloc(2000*sizeof(int));
	mut_target = 0;
	for(i=0,k=0,cumt=freq[0];i<sno;++i){
		while(i>=cumt){ /* cumt for this only*/
			++k;
			if(k>=noall)printerr("fill_tree: k>=noall");
			cumt += freq[k];
		}
		tvec[i] = val[k]; /* this fills individual vector from freq. vectors */
		mut_target += val[k];
	}
	mut_target = (float)mut_target/sno + 0.5;
	
	for(i=0;i<sno-1;++i){ /* creates a random permutation - prob unnecessary */
		itemp = tvec[i];
		ic = disrand(i+1,sno-1);
		tvec[i] = tvec[ic];
		tvec[ic] = itemp;
	}
	for(i=0;i<sno;++i){
		list[i]->val = tvec[i];
		list[i]->type = 0;
		list[i]->time = 0.0;
		list[i]->time2 = 0.0;
		list[i]->nlin = 0;
		list[i]->tlr = NULL;
		list[i]->tlf = NULL;
		list[i]->a = NULL;
		list[i]->dl = NULL;
		list[i]->dr = NULL;
		list[i]->pos = i;
		list[i]->mark = -1;
		list[i]->lno = i;
		list[i]->cp = NULL;
	}
	free(tvec);
	
	*nn = sno;
	tt = 0.0;
	list[0]->nlin = sno;
	lastp = list[0];
	*nc = 0;
	pars->linmut_indic = 0;
	event_time = 0.0;
	while(*nc < sno-1){
		if(*nn > 1995)printerr("fill_tree: *nn > 1995 (too many muts - change init params)");
		numlin = sno - *nc; /* numlin only changed here. No. of uncoalesced lineages */
		getevent(event_time,numlin,&event_type,&event_time,pars);
		
		it1 = disrand(0,numlin-1); /* choose first one */
		for(i=0;i<*nn;++i){
			if(list[i]->a == NULL){
				if(it1 == 0)break;
				--it1;
			}
		}
		if(i == *nn)printerr("fill_tree: fallen through loop 1");
		
		p1 = list[i];
		if(event_type == 2){  /* coalescence */
			/* choose a second */
			p2 = NULL;
			for(j=0;j<*nn;++j)ix[j] = j;
			for(i=0;i<*nn;++i){
				if(i < *nn-1){
					itemp = ix[i];
					ic = disrand(i+1,*nn-1);
					ix[i] = ix[ic];
					ix[ic] = itemp;
				}
				j = ix[i]; /* this chooses a random permutation of lineages */
				if(list[j]->a == NULL && list[j] != p1 && list[j]->val == p1->val){
					p2 = list[j];
					break;
				}
			}
			if(p2 == NULL)event_type = 1;
		}
		if(event_type == 1){
			/* choose mutation */
			if(p1->val == mut_target){
				mutval = p1->val + disrand(0,1)*2 - 1;
			}
			else if(p1->val > mut_target)mutval = p1->val -1;
			else mutval = p1->val +1;
			
			/* make the mutation */
			p1 = mutate(list,nn,p1,event_time,mutval,p1->lno);
			p1->dl->a = p1;
			p1->nlin = numlin;
			p1->tlr = lastp;
			lastp->tlf = p1;
			lastp = p1;			
		}
		else{ /* do all the things for coalescence */
		
			p1 = coalesce(list,nn,p1,p2,event_time);
			p1->lno = sno + *nc;
			p1->nlin = numlin;
			p1->tlr = lastp;
			lastp->tlf = p1;
			lastp = p1;
			++(*nc);
			
	/*--------------------------------------------------------
	This bit added to load mlin, cumdpmlist, and diffpairtot 
	--------------------------------------------------------*/
			/* left branch */
			ic = (*nc)-1;/* ic is the clist entry */
			clist[ic].mark[0] = -1;
			clist[ic].mark[1] = -1;
			nplus = 0;
			nminus = 0;
			pt = p1->dl;
			while(pt->type == 1){
				if(pt->val-pt->dl->val < 0)++nminus;
				else ++nplus;
				pt = pt->dl;
			}
			clist[ic].mlin[0][0] = nminus; 
			 	/* NB: minus (-1) refers back in time : ie the ancestor is 
					shorter; the descendent is longer */
			clist[ic].mlin[0][1] = nplus;
			clist[ic].mlin[0][2] = nminus + nplus;
			clist[ic].p = p1;
			p1->cp = &(clist[ic]);
			clist[ic].cpos = ic;
			clist[ic].l = pt;
			if(pt->type == 2){/*pt should be either type 0 or type 2 */
				pt->cp->u = p1;  
			}
			
			pt = p1->tlr;
			while(!(pt->type == 0  || pt->type == 2))pt=pt->tlr;
			clist[ic].tr = pt;
			if(pt ->type != 0)pt->cp->tf = p1;
			clist[ic].linmut[0] = (nminus*nplus > 0);
			pars->linmut_indic += clist[ic].linmut[0];
			
			
			/* right branch */
			nplus = 0;
			nminus = 0;
			pt = p1->dr;
			while(pt->type == 1){
				if(pt->val-pt->dl->val < 0)++nminus;
				else ++nplus;
				pt = pt->dl;
			}
			clist[ic].r = pt;
			if(pt->type == 2){
				pt->cp->u = p1;
			}
			clist[ic].mlin[1][0] = nminus;
			clist[ic].mlin[1][1] = nplus;
			clist[ic].mlin[1][2] = nplus + nminus;
			clist[ic].linmut[1] = (nminus*nplus > 0);
			pars->linmut_indic += clist[ic].linmut[1];
		}
		
	}
	free(ix);
	lastp->tlf = NULL;
	if(*nc != sno-1)printerr("fill_tree: nc != sno-1");
	clist[*nc-1].u = NULL;
	clist[*nc-1].tf = NULL;
	/* this bit fills in the upper lineage for mlin, 
			and gives node3_tot and cumnode3list */
	pars->nodemut_indic = 0;
	pars->linswap_indic = 0;
	pars->evswap_indic = 0;
	for(j=0;j<*nn;++j){
		if(linswap_cal(list[j])){
			list[j]->linswap = 1;
			++pars->linswap_indic;
		}
		else list[j]->linswap = 0;
		list[j]->evswap = swapable(list[j]);
		pars->evswap_indic += list[j]->evswap;
	}
	
	pars->lwt_tot = 0.0;
	pars->nwt_tot = 0.0;
	pars->lwt_max = -1.0;
	pars->nwt_max = -1.0;
	
	for(j=0;j<*nc;++j){
		cp = &(clist[j]);
		pp = cp->p;

		if(pars->lwt_max < (tim1 = lwt_cal(pp,0)))
			pars->lwt_max = tim1;
		cp->lwt[0] = tim1;
		pars->lwt_tot += tim1;
		if(pars->lwt_max < (tim1 = lwt_cal(pp,1)))
			pars->lwt_max = tim1;
		cp->lwt[1] = tim1;
		pars->lwt_tot += tim1;
		
		if(pars->nwt_max < (tim1 = nwt_cal(pp)))
			pars->nwt_max = tim1;
		pars->nwt_tot += tim1;
		cp->nwt = tim1;
		
		pt = cp->p->a;
		if(pt==NULL){
			cp->mlin[2][0] = 0;
			cp->mlin[2][1] = 0;
			cp->mlin[2][2] = 0;
			cp->nodemut = (cp->mlin[0][0]*cp->mlin[1][0] +
								cp->mlin[0][1]*cp->mlin[1][1] > 0);
			pars->nodemut_indic += cp->nodemut;
		}
		else{
			nplus = nminus = 0;
			while(pt->type == 1){
				if(pt->val-pt->dl->val < 0)++nminus;
				else ++nplus;
				pt = pt->a;
			}
			cp->mlin[2][0] = nminus;
			cp->mlin[2][1] = nplus;
			cp->mlin[2][2] = nminus+nplus;
			cp->nodemut =  (
								cp->mlin[0][0]*cp->mlin[1][0]*cp->mlin[2][1] +
								cp->mlin[0][1]*cp->mlin[1][1]*cp->mlin[2][0] > 0);
			pars->nodemut_indic += cp->nodemut;
		}
		
	}

	pars->pspace = MUTLIN_ADD_P + MUTNODE_ADD_P;
	if(pars->evswap_indic)pars->pspace += ESWAP_PROB;
	if(pars->linmut_indic)pars->pspace += MUTLIN_DEL_P;
	if(pars->nodemut_indic)pars->pspace += MUTNODE_DEL_P;
	if(pars->linswap_indic)pars->pspace += LSWAP_PROB;
}

void getevent(double t0,int nlin, int *event_type,double *event_time,Genpars *pars)
{
	int j;
	double t1a,t1b,lambda_t,coalrate,cprob,rr;
	for(j=0;j<100;++j){
		t1a = cosim(t0,nlin,pars->r,pars->tf,pars->which_model);
		t1b = t0 + expdev()/(0.5*nlin*pars->theta);
		if(t1a < t1b)*event_time = t1a;
		else *event_time = t1b;
		
		if(*event_time > t0)break;
	}
	if(j == 100)printerr("getevent: problem setting newtime");
	
	if(pars->which_model == 0){  /* linear model */
		if(*event_time > pars->tf)lambda_t = pars->r;
		else lambda_t = pars->r*pars->tf/(pars->r*pars->tf + 
			(1.0-pars->r)*(*event_time));
	}
	else if(pars->which_model == 1){ /* exponential model */
		if(*event_time > pars->tf)lambda_t = pars->r;
		else lambda_t = pow(pars->r,*event_time/pars->tf);
	}
	else printerr("getevent: which_model wrong");
	coalrate = nlin*(nlin-1.0)*0.5*lambda_t;
	cprob = coalrate/(coalrate+0.5*nlin*pars->theta);
	rr = gfsr8();
	if(rr < cprob) *event_type = 2;
	else *event_type = 1;
	return;
}

Node *mutate(Node **list,int *nn,Node *n1,double tt,int mutval,int lno)
{

	int lnn;
	lnn = *nn;
		
	list[lnn]->val = mutval;
	list[lnn]->type = 1;
	list[lnn]->time = tt;
	list[lnn]->a = NULL;
	list[lnn]->tlf = NULL;
	list[lnn]->dl = n1;
	if(list[lnn]->dl->time > list[lnn]->time)
		printerr("mutate: time wrong");
	else if(list[lnn]->dl->time == list[lnn]->time){
		list[lnn]->time *= 1.000001;
	}
	list[lnn]->dr = NULL;
	list[lnn]->pos = lnn;
	list[lnn]->mark = -1;
	list[lnn]->lno = lno;
	list[lnn]->linswap=list[lnn]->linswap2 = 0;
	list[lnn]->evswap = list[lnn]->evswap2 = 0;
	list[lnn]->cp = NULL;
	++(*nn);
	return list[lnn];
}

							
Node *coalesce(Node **list,int *nn,Node *n1,Node *n2,double tt)
{
	int lnn;
	lnn = *nn;
	n1->a = n2->a = list[lnn];
	if(n1->val != n2->val)printerr("coalesce: n1->val != n2->val");
	list[lnn]->val = n1->val;
	list[lnn]->type = 2;
	list[lnn]->time = tt;
	list[lnn]->a = NULL;
	list[lnn]->tlf = NULL;
	list[lnn]->dl = n1;
	if(list[lnn]->dl->time >= list[lnn]->time)
		printerr("coalesce: time wrong");
	list[lnn]->dr = n2;
	if(list[lnn]->dl->time >= list[lnn]->time)
		printerr("coalesce: time wrong");
	list[lnn]->pos = lnn;
	list[lnn]->mark = -1;
	list[lnn]->linswap = list[lnn]->linswap2 = 0;
	list[lnn]->evswap = list[lnn]->evswap2 = 0;
	list[lnn]->cp = NULL;
	++(*nn);
	return list[lnn];
}

void twiddle(Node **list,int *oldnn, int *nn, Cnode *clist,int nc,Node **mlist,
	int *mm,Cnode **cmlist,int *cmm,int *mtype,
	Genpars *pars)
{
	int j,ifail;
	float rr;
	
	*oldnn = *nn;
	*mm = 0;
	pars->nwt_tot2 = pars->nwt_tot;
	pars->nwt_max2 = pars->nwt_max;
	pars->lwt_tot2 = pars->lwt_tot;
	pars->lwt_max2 = pars->lwt_max;
	pars->linswap_indic2 = pars->linswap_indic;
	pars->evswap_indic2 = pars->evswap_indic;
	pars->linmut_indic2 = pars->linmut_indic;
	pars->nodemut_indic2 = pars->nodemut_indic;
	pars->pspace2 = pars->pspace;
	for(j=0;j<10000;++j){
		ifail = 0;
		rr = gfsr8();
		if(rr < MUTLIN_ADD_P){
			mutlin_add2(list,nn,clist,nc,mlist,mm,cmlist,cmm,pars);
			*mtype = 1;
		}
		else if(rr < CUM_MUTLIN_DEL_P){
			mutlin_del2(list,nn,clist,nc,&ifail,mlist,mm,cmlist,cmm,pars);
			*mtype = 2;
		}
		else if(rr < CUM_MUTNODE_ADD_P){
			mutnode_add3(list,nn,clist,nc,mlist,mm,cmlist,cmm,mtype,pars);
		}
		else if(rr < CUM_MUTNODE_DEL_P){
			mutnode_del3(list,nn,clist,nc,&ifail,mlist,mm,cmlist,cmm,
				mtype,pars);
		}
		else if(rr < CUM_ESWAP_PROB){
			if(pars->evswap_indic){
				eventswap(list,*nn,mlist,mm,cmlist,cmm,pars);
				*mtype = 12;
			}
			else{
				ifail = 1;
			}
		}
		else if(rr < CUM_LSWAP_PROB){
			if(pars->linswap_indic){
				linswap(list,*nn,mlist,mm,cmlist,cmm,pars);
				*mtype = 16;
			}
			else{
				ifail = 1;
			}
		}
		if(!ifail)return;
	}
	printerr("twiddle: fallen through loop");
}

void tchange(Genpars *pars,Cnode *clist,Node **mlist,int *mm,Cnode **cmlist,int *cmm)
{
	int nc,j,ii;
	Node *pp,scratch;
	Cnode cscratch;
	double t0,t1a,t1b,newtime,oldtime,tim1;
	static double tvec[2000];
	
	nc = pars->sno-1;
	pp = pars->base->tlf;
	tvec[0] = 0;
	ii = 1;
	while(pp!=NULL){
		t0 = tvec[ii-1];
		t1a = cosim(t0,pp->nlin,pars->r,pars->tf,pars->which_model);
		t1b = t0 + expdev()/(0.5*pp->nlin*pars->theta);
		if(t1a < t1b)newtime = t1a;
		else newtime = t1b;
			
		if(newtime <= t0){
			Illegal = 1;
			break;
		}
		
		tvec[ii++] = newtime;
		pp = pp->tlf;

	}
	
	pp = pars->base->tlf;
	oldtime = pp->tlr->time;
	ii = 1;
	while(pp!=NULL){
		t0 = pp->tlr->time;

		if(!Illegal)scratch.time = tvec[ii];
		else scratch.time = pp->time;
		markup(pp,"time",&scratch,mlist,mm);
		if(scratch.time <= t0)printf("scratch.time is %e, t0 is %e\n", scratch.time,t0);
		pars->tpf += tdens(t0,scratch.time,pp->nlin,
				pars->theta,pars->r,pars->tf,pars->which_model);
				/* used to have pp->tlr->time2 for oldtime, but this may 
				not be set for first pass */
		if(pp->time2 <= oldtime)printf("pp->time2 is %e,oldtime is %e\n",
								pp->time2,oldtime);
		pars->tpr += tdens(oldtime,pp->time2,pp->nlin,
				pars->theta2,pars->r2,pars->tf2,pars->which_model);
		oldtime = pp->time2;
		pp = pp->tlf;
		++ii;
	}

	pp = pars->base->tlf;
	pars->lwt_tot = 0.0;
	pars->nwt_tot = 0.0;
	pars->lwt_max = -1.0;
	pars->nwt_max = -1.0;
	for(j=0;j<nc;++j){
		pp = clist[j].p;

		tim1 = lwt_cal(pp,0);
		cscratch.lwt[0] = tim1;
		cmarkup(&clist[j],"lwt0",&cscratch,cmlist,cmm);
		if(pars->lwt_max < tim1)pars->lwt_max = tim1;
		pars->lwt_tot += tim1;

		tim1 = lwt_cal(pp,1);
		cscratch.lwt[1] = tim1;
		cmarkup(&clist[j],"lwt1",&cscratch,cmlist,cmm);
		if(pars->lwt_max < tim1)pars->lwt_max = tim1;
		pars->lwt_tot += tim1;

		tim1 = nwt_cal(pp);
		cscratch.nwt = tim1;
		cmarkup(&clist[j],"nwt",&cscratch,cmlist,cmm);					
		if(pars->nwt_max < tim1)pars->nwt_max = tim1;
		pars->nwt_tot += tim1;
	}
}	


void proptchange(struct Gplist *ptlist,Genpars *pars,Cnode *clist,Node **mlist,int *mm,Cnode **cmlist,int *cmm)
{
	int nc,j;
	Node *pp,scratch;
	Cnode cscratch;
	double t0,t1a,t1b,newtime,oldtime,tim1,dd,edd,dd2,edd2;
	
	if(ptlist->tfuni || (!ptlist->scale_tf && !ptlist->scale_r))return;
	
	dd = ptlist->dd;
	edd = exp(dd);
	
	nc = pars->sno-1;
	pp = pars->base->tlf;
	
	if(!ptlist->scale_tf){
		dd2 = 0.0;
		edd2 = 1.0;
	}
	else{
		dd2 = dd;
		edd2 = edd;
	}
	oldtime = 0.0;
	while(pp!=NULL){
		newtime = pp->tlr->time + edd2*(pp->time - oldtime);
		scratch.time = newtime;
		markup(pp,"time",&scratch,mlist,mm);
		pars->tpr += dd2;
		oldtime = pp->time2;
		if(pp->time >= pars->tfa && pp->tlr->time < pars->tfa){
			if(!(pp->time2 >= pars->tfa2 && pp->tlr->time2 < pars->tfa2))
				printerr("proptchange - inconsistency 1");
			if(fabs(pp->time2/pp->time - pars->tfa2/pars->tfa) > 1.0e-6)
				printerr("proptchange - inconsistency 2");
			break;
		}
		pp = pp->tlf;
	}
	
	if(pp == NULL){ /* tf must be above tmrca */
		if(fabs(oldtime/newtime - pars->tfa2/pars->tfa) > 1.0e-6)
			printerr ("propchange: inconsistency 3");
	}
	else{  /* we need to do the upper bits */
		
		if(!ptlist->scale_r){
			dd2 = 0.0;
			edd2 = 1.0;
		}
		else{
			dd2 = dd;
			edd2 = edd;
		}
		pp = pp->tlf;
		while(pp!=NULL){
			newtime = pp->tlr->time + edd2*(pp->time - oldtime);
			scratch.time = newtime;
			markup(pp,"time",&scratch,mlist,mm);
			pars->tpr += dd2;
			oldtime = pp->time2;
			pp = pp->tlf;
		}
	}
	pp = pars->base->tlf;
	pars->lwt_tot = 0.0;
	pars->nwt_tot = 0.0;
	pars->lwt_max = -1.0;
	pars->nwt_max = -1.0;
	for(j=0;j<nc;++j){    /* this is a copy from tchange - bits may be redundant */
		pp = clist[j].p;

		tim1 = lwt_cal(pp,0);
		cscratch.lwt[0] = tim1;
		cmarkup(&clist[j],"lwt0",&cscratch,cmlist,cmm);
		if(pars->lwt_max < tim1)pars->lwt_max = tim1;
		pars->lwt_tot += tim1;

		tim1 = lwt_cal(pp,1);
		cscratch.lwt[1] = tim1;
		cmarkup(&clist[j],"lwt1",&cscratch,cmlist,cmm);
		if(pars->lwt_max < tim1)pars->lwt_max = tim1;
		pars->lwt_tot += tim1;

		tim1 = nwt_cal(pp);
		cscratch.nwt = tim1;
		cmarkup(&clist[j],"nwt",&cscratch,cmlist,cmm);					
		if(pars->nwt_max < tim1)pars->nwt_max = tim1;
		pars->nwt_tot += tim1;
	}
}	


int swapable(Node *p)
{
	if(p == NULL)printerr("swapable: null input ");
	if(p->type == 0)return 0;
	if(p->a == NULL)return 0;
	if(p->tlf == p->a){
		if(p->type == 1 && p->tlf->type == 1)return 1;
		else return 0;
	}
	return 1;
}



void linswap(Node **list,int nn,Node **mlist,int *mm,Cnode **cmlist,int *cmm,Genpars *pars)
{
	int j,ic,left1,lr1,left2,lr2,vec[3],nmtot,nodp,linp,lmtot,esptot,esp,
	nnitot,nnip,ll,ltot,nplus,nminus,rb;
	Node *pt1,*pt2,*pt1a,*pt2a,*pt,*cpt1d,*cpt2d,scratch,*ptt,*top;
	Cnode *cpt1,*cpt2,cscratch;
	char *lrstr1,*mlinstr1,*linmutstr1,*lrstr2,*mlinstr2,*linmutstr2,*lwtstr1,*lwtstr2;
	double dnwt,dlwt,tim1;
	
	for(j=0;j<100*nn;++j){
		ic = disrand(0,nn-1);
		if(list[ic]->linswap)break;
	}
	pt1 = list[ic];if(pt1 == NULL)printerr("linswap: pt1 == NULL");
	pt1a = pt1->a;if(pt1a == NULL)printerr("linswap: pt1a == NULL");
	pt2 = list[ic]->tlf;if(pt2 == NULL)printerr("linswap: pt2 == NULL");
	pt2a = pt2->a;if(pt2a == NULL)printerr("linswap: pt2a == NULL");
	
	if(pt1a != pt2a) markup(pt1,"a",pt2a,mlist,mm);
	if(pt1a->type==2 && pt1a->dr == pt1){
		markup(pt1a,"dr",pt2,mlist,mm);
		rb = 1;
	}
	else{
		markup(pt1a,"dl",pt2,mlist,mm);
		rb = 0;
	}
	
	if(pt1a == pt2a){
		if(!rb)markup(pt2a,"dr",pt1,mlist,mm);
		else markup(pt2a,"dl",pt1,mlist,mm);
	
	}
	else{
		markup(pt2,"a",pt1a,mlist,mm);
		if(pt2a->type == 2 && pt2a->dr == pt2){
			markup(pt2a,"dr",pt1,mlist,mm);
		}
		else{
			markup(pt2a,"dl",pt1,mlist,mm);
		}
	}
	/* redo lineage numbers above pt2 */
	pt = pt2->a;
	while(1){
		if(pt->type == 2)break;
		scratch.lno = pt2->lno;
		markup(pt,"lno",&scratch,mlist,mm);
		pt = pt->a;
		if(pt == NULL)printerr("linswap: pt == NULL");
	}
	cpt1 = pt->cp;/*cnode originally above pt1 - now above pt2 */
	if(cpt1 == NULL)printerr("linswap: cpt1 == NULL");

	/* redo lineage numbers above pt1 */
	pt = pt1->a;
	while(1){
		if(pt->type == 2)break;
		scratch.lno = pt1->lno;
		markup(pt,"lno",&scratch,mlist,mm);
		pt = pt->a;
		if(pt == NULL)printerr("linswap: pt == NULL (2)");
	}
	cpt2 = pt->cp;/*cnode originally above pt2 - now above pt1 */
	if(cpt2 == NULL)printerr("linswap: cpt2 == NULL");
	
	
	/* which side are we attached to */
	if(cpt1->p->dl->lno == pt2->lno)left1 = 1;
	else if(cpt1->p->dr->lno == pt2->lno)left1 = 0;
	else printerr("linswap: problems with left1");
	left2 = cpt2->p->dl->lno == pt1->lno;
	if(cpt2->p->dl->lno == pt1->lno)left2 = 1;
	else if(cpt2->p->dr->lno == pt1->lno)left2 = 0;
	else printerr("linswap: problems with left2");
	
	/*make general indicators to save repeating code */
	if(left1){
		lrstr1 = "l";
		cpt1d = cpt1->l;
		lr1 = 0;
		mlinstr1 = "mlin0";
		linmutstr1 = "linmut0";
		lwtstr1 = "lwt0";
	}
	else{
		lrstr1 = "r";
		cpt1d = cpt1->r;
		lr1 = 1;
		mlinstr1 = "mlin1";
		linmutstr1 = "linmut1";
		lwtstr1 = "lwt1";
	}
	if(left2){
		lrstr2 = "l";
		cpt2d = cpt2->l;
		lr2 = 0;
		mlinstr2 = "mlin0";
		linmutstr2 = "linmut0";
		lwtstr2 = "lwt0";
	}
	else{
		lrstr2 = "r";
		cpt2d = cpt2->r;
		lr2 = 1;
		mlinstr2 = "mlin1";
		linmutstr2 = "linmut1";
		lwtstr2 = "lwt1";
	}
	if(cpt1d == NULL || cpt2d == NULL)printerr("linswap: cpt1d/cpt2d == NULL");
	
	/* swap cnode pointers */
	cscratch.p = cpt1d;
	cmarkup(cpt2,lrstr2,&cscratch,cmlist,cmm);
	if(cpt1d->type != 0)cmarkup(cpt1d->cp,"u",cpt2,cmlist,cmm);
	cscratch.p = cpt2d;
	cmarkup(cpt1,lrstr1,&cscratch,cmlist,cmm);
	if(cpt2d->type != 0)cmarkup(cpt2d->cp,"u",cpt1,cmlist,cmm);
	
	/* check the mutations along lineages */
	/* one branch */
	nplus = nminus = 0;
	for(pt=cpt1d->a;pt!=cpt2->p;pt=pt->a){
		if(pt->type != 1)printerr("linswap: pt->type != 1 (1)");
		if(pt->val-pt->dl->val < 0)++nminus;
		else ++nplus;
	}
	vec[0] = nminus;vec[1] = nplus;vec[2] = nplus+nminus;
	assimlin(&cscratch,vec,lr2);
	cmarkup(cpt2,mlinstr2,&cscratch,cmlist,cmm);
	if(cpt1d->type != 0){
		assimlin(&cscratch,vec,2);
		cmarkup(cpt1d->cp,"mlin2",&cscratch,cmlist,cmm);
	}
	
	/*other branch*/
	nplus = nminus = 0;
	for(pt=cpt2d->a;pt!=cpt1->p;pt=pt->a){
		if(pt->type != 1)printerr("linswap: pt->type != 1 (2)");
		if(pt->val-pt->dl->val < 0)++nminus;
		else ++nplus;
	}
	vec[0] = nminus;vec[1] = nplus;vec[2] = nplus+nminus;
	assimlin(&cscratch,vec,lr1);
	cmarkup(cpt1,mlinstr1,&cscratch,cmlist,cmm);
	if(cpt2d->type != 0){
		assimlin(&cscratch,vec,2);
		cmarkup(cpt2d->cp,"mlin2",&cscratch,cmlist,cmm);
	}
	
	/*check for conservation */
	if(cpt1->mlin[lr1][0] + cpt2->mlin[lr2][0] != 
		cpt1->mlin2[lr1][0] + cpt2->mlin2[lr2][0])
			printerr("linswap: mutval not conserved 0");
	if(cpt1->mlin[lr1][1] + cpt2->mlin[lr2][1] != 
		cpt1->mlin2[lr1][1] + cpt2->mlin2[lr2][1])
			printerr("linswap: mutval not conserved 1");
			
	nmtot = lmtot = 0;
	nodp = cal_nodeprob(cpt1->mlin,cpt1->u==NULL);
	tim1 = nwt_cal(cpt1->p);
	dnwt = dlwt = 0.0;
	if(tim1 != cpt1->nwt){
		cscratch.nwt = tim1;
		cmarkup(cpt1,"nwt",&cscratch,cmlist,cmm);
		dnwt += cpt1->nwt - cpt1->nwt2;
		if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
	}
		
	if(nodp != cpt1->nodemut){
		nmtot += nodp-cpt1->nodemut;
		cscratch.nodemut = nodp;
		cmarkup(cpt1,"nodemut",&cscratch,cmlist,cmm);
	}
	linp = cal_linprob(cpt1->mlin,lr1);
	tim1 = lwt_cal(cpt1->p,lr1);
	if(tim1 != cpt1->lwt[lr1]){
		cscratch.lwt[lr1] = tim1;
		cmarkup(cpt1,lwtstr1,&cscratch,cmlist,cmm);
		dlwt += cpt1->lwt[lr1] - cpt1->lwt2[lr1];
		if(tim1 > pars->lwt_max)pars->lwt_max = tim1;
	}
	if(linp != cpt1->linmut[lr1]){
		lmtot += linp - cpt1->linmut[lr1];
		cscratch.linmut[lr1] = linp;
		cmarkup(cpt1,linmutstr1,&cscratch,cmlist,cmm);
	}
	if(cpt1d->type != 0){
		nodp = cal_nodeprob(cpt1d->cp->mlin,0);
		tim1 = nwt_cal(cpt1d);
		if(tim1 != cpt1d->cp->nwt){
			cscratch.nwt = tim1;
			cmarkup(cpt1d->cp,"nwt",&cscratch,cmlist,cmm);
			dnwt += cpt1d->cp->nwt - cpt1d->cp->nwt2;
			if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		}
		if(nodp != cpt1d->cp->nodemut){
			nmtot += nodp - cpt1d->cp->nodemut;
			cscratch.nodemut = nodp;
			cmarkup(cpt1d->cp,"nodemut",&cscratch,cmlist,cmm);
		}
	}
	tim1 = nwt_cal(cpt2->p);
	if(tim1 != cpt2->nwt){
		cscratch.nwt = tim1;
		cmarkup(cpt2,"nwt",&cscratch,cmlist,cmm);
		dnwt += cpt2->nwt - cpt2->nwt2;
		if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
	}
		
	nodp = cal_nodeprob(cpt2->mlin,cpt2->u==NULL);
	if(nodp != cpt2->nodemut){
		nmtot += nodp - cpt2->nodemut;
		cscratch.nodemut = nodp;
		cmarkup(cpt2,"nodemut",&cscratch,cmlist,cmm);
	}
	tim1 = lwt_cal(cpt2->p,lr2);
	if(tim1 != cpt2->lwt[lr2]){
		cscratch.lwt[lr2] = tim1;
		cmarkup(cpt2,lwtstr2,&cscratch,cmlist,cmm);
		dlwt += cpt2->lwt[lr2] - cpt2->lwt2[lr2];
		if(tim1 > pars->lwt_max)pars->lwt_max = tim1;
	}
	linp = cal_linprob(cpt2->mlin,lr2);
	if(linp != cpt2->linmut[lr2]){
		lmtot += linp - cpt2->linmut[lr2];
		cscratch.linmut[lr2] = linp;
		cmarkup(cpt2,linmutstr2,&cscratch,cmlist,cmm);
	}
	if(cpt2d->type != 0){
		tim1 = nwt_cal(cpt2d);
		if(tim1 != cpt2d->cp->nwt){
			cscratch.nwt = tim1;
			cmarkup(cpt2d->cp,"nwt",&cscratch,cmlist,cmm);
			dnwt += cpt2d->cp->nwt - cpt2d->cp->nwt2;
			if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		}
		nodp = cal_nodeprob(cpt2d->cp->mlin,0);
		if(nodp != cpt2d->cp->nodemut){
			nmtot += nodp - cpt2d->cp->nodemut;
			cscratch.nodemut = nodp;
			cmarkup(cpt2d->cp,"nodemut",&cscratch,cmlist,cmm);
		}
	}
	pars->nwt_tot += dnwt;
	pars->lwt_tot += dlwt;
	pars->nodemut_indic += nmtot;
	pars->linmut_indic += lmtot;
	
	esptot = 0;
	if(pt1->tlr->type ==0)ptt = pt1;
	else ptt = pt1->tlr;
	if(ptt->tlr->type != 0)ptt = ptt->tlr;
	
	if(pt2->tlf->tlf != NULL)top = pt2->tlf->tlf;
	else top = pt2->tlf;
	for(;ptt!=top;ptt=ptt->tlf){
	
		esp = swapable(ptt);
		if(esp != ptt->evswap){
			esptot += esp - ptt->evswap;
			scratch.evswap = esp;
			markup(ptt,"evswap",&scratch,mlist,mm);
		}
	} 
	
	pars->evswap_indic += esptot;

	if(pars->evswap_indic == 0 && pars->evswap_indic2 > 0)pars->pspace -= ESWAP_PROB;
	else if(pars->evswap_indic > 0 && pars->evswap_indic2 == 0)pars->pspace += ESWAP_PROB;
	
	if(pars->nodemut_indic == 0 && pars->nodemut_indic2 > 0)pars->pspace -= MUTNODE_DEL_P;
	else if(pars->nodemut_indic > 0 && pars->nodemut_indic2 == 0)pars->pspace += MUTNODE_DEL_P;
	
	if(pars->linmut_indic == 0 && pars->linmut_indic2 > 0)pars->pspace -= MUTLIN_DEL_P;
	else if(pars->linmut_indic > 0 && pars->linmut_indic2 == 0)pars->pspace += MUTLIN_DEL_P;
	
	ll = linswap_cal(pt2);
	ltot = 0;
	if(ll != pt2->linswap){
		scratch.linswap = ll;
		markup(pt2,"linswap",&scratch,mlist,mm);
		ltot += pt2->linswap - pt2->linswap2;
	}
	pars->linswap_indic += ltot;
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	else if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	
	pars->lik = pars->lik2 = 0.0;
	pars->tpf = -log(pars->pspace2);
	pars->tpr = -log(pars->pspace);
	
}

void assimlin(Cnode *cpt,int vec[],int lr)
{
	cpt->mlin[lr][0] = vec[0];
	cpt->mlin[lr][1] = vec[1];
	cpt->mlin[lr][2] = vec[2];
	
}

void eventswap(Node **list,int nn,Node **mlist,int *mm,Cnode **cmlist,int *cmm,
	Genpars *pars)
{

	int j,ic,oldswaptot,changecst,dval,dval2,irl,nl,nl2,ii,ltot,ll,
		sno,newswaptot,switchbot;
	double tt,tt2,tim1,dlwt,dnwt;
	Node *pt2,*pt,*p1,*p2,*bot,*top,*oldtlf,*olda,scratch,*pw,*pv,*oldtf;
	Cnode cscratch;
	char *lwtstr;
	
	sno = pars->sno;
	
	for(j=0;j<100*nn;++j){
		ic = disrand(sno,nn-1); 
		if(list[ic]->evswap){
			break;
		}
	}
	if(j== 100*nn)printerr("eventswap: fallen through loop");
	
	pt2 = list[ic];
	pt = list[ic]->tlf;
	
	if(pt2->tlr->type == 0)oldswaptot = swapable(pt);
	else oldswaptot = swapable(pt) + swapable(pt2->tlr);
	
	
	bot = pt2->tlr;
	if(bot->type == 0)bot = pars->base->tlf;
	if(bot == pt2)switchbot = 1;
	else switchbot = 0;
	top = pt->tlf;
	
	/* find upper coalescent node */
	
	changecst = 0;
	if(!(pt2->type == 1 && pt->type == 1)){
		if(pt2->type == 1){
			p2 = pt2;
			while(p2->type == 1)p2 = p2->a;
		}
		else p2 = pt2->cp->u;
		if(pt->type == 1){
			p1 = pt;
			while(p1->type == 1)p1 = p1->a;
		}
		else p1 = pt->cp->u;
		if(p1 == p2){
			changecst = 1;
		}
	}
	
	/* calculate old likelihood in this segment*/
	
	pars->lik2 = lik_cal(bot,top,pars);
	
	if(pt2->type == 1 && pt->type == 1){
		dval = pt->val - pt2->val;
		dval2 = pt2->val - pt2->dl->val;
	}
	
	/* basic to all event swaps */
	
	tt = pt->time;
	tt2 = pt2->time;
	scratch.time = tt2;
	markup(pt,"time",&scratch,mlist,mm);
	scratch.time = tt;
	markup(pt2,"time",&scratch,mlist,mm);
	
	/* deal with coalescent time stats here */
	dnwt = dlwt = 0.0;
	
	for(j=0;j<2;++j){
	
		if(j == 0)pw = pt;
		else pw = pt2;
		
		if(pw->type != 2)continue;
		/* affected node */
		tim1 = nwt_cal(pw);
		cscratch.nwt = tim1;
		cmarkup(pw->cp,"nwt",&cscratch,cmlist,cmm);
		dnwt += pw->cp->nwt - pw->cp->nwt2;
		if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		
		tim1 = lwt_cal(pw,0);
		cscratch.lwt[0] = tim1;
		cmarkup(pw->cp,"lwt0",&cscratch,cmlist,cmm);
		dlwt += pw->cp->lwt[0] - pw->cp->lwt2[0];
		if(tim1 > pars->lwt_max)pars->lwt_max = tim1;
		
		tim1 = lwt_cal(pw,1);
		cscratch.lwt[1] = tim1;
		cmarkup(pw->cp,"lwt1",&cscratch,cmlist,cmm);
		dlwt += pw->cp->lwt[1] - pw->cp->lwt2[1];
		if(tim1 > pars->lwt_max)pars->lwt_max = tim1;
		
		/* left descendent */
		pv = pw->cp->l;
		if(pv->type != 0){
			tim1 = nwt_cal(pv);
			cscratch.nwt = tim1;
			cmarkup(pv->cp,"nwt",&cscratch,cmlist,cmm);
			dnwt += pv->cp->nwt - pv->cp->nwt2;
			if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		}
		
		/* right descendent */
		pv = pw->cp->r;
		if(pv->type != 0){
			tim1 = nwt_cal(pv);
			cscratch.nwt = tim1;
			cmarkup(pv->cp,"nwt",&cscratch,cmlist,cmm);
			dnwt += pv->cp->nwt - pv->cp->nwt2;
			if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		}
		
		/* ancestor */
		pv = cfind_up(pw,&irl);
		if(irl == 0)lwtstr = "lwt0";
		else if(irl == 1) lwtstr = "lwt1";
		else printerr("eventswap: irl wrong");
		
		tim1 = nwt_cal(pv);
		cscratch.nwt = tim1;
		cmarkup(pv->cp,"nwt",&cscratch,cmlist,cmm);
		dnwt += pv->cp->nwt - pv->cp->nwt2;
		if(tim1 > pars->nwt_max)pars->nwt_max = tim1;
		
		tim1 = lwt_cal(pv,irl);
		cscratch.lwt[irl] = tim1;
		cmarkup(pv->cp,lwtstr,&cscratch,cmlist,cmm);
		dlwt += pv->cp->lwt[irl] - pv->cp->lwt2[irl];
		if(tim1 > pars->lwt_max)pars->lwt_max = tim1;
		
	}
	
	pars->lwt_tot += dlwt;
	pars->nwt_tot += dnwt;
		
		
		
	
	oldtlf = pt->tlf;
	markup(pt,"tlf",pt2,mlist,mm);
	markup(pt,"tlr",pt2->tlr,mlist,mm);
	markup(pt->tlr,"tlf",pt,mlist,mm);
	markup(pt2,"tlf",oldtlf,mlist,mm);
	markup(pt2->tlf,"tlr",pt2,mlist,mm);
	markup(pt2,"tlr",pt,mlist,mm);
	
	/* two mutations in same lineage */
	
	if(pt2->a == pt){
		olda = pt->a;
		irl = 0;
		if(olda->type == 2){
			if(olda->dl == pt)irl = 0;
			else if(olda->dr == pt)irl = 1;
			else printerr("eventswap: olda wrong");
			
		}
		markup(pt,"a",pt2,mlist,mm);
		markup(pt,"dl",pt2->dl,mlist,mm);
		markup(pt->dl,"a",pt,mlist,mm);
		scratch.val = pt->dl->val + dval;
		markup(pt,"val",&scratch,mlist,mm);
		markup(pt2,"a",olda,mlist,mm);
		if(irl == 0)markup(pt2->a,"dl",pt2,mlist,mm);
		else markup(pt2->a,"dr",pt2,mlist,mm);
		markup(pt2,"dl",pt,mlist,mm);
		scratch.val = pt2->dl->val+dval2;
		markup(pt2,"val",&scratch,mlist,mm);
	}
	
	nl = pt->nlin;
	nl2 = pt2->nlin;
	
	
	/* swapping two coalescent events */
	
	if(pt->type == 2 && pt2->type == 2){
	
		scratch.nlin = nl2;
		markup(pt,"nlin",&scratch,mlist,mm);
		scratch.nlin = nl;
		markup(pt2,"nlin",&scratch,mlist,mm);
		
		/* deal with cp pointers here NBB!! MISSING IN EARLIER PROGRAMS */

		oldtf = pt->cp->tf;
		cmarkup(pt->cp,"tf",pt2->cp,cmlist,cmm);
		if(pt2->cp->tr->type == 0){
			cscratch.p = pt2->cp->tr;
			cmarkup(pt->cp,"tr",&cscratch,cmlist,cmm);
		}
		else cmarkup(pt->cp,"tr",pt2->cp->tr->cp,cmlist,cmm);
		if(pt->cp->tr->type !=0)
			cmarkup(pt->cp->tr->cp,"tf",pt->cp,cmlist,cmm);
		cmarkup(pt2->cp,"tf",oldtf->cp,cmlist,cmm);
		cmarkup(pt2->cp->tf->cp,"tr",pt2->cp,cmlist,cmm);
		cmarkup(pt2->cp,"tr",pt->cp,cmlist,cmm);
				
	}
	/* swapping coalescent event and mutation */
	else if(pt->type == 2 && pt2->type == 1){
		scratch.nlin = nl-1;
		markup(pt2,"nlin",&scratch,mlist,mm);
	}
	else if(pt->type == 1 && pt2->type == 2){
		scratch.nlin = nl2;
		markup(pt,"nlin",&scratch,mlist,mm);
	}


	
	newswaptot = swapable(pt2);
	scratch.evswap = newswaptot;
	markup(pt2,"evswap",&scratch,mlist,mm);
	
	ii = swapable(pt); /* we don't include this in newswaptot because it not in oldswaptot */
	if(ii != 1)printerr("eswaptot: ii != 1");
	scratch.evswap = ii;
	markup(pt,"evswap",&scratch,mlist,mm);
	
	if(pt->tlr->type != 0){
		newswaptot += (ii = swapable(pt->tlr));
		scratch.evswap = ii;
		markup(pt->tlr,"evswap",&scratch,mlist,mm);
	}
	
	if(switchbot)bot = pars->base->tlf;
	
	ltot = 0;
	for(pt=bot;pt!=top->tlf;pt=pt->tlf){
		if(pt==NULL)printerr("linswap: pt==NULL");
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap-pt->linswap2;
		}
	}
	pars->linswap_indic += ltot;
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	
	pars->evswap_indic += newswaptot - oldswaptot;
	
	
	pars->lik =lik_cal(bot,top,pars);
	pars->tpf = log(1.0/pars->pspace2/pars->evswap_indic2);
	pars->tpr = log(1.0/pars->pspace/pars->evswap_indic);
	
	return;
	
	
}



void mutlin_add2(Node **list,int *nn, Cnode *clist,int nc,Node **mlist,int *mm,
	Cnode **cmlist,int *cmm,Genpars *pars)
{
	int ic,v1,v2,mutval,d,newcval,ic2,dn1,anc,npairs,dl1,dnn,redobot,ltot,cur_lno,ll,
		etot,ee,irl;
	Node *p1,*p2,*p3,*pt,*pm1,*pm2,scratch;
	Node *plintop,*plinbot,*pevtop,*pevbot;
	Cnode cscratch;
	double deltat,mt1,mt2,temp,rr;
	char *str;

	/* choose a type 2 node at random */
	
	while(1){
		ic = disrand(0,nc-1); 
		irl = disrand(0,1);  /* 0 - left lineage, 1 - right lineage */
		rr = gfsr4()*pars->lwt_max;
		if(clist[ic].lwt[irl] > rr)break;
	}
	
	p1 = clist[ic].p;
	anc = p1->a == NULL;
	p2 = cfind_down(p1,irl); /* find the next non-mutation node down */
	p3 = cfind_down(p1,!(irl));/* other node */

	v1 = disrand(0,1);
	v2 = !v1;           /* Mutations go in opposite direction.
	                        v1 and v2 determine which direction the
	                        mutations go respectively for mt1 and mt2 
	                        1 -> + : 0 -> - , going back in time*/
	                        
	deltat = p1->time - p2->time;
	mt1 = p2->time + gfsr8()*deltat;
	mt2 = p2->time + gfsr8()*deltat;
	
	if(mt1 > mt2){
		temp = mt1;
		mt1 = mt2;
		mt2 = temp;
	}
	/* need to identify the highest and lowest points in the region to be
		transformed */
	
	plinbot = p2; /* work up from the bottom node */
	while(1){
		if(plinbot->a->time >= mt1)break;
		plinbot = plinbot->a;
	}  /* plinbot is the node lower than mt1 */
	
	pevbot = plinbot;
	if(pevbot->type == 0)pevbot = pars->base->tlf;
	while(1){
		if(pevbot->tlf->time >= mt1)break;
		pevbot = pevbot->tlf;
	}
	
	if(pevbot->time > mt1)redobot = 1;
	else redobot = 0;
	
	plintop = plinbot;
	while(1){
		if(plintop->a->time > mt2)break;
		plintop = plintop->a;
	}
	
	pevtop = plintop;
	if(pevtop->type == 0)pevtop = pars->base->tlf;
	while(1){
		if(pevtop->tlf->time > mt2)break;
		pevtop = pevtop->tlf;
	}
	pevtop = pevtop->tlf;
	
	
	/* if(pevtop != NULL)pevtop = pevtop->tlf;   testing */
	/* if(pevbot->type != 0)pevbot = pevbot->tlr;  testing */
	/*  if(pevbot->type != 0)pevbot = pevbot->tlr; testing */
	
	pars->lik2 = lik_cal(pevbot,pevtop,pars);
	
	pt = plinbot;
	mutval = v1 ? pt->val + 1 : pt->val - 1; /* determines actual value */
	pm1 = insertmut(list,nn,mt1,pt,mutval,mlist,mm,pt->lno);
	pt = pm1;
	while(1){ /* this is inefficient because it is repeated */
		if(pt->a->time > mt2)break;
		pt = pt->a;
		scratch.val = pt->val + (v1 ? 1 : -1); /* incr/decr val along lineage */
		markup(pt,"val",&scratch,mlist,mm);
	}  /* pt is the node lower than mt2 */
	

	mutval = v2 ? pt->val + 1 : pt->val - 1;
	pm2 = insertmut(list,nn,mt2,pt,mutval,mlist,mm,pt->lno);
	if(pm2->a->type == 1){
		d = abs(pm2->a->val - pm2->val);
		if(d == 0 || d > 1)printerr("mutlin: error 1");
	}
	else{
		if(pm2->a->type != 2)printerr("mutlin: error 2");
		if(pm2->a->val != pm2->val)printerr("mutlin: error 3");
	}
	
/*!!!!!!!!!!!! calculate transition probs here !!!!!!!!!!!!!!!!!*/
	
	
	
	pars->tpf =
	log(1.0/(deltat*deltat)*MUTLIN_ADD_P*clist[ic].lwt[irl]/pars->lwt_tot
			/pars->pspace); 
			
	
/* Does the transformation move diffpair_tot=0 -> diffpair_tot>0 ? 
   Does the transformation move node3_tot=0 -> node3_tot>0 ?
   Does the transformation move cswaptot=0 -> cswap>0
   Does the transformation move cswaptot>0 ->cswaptot=0 */
   
	cscratch.mlin[irl][0] = clist[ic].mlin[irl][0]+1;
	cscratch.mlin[irl][1] = clist[ic].mlin[irl][1]+1;
	cscratch.mlin[irl][2] = clist[ic].mlin[irl][2]+2;
	if(irl == 0)str = "mlin0";
	else str = "mlin1";
	cmarkup(&clist[ic],str,&cscratch,cmlist,cmm);
	dl1 = cal_linprob(clist[ic].mlin,irl);
	if(dl1 != clist[ic].linmut[irl]){
		cscratch.linmut[irl] = dl1;
		if(irl == 0)str = "linmut0";
		else str = "linmut1";
		cmarkup(&clist[ic],str,&cscratch,cmlist,cmm);
		++pars->linmut_indic;
		if(pars->linmut_indic == 1)pars->pspace += MUTLIN_DEL_P;
	}
	
	ic2 = findinclist(p2);
	if(ic2 >= 0){
		cscratch.mlin[2][0] = clist[ic2].mlin[2][0]+1;
		cscratch.mlin[2][1] = clist[ic2].mlin[2][1]+1;
		cscratch.mlin[2][2] = clist[ic2].mlin[2][2]+2;
		cmarkup(&clist[ic2],"mlin2",&cscratch,cmlist,cmm);
	}
	dn1 = cal_nodeprob(clist[ic].mlin,anc);
	if(dn1 != clist[ic].nodemut){
		cscratch.nodemut = dn1;
		cmarkup(&clist[ic],"nodemut",&cscratch,cmlist,cmm);
		dnn = clist[ic].nodemut - clist[ic].nodemut2;
	}
	else dnn = 0;
		
	if(ic2 >= 0){
		dn1 = cal_nodeprob(clist[ic2].mlin,0); /* not anc node */
		if(dn1 != clist[ic2].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic2],"nodemut",&cscratch,cmlist,cmm);
			dnn += clist[ic2].nodemut - clist[ic2].nodemut2;
		}
		
	}
	if(pars->nodemut_indic == 0){
		if(dnn > 0)pars->pspace += MUTNODE_DEL_P;
	}
	pars->nodemut_indic += dnn;
	
	
	etot = 0;
	
	if(pm1->tlr->type != 0){
		ee = swapable(pm1->tlr);
		if(ee != pm1->tlr->evswap){
			etot += ee - pm1->tlr->evswap;
			scratch.evswap = ee;
			markup(pm1->tlr,"evswap",&scratch,mlist,mm);
		}
	}
	
	ee = swapable(pm1);
	if(ee != pm1->evswap){
		etot += ee - pm1->evswap;
		scratch.evswap = ee;
		markup(pm1,"evswap",&scratch,mlist,mm);
	}
	
	if(pm2->tlr != pm1){
		ee = swapable(pm2->tlr);
		if(ee != pm2->tlr->evswap){
			etot += ee - pm2->tlr->evswap;
			scratch.evswap = ee;
			markup(pm2->tlr,"evswap",&scratch,mlist,mm);
		}
	}
	ee = swapable(pm2);
	if(ee != pm2->evswap){
		etot += ee - pm2->evswap;
		scratch.evswap = ee;
		markup(pm2,"evswap",&scratch,mlist,mm);
	}
	
	pars->evswap_indic += etot;
	if(pars->evswap_indic2 > 0 && pars->evswap_indic == 0) pars->pspace -= ESWAP_PROB;
	if(pars->evswap_indic2 == 0 && pars->evswap_indic > 0) pars->pspace += ESWAP_PROB;
	
	ltot = 0;
	cur_lno = p2->lno;
	for(pt=pm1;pt != pm2->a->a;pt=pt->a){ 
		if(pt == NULL)printerr("addmut: pt is NULL");
		if(pt == pm1 || !(pt->tlr->lno == cur_lno)){
			ll = linswap_cal(pt->tlr);
			if(ll != pt->tlr->linswap){
				scratch.linswap = ll;
				markup(pt->tlr,"linswap",&scratch,mlist,mm);
				ltot += pt->tlr->linswap - pt->tlr->linswap2;
			}
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	
	pars->linswap_indic += ltot;
	
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	
	
	npairs = clist[ic].mlin[irl][0]*clist[ic].mlin[irl][1];
	
	if(redobot)pevbot = pars->base->tlf;
	pars->lik = lik_cal(pevbot,pevtop,pars);
	
	pars->tpr = log(MUTLIN_DEL_P/(pars->pspace*pars->linmut_indic*npairs));
	
	
	return;
}


void mutlin_del2(Node **list,int *nn, Cnode *clist,int nc,int *ifail,
	Node **mlist,int *mm,Cnode **cmlist,int *cmm,
	Genpars *pars)
{
	int ic,ic1,ic2,dm1,j,id,newcval,dl1,dn1,anc,nminus,nplus,npairs,dnn,cur_lno,ltot,ll,
		etot,ee,irl;
	Node *pt,*pt2,*p1,*p2,*p3,scratch,*pm1,*pm2;
	Node *pevbot,*pevtop,*rev1,*rev2,*linbot,*lintop;
	Cnode cscratch,*cp;
	double deltat;
	char *str;

	if(pars->linmut_indic == 0){
		*ifail = 1;
		return;
	}
	*ifail = 0;	
	
	
	for(j=0;j<10000*nc;++j){
		id = disrand(0,2*nc-1);
		ic = id/2;
		irl = id%2;
		if(clist[ic].linmut[irl])break;
	}
	if(j>= 10000*nc)printerr("mutlin_del2: fallen through loop");
	p1 = clist[ic].p;
	anc = p1->a == NULL;
	p2 = cfind_down(p1,irl); /* find the next non-mutation node down */
	p3 = cfind_down(p1,!(irl)); /* other lineage for oldcval */
	
	deltat = p1->time - p2->time;
	

	nminus = clist[ic].mlin[irl][0];
	nplus = clist[ic].mlin[irl][1];
	ic1 = disrand(1,nminus);
	ic2 = disrand(1,nplus);
	pt = p2->a;
	for(j=0;j<100000;++j){
		if(pt == NULL)printerr("mutlin_del2: pt == NULL");
		if(pt->type != 1){
			printerr("mutlin_del2: error choosing nodes");
		}
		if(ic1 > 0 && pt->val - pt->dl->val == -1){
			--ic1;
			if(ic1 == 0)pm1 = pt;
		}
		else if(ic2 > 0 && pt->val - pt->dl->val == 1){
			--ic2;
			if(ic2 == 0)pm2 = pt;
		}
		if(ic1==0 && ic2 == 0)break;
		pt = pt->a;
	}
	if(j>=100000)printerr("mutlin_del2: fallen through loop");	
	if(pm1->val - pm1->dl->val != -1)printerr("mutlin_del2: error choosing -1 mut");
	if(pm2->val - pm2->dl->val != 1)printerr("mutlin_del2: error choosing +1 mut");
		
	etot = -(pm1->evswap + pm2->evswap);
	ltot = -(pm1->linswap + pm2->linswap);/* do this now because they are deleted later */
	if(pm1->time < pm2->time){
		rev1 = pevbot = pm1->tlr;
		pevtop = pm2->tlf;
		rev2 = pm2->tlr;
		if(rev2 == pm1)rev2 = NULL; /* don't want to count it twice */
		pt = pm1->a;
		pt2 = pm2;
		linbot = pm1->dl;
		if(linbot->type == 0){
			linbot = pm1->a;
			if(linbot == pm2){
				linbot = linbot->a;
			}
		}
		lintop = pm2->a;
	}
	else {
		rev1 = pevbot = pm2->tlr;
		pevtop = pm1->tlf;
		rev2 = pm1->tlr;
		if(rev2 == pm2)rev2 = NULL; /* don't want to count it twice */
		pt = pm2->a;
		pt2 = pm1;
		linbot = pm2->dl;
		if(linbot->type == 0){
			linbot = pm2->a;
			if(linbot == pm1){
				linbot = linbot->a;
			}
		}
		lintop = pm1->a;
	}
	/* we need rev1 and rev2 for calculating linswap & evswap params */
	dm1 = pt->dl->val - pt->dl->dl->val;
	
	pars->lik2 = lik_cal(pevbot,pevtop,pars);
	
	while(pt != pt2){
		scratch.val = pt->val - dm1;
		markup(pt,"val",&scratch,mlist,mm);
		pt = pt->a;
	}
	
	
	
	if(pm1->time < pm2->time){pt = pm1;pt2 = pm2;}
	else{pt = pm2;pt2 = pm1;}/* for old eswaptot may be fossil */
		

	
/**** delete mutations here **********/	
	
	deletemut(pm1,list,nn,mlist,mm);
	deletemut(pm2,list,nn,mlist,mm);

/****                      **********/	
	
	
	
	
	/* calculate transition probs here */
	
	
	cp = &(clist[ic]);
	npairs = cp->mlin[irl][0]*cp->mlin[irl][1];
	pars->tpf = log(MUTLIN_DEL_P/(pars->pspace*pars->linmut_indic*npairs));
	
	
/* Does the transformation move diffpair_tot>0 -> diffpair_tot=0 ? 
   Does the transformation move node3_tot>0 -> node3_tot=0 ?
   Does the transformation move cswaptot=0 -> cswap>0
   Does the transformation move cswaptot>0 ->cswaptot=0 */
   
	cscratch.mlin[irl][0] = clist[ic].mlin[irl][0]-1;
	cscratch.mlin[irl][1] = clist[ic].mlin[irl][1]-1;
	cscratch.mlin[irl][2] = clist[ic].mlin[irl][2]-2;
	if(irl == 0)str = "mlin0";
	else str = "mlin1";
	cmarkup(&clist[ic],str,&cscratch,cmlist,cmm);
	
	dl1 = cal_linprob(clist[ic].mlin,irl);
	if(dl1 != clist[ic].linmut[irl]){
		cscratch.linmut[irl] = dl1;
		if(irl == 0)str = "linmut0";
		else str = "linmut1";
		cmarkup(&clist[ic],str,&cscratch,cmlist,cmm);
		--pars->linmut_indic;
		if(pars->linmut_indic == 0)pars->pspace -= MUTLIN_DEL_P;
	}
	
	ic2 = findinclist(p2);
	if(ic2 >= 0){
		cscratch.mlin[2][0] = clist[ic2].mlin[2][0]-1;
		cscratch.mlin[2][1] = clist[ic2].mlin[2][1]-1;
		cscratch.mlin[2][2] = clist[ic2].mlin[2][2]-2;
		cmarkup(&clist[ic2],"mlin2",&cscratch,cmlist,cmm);
	}
	dn1 = cal_nodeprob(clist[ic].mlin,anc);
	if(dn1 != clist[ic].nodemut){
		cscratch.nodemut = dn1;
		cmarkup(&clist[ic],"nodemut",&cscratch,cmlist,cmm);
		dnn = clist[ic].nodemut - clist[ic].nodemut2;
	}
	else dnn = 0;
		
	if(ic2 >= 0){
		dn1 = cal_nodeprob(clist[ic2].mlin,0); /* not anc node */
		if(dn1 != clist[ic2].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic2],"nodemut",&cscratch,cmlist,cmm);
			dnn += clist[ic2].nodemut - clist[ic2].nodemut2;
		}
		
	}
	pars->nodemut_indic += dnn;
	if(pars->nodemut_indic2 > 0 && pars->nodemut_indic == 0){
		pars->pspace -= MUTNODE_DEL_P;
	}
	
	/*ltot initialized earlier */
	cur_lno = p2->lno;
	for(pt=linbot;pt != lintop->a;pt=pt->a){ 
		if(pt == NULL)printerr("linmut_del2: pt == NULL");
		ll = linswap_cal(pt->tlr);
		if(ll != pt->tlr->linswap){
			scratch.linswap = ll;
			markup(pt->tlr,"linswap",&scratch,mlist,mm);
			ltot += pt->tlr->linswap - pt->tlr->linswap2;
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	
	if(rev1 != NULL){
		ll = linswap_cal(rev1);
		if(ll != rev1->linswap){
			scratch.linswap = ll;
			markup(rev1,"linswap",&scratch,mlist,mm);
			ltot += rev1->linswap - rev1->linswap2;
		}
	}
	if(rev2 != NULL){
		ll = linswap_cal(rev2);
		if(ll != rev2->linswap){
			scratch.linswap = ll;
			markup(rev2,"linswap",&scratch,mlist,mm);
			ltot += rev2->linswap - rev2->linswap2;
		}
	}
	pars->linswap_indic += ltot;
	
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	
	/* etot initialized earlier */
	
	if(rev1 != NULL){
		ee = swapable(rev1);
		if(ee != rev1->evswap){
			etot += ee - rev1->evswap;
			scratch.evswap = ee;
			markup(rev1,"evswap",&scratch,mlist,mm);
		}
	}
	
	if(rev2 != NULL){
		ee = swapable(rev2);
		if(ee != rev2->evswap){
			etot += ee - rev2->evswap;
			scratch.evswap = ee;
			markup(rev2,"evswap",&scratch,mlist,mm);
		}
	}
	
	pars->evswap_indic += etot;
	
	if(pars->evswap_indic == 0 && pars->evswap_indic2 > 0)pars->pspace -= ESWAP_PROB;
	if(pars->evswap_indic > 0 && pars->evswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	

	pars->tpr = log(1.0/(deltat*deltat)*MUTLIN_ADD_P*clist[ic].lwt[irl]/pars->lwt_tot/
			pars->pspace); 
			
	pars->lik = lik_cal(pevbot,pevtop,pars);
	
			
	return;
}
		
		
void mutnode_add3(Node **list,int *nn, Cnode *clist,int nc,Node **mlist,int *mm,
	Cnode **cmlist,int *cmm,int *mtype,Genpars *pars)
{
	int ic,v1,v2,mutval,d,rl,newcval1,newcval2,
		anc,dl1,dn1,ic2,ic3,ic4,ntriples,redobot,ltot,ll,
		etot,ee;
	Node *p1,*p12,*pu,*pl,*pr,*ppu,*ppl,*ppr,*pmu,*pml,*pmr,scratch,
		*op1,*op12,*opu,*opl,*opr,*opml,*opmr,*opmu,*pm1,*pm2,*pt;
	Node *pevtop,*pevbotl,*pevbotr,*pevbot;
	Cnode cscratch,*cp;
	double dtu,dtl,dtr,mtu,mtl,mtr,rr;
	char *str;


	while(1){
		ic = disrand(0,nc-1); 
		rr = gfsr4()*pars->nwt_max;
		if(clist[ic].nwt > rr)break;
	}
	
	op1 = p1 = clist[ic].p;
	opu = pu = cfind_up(p1,&rl);
	anc = pu == NULL;
	if(!anc) op12 = p12 = cfind_down(pu,!rl);
	opl = pl = cfind_down(p1,0);
	opr = pr = cfind_down(p1,1);
	
	v1 = disrand(0,1); /* if v1 is 1: plus mutation on left, right lineages: 
				minus mutation upper lineage */
	v2 = !v1;
	
	if(v1)*mtype = 3;
	else *mtype = 4;
	
	
	
	if(pu != NULL){
		dtu = pu->time - p1->time;
		if(dtu < 0.0)printerr("mutnode_add3: error 1");
	}
	dtl = p1->time - pl->time;
	if(dtl < 0.0)printerr("mutnode_add3: error 2");
	dtr = p1->time - pr->time;
	if(dtr < 0.0)printerr("mutnode_add3: error 3");
	
	if(pu != NULL)mtu = p1->time + gfsr8()*dtu;
	mtl = pl->time + gfsr8()*dtl;
	if(mtl == pl->time)printerr("mutnode_add3: time wrong");
	mtr = pr->time + gfsr8()*dtr;

	if(pu != NULL){
		ppu = p1;
		while(1){
			if(ppu->a->time > mtu)break;
			ppu = ppu->a;
		}/* ppu is the node with time less than mtu */
		
		pevtop = ppu;
		while(1){
			if(pevtop->tlf->time > mtu)break;
			pevtop = pevtop->tlf;
		}
		pevtop = pevtop->tlf;
	}
	else pevtop = NULL;
	
	ppl = pl;
	while(1){
		if(ppl->a->time > mtl)break;
		ppl = ppl->a;
	}/* ppl is the node with time less than mtl */
	
	pevbotl = ppl;
	if(pevbotl->type == 0)pevbotl = pars->base->tlf;
	
	while(1){
		if(pevbotl->tlf->time > mtl)break;
		pevbotl = pevbotl->tlf;
	}
	
	ppr = pr;
	while(1){
		if(ppr->a->time > mtr)break;
		ppr = ppr->a;
	}/* ppr is the node with time less than mtr */
	
	pevbotr = ppr;
	if(pevbotr->type == 0)pevbotr = pars->base->tlf;
	while(1){
		if(pevbotr->tlf->time > mtr)break;
		pevbotr = pevbotr->tlf;
	}
	pevbot = pevbotl->time > pevbotr->time ? pevbotr : pevbotl;
	
	if(pevbot->time > mtl || pevbot->time > mtr)redobot = 1;
	else redobot = 0;
	
	pars->lik2 = lik_cal(pevbot,pevtop,pars);

	mutval = v1 ? ppl->val + 1 : ppl->val -1;
	opml = pml = insertmut(list,nn,mtl,ppl,mutval,mlist,mm,ppl->lno);
	
	mutval = v1 ? ppr->val + 1 : ppr->val -1;
	opmr = pmr = insertmut(list,nn,mtr,ppr,mutval,mlist,mm,ppr->lno);
	
	while(1){
		if(pml->a->type == 2)break;
		pml = pml->a;
		scratch.val = pml->val + (v1 ? 1 : -1);
		markup(pml,"val",&scratch,mlist,mm);
	}
	
	while(1){
		if(pmr->a->type == 2)break;
		pmr = pmr->a;
		scratch.val = pmr->val + (v1 ? 1 : -1);
		markup(pmr,"val",&scratch,mlist,mm);
	}
	
	if(pmr->a != pml->a)printerr("mutnode_add3: pmr,pml wrong");
	
	pml = pml->a;   
	/* arbitrarily choose left lineage pointer to take us up to mtu */
	scratch.val = pml->val + (v1 ? 1 : -1);
	markup(pml,"val",&scratch,mlist,mm);  /* markup the coalescent node itself */
	
	if(pu != NULL){

		while(1){
			if(pml->a->time > mtu)break;
			pml = pml->a;
			scratch.val = pml->val + (v1 ? 1 : -1);
			markup(pml,"val",&scratch,mlist,mm);
		} /*pml is now the node with time less than mtu */
		
		mutval = v2 ? pml->val + 1 : pml->val - 1;
		opmu = pmu = insertmut(list,nn,mtu,pml,mutval,mlist,mm,pml->lno);
		if(pmu->a->type == 1){
			d = abs(pmu->a->val - pmu->val);
			if(d == 0 || d > 1)printerr("mutnode_add3: error 4");
		}
		else{
			if(pmu->a->type != 2)printerr("mutnode_add3: error 5");
			if(pmu->a->val != pmu->val)printerr("mutnode_add3: error 6");
		}
		
	}
		
	
	/* do transition probs here */
	
	/* check that p1,p12,pl,pr remain the same */
	if(opml->time < opmr->time){pm1 = opml;pm2 = opmr;}
	else {pm1 = opmr;pm2 = opml;}
	
	
	
	if(anc){
		pars->tpf = log(MUTNODE_ADD_P*0.5/(dtl*dtr*pars->pspace)*clist[ic].nwt/
						pars->nwt_tot);
	}
	else{
		pars->tpf = log(MUTNODE_ADD_P*0.5/(dtu*dtl*dtr*pars->pspace)*clist[ic].nwt/
						pars->nwt_tot);
	}
	
/* Does the transformation move diffpair_tot=0 -> diffpair_tot>0 ? 
   Does the transformation move node3_tot=0 -> node3_tot>0 ?
   Does the transformation move cswaptot=0 -> cswap>0
   Does the transformation move cswaptot>0 ->cswaptot=0 */
	
	ic2 = findinclist(opu);
	ic3 = findinclist(opl);
	ic4 = findinclist(opr);
	
	cscratch.mlin[0][0] = clist[ic].mlin[0][0] + v2;
	cscratch.mlin[0][1] = clist[ic].mlin[0][1] + v1;
	cscratch.mlin[0][2] = cscratch.mlin[0][0] + cscratch.mlin[0][1];
	cmarkup(&clist[ic],"mlin0",&cscratch,cmlist,cmm);
	
	cscratch.mlin[1][0] = clist[ic].mlin[1][0] + v2;
	cscratch.mlin[1][1] = clist[ic].mlin[1][1] + v1;
	cscratch.mlin[1][2] = cscratch.mlin[1][0] + cscratch.mlin[1][1];
	cmarkup(&clist[ic],"mlin1",&cscratch,cmlist,cmm);
	
	if(!anc){
		cscratch.mlin[2][0] = clist[ic].mlin[2][0] + v1;
		cscratch.mlin[2][1] = clist[ic].mlin[2][1] + v2;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic],"mlin2",&cscratch,cmlist,cmm);
	}
	
	if(!anc){
		cscratch.mlin[rl][0] = clist[ic2].mlin[rl][0]+v1;
		cscratch.mlin[rl][1] = clist[ic2].mlin[rl][1]+v2;
		cscratch.mlin[rl][2] = cscratch.mlin[rl][0] + cscratch.mlin[rl][1];
		if(rl==0)str="mlin0";
		else str = "mlin1";
		cmarkup(&clist[ic2],str,&cscratch,cmlist,cmm);
	}
	if(ic3 >= 0){
		cscratch.mlin[2][0] = clist[ic3].mlin[2][0] + v2;
		cscratch.mlin[2][1] = clist[ic3].mlin[2][1] + v1;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic3],"mlin2",&cscratch,cmlist,cmm);
	}
	if(ic4 >= 0){
		cscratch.mlin[2][0] = clist[ic4].mlin[2][0] + v2;
		cscratch.mlin[2][1] = clist[ic4].mlin[2][1] + v1;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic4],"mlin2",&cscratch,cmlist,cmm);
	}
	
	dl1 = cal_linprob(clist[ic].mlin,0);
	if(dl1 != clist[ic].linmut[0]){
		cscratch.linmut[0] = dl1;
		cmarkup(&clist[ic],"linmut0",&cscratch,cmlist,cmm);
		++pars->linmut_indic;
		if(pars->linmut_indic == 1)pars->pspace += MUTLIN_DEL_P;
	}
	
	dl1 = cal_linprob(clist[ic].mlin,1);
	if(dl1 != clist[ic].linmut[1]){
		cscratch.linmut[1] = dl1;
		cmarkup(&clist[ic],"linmut1",&cscratch,cmlist,cmm);
		++pars->linmut_indic;
		if(pars->linmut_indic == 1)pars->pspace += MUTLIN_DEL_P;
	}
	
	if(!anc){
		dl1 = cal_linprob(clist[ic2].mlin,rl);
		if(dl1 != clist[ic2].linmut[rl]){
			cscratch.linmut[rl] = dl1;
			if(rl==0)str = "linmut0";
			else str = "linmut1";
			cmarkup(&clist[ic2],str,&cscratch,cmlist,cmm);
			++pars->linmut_indic;
			if(pars->linmut_indic == 1)pars->pspace += MUTLIN_DEL_P;
		}
	}
	
	dn1 = cal_nodeprob(clist[ic].mlin,anc);
	if(dn1 != clist[ic].nodemut){
		cscratch.nodemut = dn1;
		cmarkup(&clist[ic],"nodemut",&cscratch,cmlist,cmm);
		++pars->nodemut_indic;
	}
	if(!anc){
		dn1 = cal_nodeprob(clist[ic2].mlin,clist[ic2].u==NULL);
		if(dn1 != clist[ic2].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic2],"nodemut",&cscratch,cmlist,cmm);
			++pars->nodemut_indic;
		}
	}
	if(ic3>=0){
		dn1 = cal_nodeprob(clist[ic3].mlin,0);
		if(dn1 != clist[ic3].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic3],"nodemut",&cscratch,cmlist,cmm);
			++pars->nodemut_indic;
		}
	}
	if(ic4>=0){
		dn1 = cal_nodeprob(clist[ic4].mlin,0);
		if(dn1 != clist[ic4].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic4],"nodemut",&cscratch,cmlist,cmm);
			++pars->nodemut_indic;
		}
	}
	if(pars->nodemut_indic2 == 0 && pars->nodemut_indic > 0){
		pars->pspace += MUTNODE_DEL_P;
	}
	
	
	
	
	ltot = 0;
	for(pt=opml;pt != op1;pt=pt->a){ /* there may be a bit of repetition */
		if(pt == NULL)printerr("mutnode_add3: pt == NULL 1");
		ll = linswap_cal(pt->tlr);
		if(ll != pt->tlr->linswap){
			scratch.linswap = ll;
			markup(pt->tlr,"linswap",&scratch,mlist,mm);
			ltot += pt->tlr->linswap - pt->tlr->linswap2;
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	for(pt=opmr;pt != op1;pt=pt->a){/* there may be a bit of repetition */
		if(pt == NULL)printerr("mutnode_add3: pt == NULL 2");
		ll = linswap_cal(pt->tlr);
		if(ll != pt->tlr->linswap){
			scratch.linswap = ll;
			markup(pt->tlr,"linswap",&scratch,mlist,mm);
			ltot += pt->tlr->linswap - pt->tlr->linswap2;
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	if(!anc){
		for(pt=p1;pt != opmu->a->a;pt=pt->a){
			if(pt == NULL)printerr("mutnode_add3: pt == NULL 3");
			ll = linswap_cal(pt->tlr);
			if(ll != pt->tlr->linswap){
				scratch.linswap = ll;
				markup(pt->tlr,"linswap",&scratch,mlist,mm);
				ltot += pt->tlr->linswap - pt->tlr->linswap2;
			}
			
			ll = linswap_cal(pt);
			if(ll != pt->linswap){
				scratch.linswap = ll;
				markup(pt,"linswap",&scratch,mlist,mm);
				ltot += pt->linswap - pt->linswap2;
			}
		}
	}
	
	pars->linswap_indic += ltot;
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;

	etot = 0;
	
	if(opml->tlr->type != 0){
		ee = swapable(opml->tlr);
		if(ee != opml->tlr->evswap){
			etot += ee - opml->tlr->evswap;
			scratch.evswap = ee;
			markup(opml->tlr,"evswap",&scratch,mlist,mm);
		}
	}
	
	ee = swapable(opml);
	if(ee != opml->evswap){
		etot += ee - opml->evswap;
		scratch.evswap = ee;
		markup(opml,"evswap",&scratch,mlist,mm);
	}
	
	if(opmr->tlr->type != 0 && opmr->tlr != opml ){
		ee = swapable(opmr->tlr);
		if(ee != opmr->tlr->evswap){
			etot += ee - opmr->tlr->evswap;
			scratch.evswap = ee;
			markup(opmr->tlr,"evswap",&scratch,mlist,mm);
		}
	}
	if(opmr != opml->tlr){
		ee = swapable(opmr);
		if(ee != opmr->evswap){
			etot += ee - opmr->evswap;
			scratch.evswap = ee;
			markup(opmr,"evswap",&scratch,mlist,mm);
		}
	}
	
	if(!anc){
		ee = swapable(opmu->tlr);
		if(ee != opmu->tlr->evswap){
			etot += ee - opmu->tlr->evswap;
			scratch.evswap = ee;
			markup(opmu->tlr,"evswap",&scratch,mlist,mm);
		}
		ee = swapable(opmu);
		if(ee != opmu->evswap){
			etot += ee - opmu->evswap;
			scratch.evswap = ee;
			markup(opmu,"evswap",&scratch,mlist,mm);
		}
	}
	
	pars->evswap_indic += etot;
	if(pars->evswap_indic2 > 0 && pars->evswap_indic == 0) pars->pspace -= ESWAP_PROB;
	if(pars->evswap_indic2 == 0 && pars->evswap_indic > 0) pars->pspace += ESWAP_PROB;
	
	
	cp = &(clist[ic]);
	if(anc){
		ntriples = cp->mlin[0][0]*cp->mlin[1][0] + 
				cp->mlin[0][1]*cp->mlin[1][1];
	}
	else{
		ntriples = cp->mlin[0][0]*cp->mlin[1][0]*cp->mlin[2][1] + 
				cp->mlin[0][1]*cp->mlin[1][1]*cp->mlin[2][0];
	}
	
	if(redobot)pevbot = pars->base->tlf;
	pars->lik = lik_cal(pevbot,pevtop,pars);
	
	pars->tpr = log(MUTNODE_DEL_P/(pars->pspace*pars->nodemut_indic*ntriples));

	



	return;

}

void mutnode_del3(Node **list,int *nn, Cnode *clist,int nc,int *ifail,
	Node **mlist,int *mm,Cnode **cmlist,int *cmm,
	int *mtype,Genpars *pars)
{
	int ic,bigc,i,ic1,dmu,ic2,dml,ic3,ic4,dmr,v1,v2,anc,rl,dl1,
		dn1,j,ntriples,newcval1,newcval2,ltot,ll,etot,ee;
	Node *p1,*p12,*pl,*pu,*pr,scratch,*pt,*pt2,*op1,*opl,*opr,*opu,*op12,*pm1,*pm2;
	Node *pevbot,*pevtop,*revl,*revr,*revu,*pevbotl,*pevbotr,*linbotl,*linbotr;
	Cnode cscratch,*cp;
	double dtu,dtl,dtr;
	char *str;
	
	
	
	
	if(pars->nodemut_indic == 0){
		*ifail = 1;
		return;
	}
	*ifail = 0;

	for(j=0;j<10000*nc;++j){
		ic = disrand(0,nc-1);
		if(clist[ic].nodemut)break;
	}
	if(j>= 10000*nc)printerr("mutnode_del3: fallen through first loop");
	op1=p1 = clist[ic].p;
	bigc = p1->a == NULL;
	opu=pu = cfind_up(p1,&rl);
	anc = pu==NULL;
	if(!anc)op12=p12 = cfind_down(pu,!rl);
	opl=pl = cfind_down(p1,0);
	opr=pr = cfind_down(p1,1);
	
	if(!anc){
		dtu = opu->time - op1->time;
	}
	dtl = op1->time - opl->time;
	dtr = op1->time - opr->time;

	
	cp = &(clist[ic]);

	for(i=0;i<100000;++i){
		if(!bigc){
			ic1 = disrand(1,cp->mlin[2][0]+cp->mlin[2][1]);
			pu = getmnode(p1,"u",ic1);
			revu = pu->tlr;
			dmu = pu->val-pu->dl->val;
		}
		ic2 = disrand(1,cp->mlin[0][0]+cp->mlin[0][1]);
		pl = getmnode(p1,"l",ic2);
		revl = pl->tlr;
		dml = pl->val-pl->dl->val;
		if(!bigc && dml == dmu)continue;
		ic3 = disrand(1,cp->mlin[1][0]+cp->mlin[1][1]);
		pr = getmnode(p1,"r",ic3);
		revr = pr->tlr;
		dmr = pr->val - pr->dl->val;
		if(dmr == dml)break;
		
	}
	if(i==100000)printerr("mutnode_del3: fallen through loop");
	
	if(revl == pr)revl = NULL; /* avoid duplications */
	if(revr == pl)revr = NULL;
	if(revr == revl)revr = NULL;
	pevbotl = pl->tlr;
	pevbotr = pr->tlr;
	linbotl = pl->dl;
	if(linbotl->type == 0){
		linbotl = pl->a;
	}
	linbotr = pr->dl;
	if(linbotr->type == 0){
		linbotr = pr->a;
	}
	if(pl->tlr->time < pr->tlr->time)pevbot = pl->tlr;
	else pevbot = pr->tlr;
	
	ltot = 0;
	etot = 0;
	if(!bigc){
		pevtop = pu->tlf;
		ltot = -pu->linswap;
		etot = -pu->evswap;
	}
	else pevtop = NULL;
	
	etot += -(pl->evswap + pr->evswap);
	ltot += -(pl->linswap + pr->linswap);/* doing now because they are deleted later*/
	
	/* if(pevtop != NULL)pevtop = pevtop->tlf;  testing */
	/*if(pevbot->type != 0)pevbot = pevbot->tlr; testing */
	/*  if(pevbot->type != 0)pevbot = pevbot->tlr; testing */
	
	pars->lik2 = lik_cal(pevbot,pevtop,pars);
	
	if(dml == 1)*mtype = 5;
	else *mtype = 6;
	
	v1 = dml == 1;
	v2 = !v1;
	
	pt = pl;
	while(1){
		pt = pt->a;
		if(pt->type == 2)break;
		scratch.val = pt->val - dml;
		markup(pt,"val",&scratch,mlist,mm);
	}
	
	pt2 = pr;
	while(1){
		pt2 = pt2->a;
		if(pt2->type == 2)break;
		scratch.val = pt2->val - dmr;
		markup(pt2,"val",&scratch,mlist,mm);
	}
	
	if(pt2 != pt)printerr("mutnode_del3: pt2 != pt");
	
	/* this bit deals with the coalescent node */
	scratch.val = pt->val - dmr;
	markup(pt,"val",&scratch,mlist,mm);
	
	if(!bigc){
		while(1){
			pt = pt->a;
			if(pt == pu)break;
			scratch.val = pt->val - dml;
			markup(pt,"val",&scratch,mlist,mm);
		}
	}
	
	
	if(pl->time < pr->time){pm1 = pl;pm2 = pr;}
	else {pm1 = pr;pm2 = pl;}
		
	if(!bigc)deletemut(pu,list,nn,mlist,mm);
	deletemut(pl,list,nn,mlist,mm);
	deletemut(pr,list,nn,mlist,mm);

	/* do transition probs here */
	
	/* check that p1,p12,pl,pr remain the same */
	
	
	if(anc){
		ntriples = cp->mlin[0][0]*cp->mlin[1][0] + 
				cp->mlin[0][1]*cp->mlin[1][1];
	}
	else{
		ntriples = cp->mlin[0][0]*cp->mlin[1][0]*cp->mlin[2][1] + 
				cp->mlin[0][1]*cp->mlin[1][1]*cp->mlin[2][0];
	}
	
	
	pars->tpf = log(MUTNODE_DEL_P/(pars->pspace*pars->nodemut_indic*ntriples));

	
	
	
/* Does the transformation move diffpair_tot>0 -> diffpair_tot=0 ? 
   Does the transformation move node3_tot>0 -> node3_tot=0 ?
   Does the transformation move cswaptot=0 -> cswap>0
   Does the transformation move cswaptot>0 ->cswaptot=0 */
	
	if(!anc)ic2 = findinclist(opu);
	ic3 = findinclist(opl);
	ic4 = findinclist(opr);

	cscratch.mlin[0][0] = clist[ic].mlin[0][0] - v2;
	cscratch.mlin[0][1] = clist[ic].mlin[0][1] - v1;
	cscratch.mlin[0][2] = cscratch.mlin[0][0] + cscratch.mlin[0][1];
	cmarkup(&clist[ic],"mlin0",&cscratch,cmlist,cmm);
	
	cscratch.mlin[1][0] = clist[ic].mlin[1][0] - v2;
	cscratch.mlin[1][1] = clist[ic].mlin[1][1] - v1;
	cscratch.mlin[1][2] = cscratch.mlin[1][0] + cscratch.mlin[1][1];
	cmarkup(&clist[ic],"mlin1",&cscratch,cmlist,cmm);
	
	if(!anc){
		cscratch.mlin[2][0] = clist[ic].mlin[2][0] - v1;
		cscratch.mlin[2][1] = clist[ic].mlin[2][1] - v2;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic],"mlin2",&cscratch,cmlist,cmm);
	}
	
	if(!anc){
		cscratch.mlin[rl][0] = clist[ic2].mlin[rl][0]-v1;
		cscratch.mlin[rl][1] = clist[ic2].mlin[rl][1]-v2;
		cscratch.mlin[rl][2] = cscratch.mlin[rl][0] + cscratch.mlin[rl][1];
		if(rl==0)str="mlin0";
		else str = "mlin1";
		cmarkup(&clist[ic2],str,&cscratch,cmlist,cmm);
	}
	if(ic3 >= 0){
		cscratch.mlin[2][0] = clist[ic3].mlin[2][0] - v2;
		cscratch.mlin[2][1] = clist[ic3].mlin[2][1] - v1;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic3],"mlin2",&cscratch,cmlist,cmm);
	}
	if(ic4 >= 0){
		cscratch.mlin[2][0] = clist[ic4].mlin[2][0] - v2;
		cscratch.mlin[2][1] = clist[ic4].mlin[2][1] - v1;
		cscratch.mlin[2][2] = cscratch.mlin[2][0] + cscratch.mlin[2][1];
		cmarkup(&clist[ic4],"mlin2",&cscratch,cmlist,cmm);
	}



	dl1 = cal_linprob(clist[ic].mlin,0);
	if(dl1 != clist[ic].linmut[0]){
		cscratch.linmut[0] = dl1;
		cmarkup(&clist[ic],"linmut0",&cscratch,cmlist,cmm);
		--pars->linmut_indic;
		if(pars->linmut_indic == 0)pars->pspace -= MUTLIN_DEL_P;
	}
	
	dl1 = cal_linprob(clist[ic].mlin,1);
	if(dl1 != clist[ic].linmut[1]){
		cscratch.linmut[1] = dl1;
		cmarkup(&clist[ic],"linmut1",&cscratch,cmlist,cmm);
		--pars->linmut_indic;
		if(pars->linmut_indic == 0)pars->pspace -= MUTLIN_DEL_P;
	}
	
	if(!anc){
		dl1 = cal_linprob(clist[ic2].mlin,rl);
		if(dl1 != clist[ic2].linmut[rl]){
			cscratch.linmut[rl] = dl1;
			if(rl==0)str = "linmut0";
			else str = "linmut1";
			cmarkup(&clist[ic2],str,&cscratch,cmlist,cmm);
			--pars->linmut_indic;
			if(pars->linmut_indic == 0)pars->pspace -= MUTLIN_DEL_P;
		}
	}
	
	dn1 = cal_nodeprob(clist[ic].mlin,anc);
	if(dn1 != clist[ic].nodemut){
		cscratch.nodemut = dn1;
		cmarkup(&clist[ic],"nodemut",&cscratch,cmlist,cmm);
		--pars->nodemut_indic;
	}
	if(!anc){
		dn1 = cal_nodeprob(clist[ic2].mlin,clist[ic2].u==NULL);
		if(dn1 != clist[ic2].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic2],"nodemut",&cscratch,cmlist,cmm);
			--pars->nodemut_indic;
		}
	}
	if(ic3>=0){
		dn1 = cal_nodeprob(clist[ic3].mlin,0);
		if(dn1 != clist[ic3].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic3],"nodemut",&cscratch,cmlist,cmm);
			--pars->nodemut_indic;
		}
	}
	if(ic4>=0){
		dn1 = cal_nodeprob(clist[ic4].mlin,0);
		if(dn1 != clist[ic4].nodemut){
			cscratch.nodemut = dn1;
			cmarkup(&clist[ic4],"nodemut",&cscratch,cmlist,cmm);
			--pars->nodemut_indic;
		}
	}
	if(pars->nodemut_indic2 > 0 && pars->nodemut_indic == 0){
		pars->pspace -= MUTNODE_DEL_P;
	}
	
	

	/*ltot already initialized */
	for(pt=linbotl;pt != op1;pt=pt->a){
		if(pt == NULL)printerr("mutnode_del3: pt == NULL 1");
		ll = linswap_cal(pt->tlr);
		if(ll != pt->tlr->linswap){
			scratch.linswap = ll;
			markup(pt->tlr,"linswap",&scratch,mlist,mm);
			ltot += pt->tlr->linswap - pt->tlr->linswap2;
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	for(pt=linbotr;pt != op1;pt=pt->a){
		if(pt == NULL)printerr("mutnode_del3: pt == NULL 2");
		ll = linswap_cal(pt->tlr);
		if(ll != pt->tlr->linswap){
			scratch.linswap = ll;
			markup(pt->tlr,"linswap",&scratch,mlist,mm);
			ltot += pt->tlr->linswap - pt->tlr->linswap2;
		}
		
		ll = linswap_cal(pt);
		if(ll != pt->linswap){
			scratch.linswap = ll;
			markup(pt,"linswap",&scratch,mlist,mm);
			ltot += pt->linswap - pt->linswap2;
		}
	}
	if(!anc){
		for(pt=op1;pt != opu->a;pt=pt->a){
			if(pt == NULL)printerr("mutnode_del3: pt == NULL 3");
			ll = linswap_cal(pt->tlr);
			if(ll != pt->tlr->linswap){
				scratch.linswap = ll;
				markup(pt->tlr,"linswap",&scratch,mlist,mm);
				ltot += pt->tlr->linswap - pt->tlr->linswap2;
			}
			
			ll = linswap_cal(pt);
			if(ll != pt->linswap){
				scratch.linswap = ll;
				markup(pt,"linswap",&scratch,mlist,mm);
				ltot += pt->linswap - pt->linswap2;
			}
		}
	}
	
	/* check that revl or revr not deleted */
	if(revl != NULL){
		ll = linswap_cal(revl);
		if(ll != revl->linswap){
			scratch.linswap = ll;
			markup(revl,"linswap",&scratch,mlist,mm);
			ltot += revl->linswap - revl->linswap2;
		}
	}
	if(revr != NULL){
		ll = linswap_cal(revr);
		if(ll != revr->linswap){
			scratch.linswap = ll;
			markup(revr,"linswap",&scratch,mlist,mm);
			ltot += revr->linswap - revr->linswap2;
		}
	}
	if(!anc){
		ll = linswap_cal(revu);
		if(ll != revu->linswap){
			scratch.linswap = ll;
			markup(revu,"linswap",&scratch,mlist,mm);
			ltot += revu->linswap - revu->linswap2;
		}
	}
	
	
	pars->linswap_indic += ltot;
	if(pars->linswap_indic == 0 && pars->linswap_indic2 > 0)pars->pspace -= LSWAP_PROB;
	if(pars->linswap_indic > 0 && pars->linswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	
/* etot initialized earlier */
	if(revl != NULL){
		ee = swapable(revl);
		if(ee != revl->evswap){
			etot += ee - revl->evswap;
			scratch.evswap = ee;
			markup(revl,"evswap",&scratch,mlist,mm);
		}
	}
	
	if(revr != NULL){
		ee = swapable(revr);
		if(ee != revr->evswap){
			etot += ee - revr->evswap;
			scratch.evswap = ee;
			markup(revr,"evswap",&scratch,mlist,mm);
		}
	}
	
	if(!anc){
		ee = swapable(revu);
		if(ee != revu->evswap){
			etot += ee - revu->evswap;
			scratch.evswap = ee;
			markup(revu,"evswap",&scratch,mlist,mm);
		}
	}
	
	pars->evswap_indic += etot;
	
	if(pars->evswap_indic == 0 && pars->evswap_indic2 > 0)pars->pspace -= ESWAP_PROB;
	if(pars->evswap_indic > 0 && pars->evswap_indic2 == 0)pars->pspace += LSWAP_PROB;
	


	
	pars->lik = lik_cal(pevbot,pevtop,pars);
	
	if(anc){
		pars->tpr = log(MUTNODE_ADD_P/(dtl*dtr)
				/pars->pspace*0.5*clist[ic].nwt/pars->nwt_tot);
	}
	else{
		pars->tpr = log(MUTNODE_ADD_P/(dtu*dtl*dtr)
				/pars->pspace*0.5*clist[ic].nwt/pars->nwt_tot);
	}


	return;
	

}


		
Node *insertmut(Node **list,int *nn,double mt1,Node *pt,int mutval,
	Node **mlist,int *mm,int lno)
{

/* start with pt as the node immediately underneath pn1. In this case pt->time is 
	immediately before pn1->time along lineage, so we need to change pt->a, but 
	pt->time may still be immediately prior to pt->tlf->time.
	
	Need to change:
	pt->a
	pt->a->dl or dr (this is because pt->a may be a coalescent node)
	pt->tlf (possibly) or pt->tlf->...
	pt->tlf->tlr or pt->tlf->...->tlr   */		
	
	Node *pn1,*oldtlf;
	
	pn1 = mutate(list,nn,pt,mt1,mutval,lno); /* makes new node, adds to end
									of list, adds one to nn */
	pn1->mark = -2;/* -2 -> new node: -1 -> accepted node: >=0 -> marked node */
	mlist[(*mm)++] = pn1;
	pn1->a = pt->a;
	markup(pt,"a",pn1,mlist,mm); 
	if(pn1->a->type == 2){
		if(pn1->a->dl == pt){
			markup(pn1->a,"dl",pn1,mlist,mm);
		}
		else if(pn1->a->dr == pt){
			markup(pn1->a,"dr",pn1,mlist,mm);
		}
		else printerr("insertmut: error 1");
	}
	else if(pn1->a->type == 1){
		markup(pn1->a,"dl",pn1,mlist,mm);
	}
	else printerr("insertmut: error 2");	
	
	if(pt->type == 0)pt = list[0]; /* sample nodes have no tlf or tlr - except
	                                   list[0] */
	while(pt->tlf->time <= mt1)pt = pt->tlf;
	oldtlf = pt->tlf;
	markup(pt,"tlf",pn1,mlist,mm);

	markup(oldtlf,"tlr",pn1,mlist,mm);

	pn1 -> tlr = pt;
	pn1->tlf = oldtlf;
	pn1->nlin = pn1->tlf->nlin;
	
	/* trying to trap problems with times here - may lead to other problems
	because times not consistent with other mutations inserted */
/*	if(pn1->time <= pn1->tlr->time)pn1->time = pn1->tlr->time + DBL_EPSILON;
	if(pn1->time >= pn1->tlf->time)pn1->time = pn1->tlf->time - DBL_EPSILON; */
	if(pn1->time <= pn1->tlr->time || pn1->time >= pn1->tlf->time){
			printerr2("insertmut: rounding error with times",0);
			Illegal = 1;
	}
	return pn1;
	
		
}

void deletemut(Node *pp,Node **list,int *nn,Node **mlist,int *mm)
{
	int ic1;
	
	Node *ancestor,*nextevent,*descendent,*lastevent;
	ancestor = pp->a;
	if(ancestor == NULL)printerr("deletemut: error 1");
	nextevent = pp->tlf;
	if(nextevent == NULL)printerr("deletemut: error 2");
	descendent = pp->dl;
	if(descendent == NULL)printerr("deletemut: error 3");
	lastevent = pp->tlr;
	if(lastevent == NULL)printerr("deletemut: error 4");

	if(ancestor->type == 2){
		if(ancestor->dl == pp){
			markup(ancestor,"dl",descendent,mlist,mm);
		}
		else if(ancestor->dr == pp){
			markup(ancestor,"dr",descendent,mlist,mm);
		}
		else printerr("deletemut: error 5");
	}
	else if(ancestor->type == 1){
		if(ancestor->dl == pp){
			markup(ancestor,"dl",descendent,mlist,mm);
		}
		else printerr("deletemut: error 6");
	}
	else printerr("deletemut: error 7");
	markup(nextevent,"tlr",lastevent,mlist,mm);
	markup(descendent,"a",ancestor,mlist,mm);
	markup(lastevent,"tlf",nextevent,mlist,mm);
	
	ic1 = pp->pos;		/* remove the entry from list */
	list[ic1] = list[*nn-1];
	list[ic1]->pos = ic1;
	list[*nn-1] = pp;
	list[*nn-1]->pos = *nn-1;
	if(pp->type != 1)printerr("deletemut: error 8");
	if(pp->dl->a == pp)printerr("deletemut: error 9");
	if(pp->tlr->tlf == pp)printerr("deletemut: error 10");
	--(*nn);
	
	return;

}


void cmarkup(Cnode *pt,char *str,Cnode *target,Cnode **cmlist,int *cmm)
{
	int ic,j;
	if(pt == NULL)printerr("cmarkup: pt is null");
	if(pt->mark[0] == -1 && pt->mark[1] == -1)cmlist[(*cmm)++] = pt; 
	/* -1 signifies previously accepted node */
	if(target == NULL)printerr("cmarkup: target is null");
	switch(str[0]){
		case 'u':
			ic = 1;
			if(!inside(ic,pt->mark[0])){
				pt->u2 = pt->u;
				pt->mark[0] = make_mark(pt->mark[0],ic);
			}
			pt->u = target->p;
			break;
		case 'l':                 /*l, linmut0, linmut1,lwt0,lwt1*/
			if(str[1] == '\0'){
				ic = 2;
				if(!inside(ic,pt->mark[0])){
					pt->l2 = pt->l;
					pt->mark[0] = make_mark(pt->mark[0],ic);
				}
				pt->l = target->p;
			}
			else if(str[3] == '0'){
				ic = 3;
				if(!inside(ic,pt->mark[0])){
					pt->lwt2[0] = pt->lwt[0];
					pt->mark[0] = make_mark(pt->mark[0],ic);
				}
				pt->lwt[0] = target->lwt[0];
			}
			else if(str[3] == '1'){
				ic = 4;
				if(!inside(ic,pt->mark[0])){
					pt->lwt2[1] = pt->lwt[1];
					pt->mark[0] = make_mark(pt->mark[0],ic);
				}
				pt->lwt[1] = target->lwt[1];
			}
			else if(str[6] == '0'){
				ic = 5;
				if(!inside(ic,pt->mark[0])){
					pt->linmut2[0] = pt->linmut[0];
					pt->mark[0] = make_mark(pt->mark[0],ic);
				}
				pt->linmut[0] = target->linmut[0];
			}
			else if(str[6] == '1'){
				ic = 6;
				if(!inside(ic,pt->mark[0])){
					pt->linmut2[1] = pt->linmut[1];
					pt->mark[0] = make_mark(pt->mark[0],ic);
				}
				pt->linmut[1] = target->linmut[1];
			}
			else printerr("cmarkup: l--- not here");
			break;
		case 'r':
			ic = 1;
			if(!inside(ic,pt->mark[1])){
				pt->r2 = pt->r;
				pt->mark[1] = make_mark(pt->mark[1],ic);
			}
			pt->r = target->p;
			break;
		case 't':                  /*tf, tr*/
			if(str[1] == 'f'){
				ic = 2;
				if(!inside(ic,pt->mark[1])){
					pt->tf2 = pt->tf;
					pt->mark[1] = make_mark(pt->mark[1],ic);
				}
				pt->tf = target->p;
			}
			else if(str[1] == 'r'){
				ic = 3;
				if(!inside(ic,pt->mark[1])){
					pt->tr2 = pt->tr;
					pt->mark[1] = make_mark(pt->mark[1],ic);
				}
				pt->tr = target->p;
			}
			else printerr("cmarkup: t--- not here");
			break;
		case 'm':                   /*mlin0, mlin1, mlin2*/
			switch(str[4]){
				case '0':
					ic = 4;
					if(!inside(ic,pt->mark[1])){
						for(j=0;j<3;++j)pt->mlin2[0][j] = pt->mlin[0][j];
						pt->mark[1] = make_mark(pt->mark[1],ic);
					}
					for(j=0;j<3;++j)pt->mlin[0][j] = target->mlin[0][j];
					break;
				case '1':
					ic = 5;
					if(!inside(ic,pt->mark[1])){
						for(j=0;j<3;++j)pt->mlin2[1][j] = pt->mlin[1][j];
						pt->mark[1] = make_mark(pt->mark[1],ic);
					}
					for(j=0;j<3;++j)pt->mlin[1][j] = target->mlin[1][j];
					break;
				case '2':
					ic = 6;
					if(!inside(ic,pt->mark[1])){
						for(j=0;j<3;++j)pt->mlin2[2][j] = pt->mlin[2][j];
						pt->mark[1] = make_mark(pt->mark[1],ic);
					}
					for(j=0;j<3;++j)pt->mlin[2][j] = target->mlin[2][j];
					break;
				default:
					printerr("cmarkup: m----- not here");
			}
			break;
		case 'n':                     /*nniswap, nodemut,nwt*/
			if(str[1] == 'o'){
				ic = 7;
				if(!inside(ic,pt->mark[1])){
					pt->nodemut2 = pt->nodemut;
					pt->mark[1] = make_mark(pt->mark[1],ic);
				}
				pt->nodemut = target->nodemut;
			}
			else if(str[1] == 'w'){
				ic = 8;
				if(!inside(ic,pt->mark[1])){
					pt->nwt2 = pt->nwt;
					pt->mark[1] = make_mark(pt->mark[1],ic);
				}
				pt->nwt = target->nwt;
			}
			else printerr("cmarkup: n------ not here");
			break;
		default :
			printerr("cmarkup: not here");
	}
}




void markup(Node *pt,char *str,Node *target,Node **mlist,int *mm)
{
	int ic;
	if(pt->mark == -1)mlist[(*mm)++] = pt; 
	/* -1 signifies previously accepted node */
	switch(str[0]){
		case 'a':
			ic = 1;  
			if(!inside(ic,pt->mark)){
				pt->a2 = pt->a;
				pt->mark = make_mark(pt->mark,ic);
			}
			pt->a = target;
			break;
		case 'd':
			if(str[1] == 'l'){
				ic = 2;
				if(!inside(ic,pt->mark)){
					pt->dl2 = pt->dl;
					pt->mark = make_mark(pt->mark,ic);
				}
				pt->dl = target;
			}
			else if(str[1] == 'r'){
				ic = 3;
				if(!inside(ic,pt->mark)){
					pt->dr2 = pt->dr;
					pt->mark = make_mark(pt->mark,ic);
				}
				pt->dr = target;
			}
			else printerr("markup: d--- not here");
			break;
		case 't':
			switch(str[2]){
				case 'f':
					ic = 4;
					if(!inside(ic,pt->mark)){
						pt->tlf2 = pt->tlf;
						pt->mark = make_mark(pt->mark,ic);
					}
					pt->tlf = target;
					break;
				case 'r':
					ic = 5;
					if(!inside(ic,pt->mark)){
						pt->tlr2 = pt->tlr;
						pt->mark = make_mark(pt->mark,ic);
					}
					pt->tlr = target;
					break;
				case 'm':
					ic = 6;
					if(!inside(ic,pt->mark)){
						pt->time2 = pt->time;
						pt->mark = make_mark(pt->mark,ic);
					}
					pt->time = target->time;
					break;
				default:
					printerr("markup: t--- not here");
			}
			break;
		case 'v':
			ic = 7;
			if(!inside(ic,pt->mark)){
				pt->val2 = pt->val;
				pt->mark = make_mark(pt->mark,ic);
			}
			pt->val = target->val;
			break;
		case 'n':
			ic = 8;						/* 8+1=9 -> value of MCONS */
			if(!inside(ic,pt->mark)){
				pt->nlin2 = pt->nlin;
				pt->mark = make_mark(pt->mark,ic);
			}
			pt->nlin = target->nlin;
			break;
		case 'l':
			if(str[1] == 'n'){
				ic = 9;
				if(!inside(ic,pt->mark)){
					pt->lno2 = pt->lno;
					pt->mark = make_mark(pt->mark,ic);
				}
				pt->lno = target->lno;
			}
			else if(str[1] == 'i'){
				ic = 10;
				if(!inside(ic,pt->mark)){
					pt->linswap2 = pt->linswap;
					pt->mark = make_mark(pt->mark,ic);
				}
				pt->linswap = target->linswap;
			}
			else printerr("markup: l---- not here");
			break;
		case 'e':                    /*evswap*/
			ic = 11;
			if(!inside(ic,pt->mark)){
				pt->evswap2 = pt->evswap;
				pt->mark = make_mark(pt->mark,ic);
			}
			pt->evswap = target->evswap;
			break;
		default:
			printerr("markup: not here");
	}
	
}

int make_mark(int mark,int val)
{
	int newmark;
	
	if(mark == -1)return val;
	else if(mark == -2)return -2;
	else if(mark > 0){
		newmark = mark * MCONS + val;
		return newmark;
	}
	else printerr("make_mark: error in mark");
	return 1;
}

int inside(int ic,int mark)
{
	int irem;
	if(ic == 0 || mark == 0)printerr("inside: ic == 0 or mark == 0");
	if(mark == -1)return 0;
	if(mark == -2)return 1;
	do{
		irem = mark % MCONS;
		mark /= MCONS;
		if(irem == ic)return 1;
		if(irem == 0)printerr("inside: irem == 0");
	}while(mark > 0);
	return 0;
}
		

void restore(Node *pp)
{
	int mark,ic;
	
	mark = pp->mark;
	if(mark == 0 || mark == -1)printerr("restore: mark == 0 or -1");
	if(mark == -2)return;
	
	while(pp->mark != -1){
		ic = decomp(&(pp->mark));
		resit(pp,ic);
		
	}
}

void crestore(Cnode *pp)
{
	int mark0,mark1,ic;
	
	mark0 = pp->mark[0];
	mark1 = pp->mark[1];
	if(mark0 == 0 || mark1 == 0)printerr("crestore: mark == 0");
	if(mark0 == -1 && mark1 == -1)printerr("restore: mark == -1");
	if(mark0 > 0){
		while(pp->mark[0] != -1){
			ic = decomp(&(pp->mark[0]));
			cresit(pp,ic,0);
		}
	}
	
	if(mark1 >0){
	
		while(pp->mark[1] != -1){
			ic = decomp(&(pp->mark[1]));
			cresit(pp,ic,1);
			
		}
	}
}

int decomp(int *mark)
{
	int irem;

	if(*mark <= 0)printerr("decomp: mark wrong");
	irem = (*mark) % MCONS;
	(*mark) /= MCONS;
	if(*mark == 0)*mark = -1;
	return irem;
}	

void resit(Node *pp,int ic)
{

	switch(ic){
		case 1:
			pp->a = pp->a2;break;
		case 2:
			pp->dl = pp->dl2;break;
		case 3:
			pp->dr = pp->dr2;break;
		case 4:
			pp->tlf = pp->tlf2;break;
		case 5:
			pp->tlr = pp->tlr2;break;
		case 6:
			pp->time = pp->time2;break;
		case 7:
			pp->val = pp->val2;break;
		case 8:
			pp->nlin = pp->nlin2;break;
		case 9:
			pp->lno = pp->lno2;break;
		case 10:
			pp->linswap = pp->linswap2;break;
		case 11: 
			pp->evswap = pp->evswap2;break;
		default:
			printerr("resit: ic wrong");
	}
}

void cresit(Cnode *pp,int ic,int ip)
{
	int j;
	
	if(ip == 0){
		switch(ic){
			case 1:
				pp->u = pp->u2;break;
			case 2:
				pp->l = pp->l2;break;
			case 3:
				pp->lwt[0] = pp->lwt2[0];break;
			case 4:
				pp->lwt[1] = pp->lwt2[1];break;
			case 5:
				pp->linmut[0] = pp->linmut2[0];break;
			case 6:
				pp->linmut[1] = pp->linmut2[1];break;
			default:
				printerr("cresit: ic wrong, ip = 0");
		}
		return;
	}
	else if(ip == 1){
		switch(ic){
			case 1:
				pp->r = pp->r2;break;
			case 2:
				pp->tf = pp->tf2;break;
			case 3:
				pp->tr = pp->tr2;break;
			case 4:
				for(j=0;j<3;++j)pp->mlin[0][j] = pp->mlin2[0][j];break;
			case 5:
				for(j=0;j<3;++j)pp->mlin[1][j] = pp->mlin2[1][j];break;
			case 6:
				for(j=0;j<3;++j)pp->mlin[2][j] = pp->mlin2[2][j];break;
			case 7:
				pp->nodemut = pp->nodemut2;break;
			case 8: 
				pp->nwt = pp->nwt2;break;
			default:
				printerr("cresit: ic wrong, ip = 1");
		}
	}
	else printerr("cresit: ip wrong");
}

Node *cfind_down(Node *pt,int indic)
{
	if(pt->cp == NULL)printerr("cfind_down: input not cnode");
	if(indic == 0)return pt->cp->l;
	else return pt->cp->r;
}

Node *cfind_up(Node *pt,int *rl)
{
	Node *oldpt;
	if(pt->cp == NULL)printerr("cfind_up: input not cnode");
	oldpt = pt;
	pt = pt->cp->u;
	if(pt == NULL){
		*rl = -1;
		return NULL;
	}
	if(pt->cp->l == oldpt)*rl = 0;
	else if(pt->cp->r == oldpt)*rl = 1;
	else printerr("cfind_up: error in pointers");
	return pt;
}

	
Node *getmnode(Node *pp,char *ss,int val)
{

	int j;
	
	switch(ss[0]){
		case 'u':
			for(j=1;j<=val;++j){
				pp = pp->a;
				if(pp->type != 1)printerr("getmnode: val wrong, 1");
			}
			return pp;
		case 'l':
			for(j=1;j<= val;++j){
				pp = pp->dl;
				if(pp->type != 1)printerr("getmnode: val wrong, 2");
			}
			return pp;
		case 'r':
			pp = pp->dr; /* need to start down right lineage */
			if(pp->type != 1)printerr("getmnode: val wrong, 3");
			if(val == 1) return pp;
			for(j=1;j<val;++j){  /* slight displacement to account for prev. lines */
				pp = pp->dl;
				if(pp->type != 1)printerr("getmnode: val wrong, 2");
			}
			return pp;
		default:
			printerr("getmnode: fallen through ifs");
			return NULL;
	}
}


double log_normdev(double x,double mu,double s)
{
	return -pow(x-mu,2.0)/(2*(s*s)) - log(s);
}

double normdev(double x,double mu,double s)
{
	return 1.0/(s*sqrt(2.0*PI))*exp(-pow(x-mu,2.0)/(2*s*s));
}

double lndev(double x,double mu,double s)
{
	return 1.0/(x*s*sqrt(2.0*PI))*exp(-pow(log(x/mu),2.0)/(2*s*s));
}
	


int linswap_cal(Node *p1)
{
	if(p1 == NULL)printerr("linswap_cal: p1 is NULL");
	if(p1->tlf == NULL)return 0;
	if(p1->a == NULL)printerr("linswap_cal: p1->a == NULL");
	/* this is here because p1->tlf != NULL is not compatible with 
	p1->a == NULL */
	if(p1->val != p1->tlf->val)return 0;
	if(p1->type == 0)return 0;
	if(p1->tlf == p1->a)return 0;
	return 1;
}

#ifdef __MWERKS__
void MyEventLoop(long *sleepytime)
{
	EventRecord event;
	Boolean gotEvent, SIOUXDidEvent;
	float speedno;
	char c,whichkey;
	if (WaitNextEvent(everyEvent, &event,*sleepytime, NULL)){
		SIOUXDidEvent = SIOUXHandleOneEvent(&event);
/*		printf("event.what is %d      event.modifiers is %d\n",event.what,
				event.modifiers); */
		if(event.what == 3 && event.modifiers == 384){
			whichkey = (char)event.message & CHAR_CODE_MASK;
		/*	printf("%c\n",whichkey); */
			if(whichkey == 'u'){
				printf("pausing...Hit return to continue\n");
				getchar();
				printf("continuing...\n");
			}
			if(whichkey == 'l'){
				printf("enter new speed - number between 0,1  ");
				scanf("%f",&speedno);
				printf("continuing...\n");
				MTspeed = MinMTspeed*pow(MaxMTspeed/MinMTspeed,speedno);
				
			}
				
		}
	}
}
#endif

