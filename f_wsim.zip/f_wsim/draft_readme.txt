

Quick guide to f_wsim
---------------------

This program simulates co-dominant or dominant data under
selection in a structured population. The basic idea is described
in Beaumont and Balding (2004).

This program simulates  gene frequency data from a Wright-Fisher model with
migration. The model allows for an arbitrary number d of
constant-size demes.  Demes have a size,
N chromosomes, which can vary among demes. To allow for
the possibility of adaptive selection, for a particular locus the
demes can be considered to have attributes: neutral, red, or
blue. These are assigned at random, independently for each
selected locus, so that the number of populations in which selection
applies at a locus under selection is random. As described in more
detail below, in neutral demes all alleles have the same fitness,
whereas in the others it is possible for alleles to be
blue-adapted or red-adapted. The random allocation of labels
implies that each deme has different attributes to which a locus can
adapt --- for example, hot versus cold, and wet versus
dry, and crabs present versus crabs absent. In effect,
each locus is specialised to be able to adapt to a particular
attribute independently of other loci. This lack of correlation is
unlikely to be true in general (i.e. there will be a number of loci
that affect, for example, adaptation to heat), but is biologically
more plausible than the alternative in which a deme has the same
attribute for all loci.

The immigration rate into a deme is chosen at random by drawing
individual $F$s from a beta distribution, and then substituting
$m=(1-F)/(2NF)$. In each generation, a binomially-distributed number
of chromosomes in each deme is replaced by immigrants chosen at random
from all other demes. Each immigrant chromosome replaces a randomly
chosen resident chromosome.

Two mutation models are employed. In one case (two-locus) there is a
`marker' locus completely linked with a `selected' locus.  The
marker locus evolves according to an infinite allele model.  The
selected locus evolves according to a parent-independent K-allele
model with up to three alleles: blue, red, and neutral.  In
the other case (marker-selected), the marker locus is itself
susceptible to selection and evolves according to an infinite allele
model, but each mutation, as well as being distinct, has a selective
effect that is either blue, red, or neutral.  In both models
the selective effect of each realised allele is drawn with
probabilities P_{neut}, P_{red}$, $P_{blue}$, that sum to 1. 
We will use 'gene' or `locus' to refer to
one realisation from either the two-locus or the marker-selected
models. A multilocus data set is made up from independent realisations
and are either all two-locus, or all marker-selected.

In the marker-selected case, the initial parametric frequencies are
simulated from a Dirichlet distribution with K_{max}
alleles, and all parameters equal to Theta_M/K_{max}. This distribution 
is expected under a K-allele model, where
each mutation has probability 1/K_{max} of being to a
particular allele independent of its current type, and where
Theta_M is the scaled mutation rate. From this distribution a
sample of size Nd is drawn, and allocated among the d demes.  The
realised number of alleles, K, is generally much lower than
K_{max} so that it is well approximated by the infinite
allele model. Mutations subsequently occur at a rate mu_M.

Initialisation in the two-locus case is based on an urn-scheme
simulation of the coalescent (Donnelly and Tavare, 1995) in which the
mutations are laid down for each locus, with rates Theta_M for the
marker locus and Theta_S for the selected locus, using the mutation
models described above. The sample is allocated among demes as for the
marker-selected case. Mutations subsequently occur at frequency
mu_M for the marker locus and mu_S for the selected locus. The
frequencies may or may not be consistent with values chosen for
Theta_M and heta_S.

The genes are unlinked, and each may be either neutral,
directional-selected, or balancing-selected.  (We use
`directional-selected' as a synonym for adaptively-selected.) For
neutral genes P_{neut} = 1.  For directional-selected
genes we assume a diploid selection model in which relative fitness in
a blue deme is 1+s for blue homozygotes, and 1+s/2 for blue
heterozygotes, and 1 for all other genotypes. The same selective
effects pertain for red alleles in red demes. For balancing-selected
genes, in either red or blue demes, blue-red heterozygotes have
fitness 1+s, all other heterozygotes and all homozygotes have
fitness 1. In the current model the selection coefficients can be
different for balancing-selected and neutral-selected genes, but
within a run are the same for all genes in the same class. In neutral
demes all genotypes have fitness 1. The mean fitness is calculated
from these selection coefficients assuming Hardy-Weinberg equilibrium.
The proportions of each allele in the gamete pool are then calculated.

Chromosomes in the current generation are subject to mutation, then
some are replaced with immigrants, and then the next generation is
sampled according to the selection coefficients specified above.
Thus, selection occurs *after* mutation and immigration. In the
analyses described here, we used T=50000 generations, which is not
intended to lead to any equilibrium, but is chosen to be sufficiently
long that the allele frequencies reflect the selection coefficients.
Biologically, the simulations correspond to a situation in which a
species with no loci under selection colonises new habitats T
generations ago, and selection (both directional and balancing) occurs
under this changed regime.  Certainly for the neutral loci, the chosen
value of T is large enough that it would be reasonable to assume
that the MRCA for most loci would be contained within this simulation
period.

After T generations, chromosomes are sampled, with replacement, in
some or all of the demes.  A simulated data set may then be discarded
if an allele has global frequency greater than a given threshold, or
if non-neutral genes have no non-neutral alleles (this is only
relevant if mutations can give rise to neutral alleles).  If SNP-like
data are desired then datasets with more than two alleles can also be
discarded.
--------------------------------------------------------------------


NBB The binary was compiled using cygwin, and you need the dll in the same
folder (or other special places) for it to run. You may well get faster
performance (and not need this dll) with binaries compled using e.g. 
intel or Borland compilers.


Input files
-----------

** INTFILE - random number generator seed. Gets updated in
program. So can be used for later runs. More difficult if you want
parallel runs. Need to offset it by additional simulations in this
case.

** f_wsim_params.txt - this contains the parameters for the run.
This is mostly self-explanatory, (see description above).
Consult Beaumont and Balding (2004) for extra information.

Points to note:
 1) if "Is the composition of population types fixed (just
 permuted)" is set to 1 the following 2 parameters are relevant,
 otherwise the 2 after that are relevant.

 2) scale of F refers to the beta parameter. F is allowed to vary
 among subpopulations. If 0 then F is
 identical among subpopulations. Consult Beaumont and Balding
 (2004) for more info.

 3) If F is allowed to vary, we can either vary immigration rate
 or population size. This is altered by the "Keep immigration rate
 constant?" switch. Otherwise the immigration rate varies an pop
 size stays constant.
 
 4) An important thing to realise is that F, here, is considered 
 a parameter - the probability that two lineages coalesce before 
 migration (looking back in time). In this scenario F is just another
 way of giving the migration rates, via F = 1/(1+2NM). This will *only*
 coincide with Fst as estimated by e.g. Weir and Cockerham a) when 
 mutation rate is low; b) the number of subpoplations are large. 
 Generally we are considering a low mutation rate so, to get the 
 simulations to produce data from which the W&C estimator will estimate
 closely the desired Fst, you need to input an F that will give rise to 
 an NM (vi F = 1/(1+2NM)) that will give rise to an expected Fst of
 1/(1+d/(d-1)*(1/F-1)), where d is the number of demes. E.g. for low F, 
 and for 2 demes the simulations will produce data where W&C estimate 
 will generally be around half the F used to run the simulations. 
 
 5) Extending from this, if you simulate the data where you think F is 
 going to be X and you then run Ddatacal, or datacal over it (from
 the fdist distributions) and find that it is is different, there are
 two reasons for this: a) the effect in 4) above; b) if you allow F to
 vary among populations random values might be drawn whose average is 
 different from the expected F you put. In the 'other_info.txt' file
 the 'corrected' Fs for the number of demes are given. So you should
 expect datacal to recover (roughly) the average of these when
 it estimates W&Cs Fst. 

 6) "Mutation rate of selected alleles" is only relevant if
 "Marker is selected" is set to 0.

 7) The program runs independent realisations and *only* prints out data
 when the conditions given in the last line of the file are true.
 So this means (for e.g. SNPs that many simulations do not give an
 output).

 8) "report selected loci with selected alleles only" means only
 print out simulations where the loci designated as "under
 selection" actually have non-neutral alleles present in the
 sample.

Output files
------------

** other_info.txt - this just gives details of Fs, predicted 'W&C' Fs,
pop sizes (if allowed to vary), and the numbers of realisations that were
rejected according to the different criteria at the bottom of the
parameter file.

** selfile - this just has two columns. The first is the locus
number starting from 0, the second is an indicator: 1 -
directional selected, 2 - balancing; 3 - neutral. The loci are
always output in that order.

** select_summary.txt - this has as many lines as loci requested.
The order of the lines are as in the output files ("selfile",
"simulated_infile_marker.txt", "simulated_infile_selec.txt"). If
the loci are directional selected it gives "red" or "blue"
according to how the population was designated. If the frequency
of e.g. blue alleles is greater than 50% in the blue populations,
it is output in upper case, otherwise lower case. In the case of
balancing selected loci, alleles that are at freqs between 0.25
and 0.75 are output upper case (X) and lower case (x) otherwise.

** simulated_infile_marker.txt - this is a simulated infile that
can be used directly in fdist. In the case of dominant data, there
first frequency is for the null (i.e. recessive homozygote).

** simulated_infile_selec.txt - this is a more complicated version
of infile not suitable for input into any program, but which gives
more explicit information on both the marker and selected allele.
