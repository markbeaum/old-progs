#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "myutil.h"

#define MAXPOP 100
#define MAXALL 100
#define MAXLOC 10000


struct type_val{
    int m;
    int s;
};
void subsample_dom();
struct type_val freq_choose(int ig,int n,int freq[], struct type_val val[]);
void permute(int vec[],int len);
double betasim(double a[]);
int no_sel_alleles(void);
char select_mark(int freq[], struct type_val val[],int len,int poptype);
void read_params(void);
void mutate(void);
void mutate_selec(struct type_val *old_val, struct type_val *new_val);
void mutate_marker(struct type_val *old_val, struct type_val *new_val);
int choose_pop(int ic);
double fitcalc(int pop_id, struct type_val val_a, struct type_val val_b);
void setval(struct type_val *v1,struct type_val *v2);
int get_allclass(int vec[],int ic,int n);
int lookup(struct type_val *v1,struct type_val val[],int len);
void migrate(void);
void sample(void);
void mfitcalc(void);
void dirifill(int n,int freq[],struct type_val val[],int *len);
void urnfill(int n,int freq[],struct type_val val[],int *len);
void initialise(void);
void getsample(void);
void subsample(void);


/* main variables */
int Idom; /* indicator, whether to generate dominant markers */
int F_value; /* value of Fis */
int Freq[MAXPOP][MAXALL], /* absolute allele frequency in each deme */
	Nal[MAXPOP]; /* number of alleles in each subpopulation */
struct type_val Val[MAXPOP][MAXALL]; /* mutational type of each allelic category in each deme */
int Nextmutval; /* counter for IAM */
double Mfit[MAXPOP]; /* mean fitness */
int Ltype_current;

/* main parameters - to be read in */
int Ltype[MAXLOC]; /* type of each locus - neutral or not */
int Popsize[MAXPOP]; /* size of each deme */
int Poptype[MAXPOP]; /* selective environment - currently neutral, red, blue */
int Tpopsize; /* total population size */
int Ngen, /* number of generations to run */
	Npop, /* number of populations (total) */
	Nloci, /* number of loci */
	K_diri; /* notional number of alleles to mimic IAM */
double Theta_M, Theta_S,/* scaled mutation rates for IAM initialization */
	P_neut, /* probability that a mutation is neutral */
	P_red, /* probability that a mutation is red-adapted */
	P_blue; /* probability that a mutation is blue-adapted */
double Mig_rate[MAXPOP], /* migration rate */
F,F_scale, /* mean and s.d. (approx) of F */
Mu_marker, Mu_selec, /* mutation rate for marker and selected genes */
Sel_coeff_p,Sel_coeff_b; /* selection coefficient - fitness is 1+s */
       /* for subsampling */

/* main variables */
int SubsFreq[MAXPOP][MAXALL]; /* absolute allele frequency from sampled demes */
struct type_val SubsVal[MAXALL]; /* the global (across demes) table of allelic values */
int SNal; /* number of alleles across all sampled demes */

int M_SubsFreq[MAXPOP][MAXALL]; /* absolute allele frequency of MARKER from sampled demes */
struct type_val M_SubsVal[MAXALL]; /* the global (across demes) table of MARKER values */
int M_SNal; /* number of MARKER alleles across all sampled demes */

/* main parameters - to be read in */
int SubsLookup[MAXPOP], /* list of demes to be sampled */
	NSubs, /* number of demes to be sampled */
	Sampsize[MAXPOP]; /* sample size of each sampled deme */
 int Report_poly_only,Report_snp_only,Report_sel_only;

 int Checkit = 0;
 int Maxf,Tot_Sampsize;
 double Fthresh;
 int Marker_is_selected=1;

 int Konst_m;
 double Mformig;

 int Fixed_poptype;
 double P_neut_pop,P_red_pop,P_blue_pop;
 int Loc_indic;

int main(void)
{
    int j,nloci,i,k,mono,pp,nosel,more_than_two,lowvary;
    long insert1,insert2;
	double rr;
    FILE *out1,*out2,*out3,*out4,*selfile;

    out1 = fopen("simulated_infile_marker.txt","w+");
    out2 = fopen("simulated_infile_selec.txt","w+");
    out3 = fopen("select_summary.txt","w");
    out4 = fopen("other_info.txt","w");
    selfile = fopen("selfile","w");
    opengfsr();

    read_params();

    fprintf(out4,"individual Fs:\n\n");
    for(j=0;j<NSubs;++j){
		i = SubsLookup[j];
		fprintf(out4,"%f ",
                1.0/(1.0 + 2.0*Mig_rate[i]*Popsize[i]));
	}
    fprintf(out4,"\n\n");
    fprintf(out4,"So with %d demes, you expect W&C theta to be around: \n",Npop);
    for(j=0;j<NSubs;++j){
		i = SubsLookup[j];
		fprintf(out4,"%f ",
                1.0/(1.0 + (Npop/(Npop-1.0))*2.0*Mig_rate[i]*Popsize[i]));
	}
    fprintf(out4,"\n\n");


    fprintf(out4,"individual pop sizes:\n\n");
    for(j=0;j<NSubs;++j){
		i = SubsLookup[j];
		fprintf(out4,"%d ",
                Popsize[i]);
	}
    fprintf(out4,"\n\n");
    fflush(out4);

    /* sets Npop, loci */
    for(j=0;j<Npop;++j)Tpopsize += Popsize[j];
    fprintf(out1,"%d\n%-5d\n",0,NSubs);
    insert1 = ftell(out1);    /* only needed if Report_poly_only */
    fprintf(out1,"%-5d\n\n",Nloci);
    fprintf(out2,"%d\n%-5d\n",0,NSubs);
    insert2 = ftell(out2);   /* only needed if Report_poly_only */
    fprintf(out2,"%-5d\n\n",Nloci);
    mono = 0;
    nosel = 0;
    more_than_two = 0;
    lowvary = 0;
    for(j=0;j<Nloci;++j){
		Loc_indic = j;
        if(Fixed_poptype)permute(Poptype,Npop);
		else{
			for(i=0;i<Npop;++i){
				rr = gfsr4();
				if(rr < P_neut_pop)Poptype[i] = 0;
				else if(rr < P_neut_pop+P_red_pop)Poptype[i] = 1;
				else Poptype[i] = 2;
			}
		}
		Ltype_current = Ltype[j];
        getsample();
        if(M_SNal == 1){
            ++mono;
            if(Report_poly_only){
                --j;
                continue;
            }
        }
        if(Maxf > Fthresh*Tot_Sampsize){
            ++lowvary;
            --j;
            continue;
        }
        if(M_SNal > 2){
            ++more_than_two;
            if(Report_snp_only){
                --j;
                continue;
            }
        }
        if(Ltype_current==1 || Ltype_current == 2){
            if(no_sel_alleles()){
                ++nosel;
                if(Report_sel_only){
                    --j;
                    continue;
                }
            }
        }
         fprintf(selfile,"%d %d\n",j,Ltype_current);

        /* this printing out system is only suitable when marker and selected
        mutations are the same in an IAM - probably we need to have separate variables
        for frequencies of neutral and selected markers to be completely general*/
        fprintf(out1,"%d\n",M_SNal);
        fprintf(out2,"%d (%d)\n",SNal,Ltype[j]);
        fprintf(out2,"   ");
        for(i=0;i<SNal;++i)fprintf(out2,"(%5d  %5d)   ",SubsVal[i].m,SubsVal[i].s);
        fprintf(out2,"\n");
        fprintf(out3,"%d ",Ltype_current);
        if(!Report_poly_only){
            if(M_SNal == 1)fprintf(out3,"M ");  /* might want to print SNal ?*/
            else fprintf(out3,"- ");
        }
        for(i=0;i<NSubs;++i){
            pp = Poptype[SubsLookup[i]];
            if(pp == 0 || Ltype[j]==0)fprintf(out3,"O");
            else fprintf(out3,"%c",select_mark(SubsFreq[i],SubsVal,SNal,pp));
			fprintf(out2,"%3d",Poptype[SubsLookup[i]]);
            for(k=0;k<M_SNal;++k)fprintf(out1,"%d ",M_SubsFreq[i][k]);
			for(k=0;k<SNal;++k){
				fprintf(out2,"     %5d       ",SubsFreq[i][k]);
			}
			fprintf(out1,"\n");
			fprintf(out2,"\n");
		}
        fprintf(out1,"\n");
        fprintf(out2,"\n");
        fprintf(out3,"\n");
        fflush(out1);
        fflush(out2);
        fflush(out3);
        if(j==0)printf("done one locus\r");
        else printf("done %d loci        \r",j+1);
    } // end of simulation loop over loci
//    if(Report_poly_only){     /* this may be fragile! */
//        fseek(out1,insert1,SEEK_SET);
//        fprintf(out1,"%-5d",Nloci-mono-nosel);
//        fseek(out2,insert2,SEEK_SET);
//        fprintf(out2,"%-5d",Nloci-mono-nosel);
//    }
    fprintf(out4,"Number of monomorphic loci is %d\n",mono);
    fprintf(out4,"Number of selected loci without selected alleles is %d\n",nosel);
    fprintf(out4,"Number of loci with more than two alleles is %d\n",more_than_two);
    fprintf(out4,"Number of loci with most frequent allele > threshold is %d\n",lowvary);
    closegfsr();
}

int no_sel_alleles(void)
{
    int k;
    for(k=0;k<SNal;++k){
        if(SubsVal[k].s != 0)return 0;
    }
    return 1;

}

char select_mark(int freq[], struct type_val val[],int len,int poptype)
{
    int isum,isum2;
    int j;

    isum = 0;
    isum2 = 0;
    for(j=0;j<len;++j){
        if(val[j].s == poptype)isum += freq[j];
        isum2 += freq[j];
    }
    if(Ltype_current == 1){
        if((double)isum/(double)isum2 > 0.5){
            if(poptype == 1)return 'R';
            if(poptype == 2)return 'B';
            if(poptype == 0)return '?';
        }
        else{
            if(poptype == 1)return 'r';
            if(poptype == 2)return 'b';
            if(poptype == 0)return '?';
        }
    }
    else{
        if((double)isum/(double)isum2 < 0.25 ||
                (double)isum/(double)isum2 > 0.75){

            if(poptype == 1)return 'x';
            if(poptype == 2)return 'x';
            if(poptype == 0)return '?';
        }
        else{
            if(poptype == 1)return 'X';
            if(poptype == 2)return 'X';
            if(poptype == 0)return '?';
        }
    }

}

void read_params()
{
	int nlneut,nlbal,npop_red,npop_blue,i,j,ic;
    double bvec[2],ff;
	FILE *pfile;

	pfile = fopen("f_wsim_params.txt","r");

	fscanf(pfile,"%d %lf %d %d %d %d",&Idom,&F_value,&(Popsize[0]),&Ngen,&Npop,&Nloci);
	fscanf(pfile,"%d %d %d %d %d",&nlneut,&nlbal,&Fixed_poptype,&npop_red,&npop_blue);
	fscanf(pfile,"%lf %lf %lf",&P_neut_pop,&P_red_pop,&P_blue_pop);
	fscanf(pfile,"%d %lf %lf %lf %lf %lf",&K_diri,&Theta_M,&Theta_S,&P_neut,&P_red,&P_blue);
    fscanf(pfile,"%lf %lf %d %lf%lf %d %lf %lf %lf",&F,&F_scale,&Konst_m,&Mformig,&Mu_marker,&Marker_is_selected,
                                    &Mu_selec,&Sel_coeff_p,&Sel_coeff_b);
	Tpopsize = 0;
	if(!Konst_m){
		for(j=1;j<Npop;++j)Popsize[j] = Popsize[0];
		Tpopsize = Npop*Popsize[0];
	}

    if(F_scale != 0){
        bvec[0] = F/F_scale;
        bvec[1] = (1-F)/F_scale;
    }
    for(j=0;j<Npop;++j){
        if(F_scale == 0.0)ff = F;
        else ff = betasim(bvec);
        if(!Konst_m)Mig_rate[j] = (1-ff)/(2*Popsize[j]*ff);
		else{
			Mig_rate[j] = Mformig;
			Popsize[j] = (1-ff)/(2*Mformig*ff);
			Tpopsize += Popsize[j];
		}
    }

	for(j=0;j<Nloci-nlneut-nlbal;++j)Ltype[j] = 1; /*selected loci */
    for(;j<Nloci-nlneut;++j)Ltype[j] = 2; /* loci under balancing selection */
	for(;j<Nloci;++j)Ltype[j] = 0; /* neutral loci */
	for(j=0;j<npop_red;++j)Poptype[j] = 1; /* red */
	for(;j<npop_red+npop_blue;++j)Poptype[j] = 2; /* blue */
	for(;j<Npop;++j)Poptype[j] = 0; /*neutral*/

	fscanf(pfile,"%d %d",&NSubs,&(Sampsize[0]));
    if(NSubs == 0)printerr("number of samples is 0");

	for(j=1;j<NSubs;++j)Sampsize[j] = Sampsize[0];
    Tot_Sampsize = NSubs*Sampsize[0];

    j=0;
	while(1){
		ic = disrand(0,Npop-1);
		for(i=0;i<j;++i){
			if(SubsLookup[i] == ic)break;
		}
		if(i==j)SubsLookup[j++] = ic;
        if(j == NSubs)break;
	}
    fscanf(pfile,"%d",&Report_poly_only);
    fscanf(pfile,"%d",&Report_snp_only);
    fscanf(pfile,"%d",&Report_sel_only);
    fscanf(pfile,"%lf",&Fthresh);
    if(Idom){
		Report_poly_only = 1;
		Report_snp_only = 1;
	}
}

void permute(int vec[],int len)
{
    int j,ip,itemp;
    for(j=0;j<len;++j){
        ip = disrand(j,len-1);
        itemp = vec[j];
        vec[j] = vec[ip];
        vec[ip] = itemp;
    }
}

void getsample()
{
    int j;
    initialise();
    for(j=0;j<Ngen;++j){
        mfitcalc();
        sample();
        mutate();
        migrate();
    }
    if(Idom)subsample_dom();
    else subsample();
}





void subsample_dom()
{
	int j,ic,ss,i,k,freq[MAXPOP][MAXALL],vtable[MAXPOP][MAXALL],ip,basefreq[MAXALL];
	int tempfreq[MAXPOP][MAXALL],tempsnal,temp_first,temp_second,irec,is_f,ig;
	int first_type, second_type,hit0,hit1;
	double done;
	struct type_val tempval[MAXALL],g1,g2;

	SNal = 0;
	tempsnal = 0;


	for(j=0;j<NSubs;++j){
		ic = SubsLookup[j];
		for(i=0;i<Nal[ic];++i){
			freq[j][i] = Freq[ic][i];
			if(freq[j][i] > 0){
				ip = lookup(&Val[ic][i],tempval,tempsnal);
				if(ip == tempsnal){
					tempval[tempsnal] = Val[ic][i]; /* Assignment of structure! */
					++tempsnal;
				}
				vtable[j][i] = ip;
			}
		}
	}
	/* for computational efficiency have allowed each population to have its own
	   allele frequency table - but to print it out - we need to collate everything
	   together */
	for(j=0;j<NSubs;++j){
		ic = SubsLookup[j];
		for(i=0;i<tempsnal;++i){
			tempfreq[j][i] = 0;
		}
		for(i=0;i<Nal[ic];++i){
			if(freq[j][i] > 0){
				ip = vtable[j][i];
				tempfreq[j][ip] = freq[j][i];
			}
		}
	}


	temp_first = 0;
	temp_second = 0;


	irec = disrand(0,1);
	for(j=0;j<NSubs;++j){
		ic = j;
		ss = Sampsize[j]/2;
		M_SubsFreq[j][0] = M_SubsFreq[j][1] = 0;
		for(i=0;i<tempsnal;++i)SubsFreq[j][i] = 0;

		for(i=0;i<ss;++i){
			is_f = gfsr4() < F_value;
			ig = disrand(1,Popsize[ic]);
			g1 = freq_choose(ig,tempsnal,tempfreq[ic],tempval);
			if(is_f)g2 = g1;
			else{
				ig = disrand(1,Popsize[ic]);
				g2 = freq_choose(ig,tempsnal,tempfreq[ic],tempval);
			}

			if(temp_first > 0 && g1.m != first_type){
				if(temp_second > 0 && g1.m != second_type){
					M_SNal = 3;
					return;
				}
				else{
					if(temp_second == 0)second_type = g1.m;
					++temp_second;
				}
			}
			else{
				if(temp_first == 0)first_type = g1.m;
				++temp_first;
			}

			if(g2.m != first_type){
				if(temp_second > 0 && g2.m != second_type){
					M_SNal = 3;
					return;
				}
				else{
					if(temp_second == 0)second_type = g2.m;
					++temp_second;
				}
			}
			else{
				++temp_first;
			}

/*			if(Loc_indic == 17 && tempsnal > 1 && tempval[1].m == 261903){
				ip = 1;
			}*/
/* this is tricky because second_type may not be defined */
			if(irec){ /*first_type is recessive */
				if(g1.m == first_type && g2.m == first_type)++M_SubsFreq[j][0];
				else ++M_SubsFreq[j][1];
			}
			else{
				if(g1.m != first_type && g2.m != first_type)++M_SubsFreq[j][0];
				else ++M_SubsFreq[j][1];
			}

			ip = lookup(&g1,SubsVal,SNal);
			if(ip == SNal){
				SubsVal[SNal] = g1;
				++SNal;
				SubsFreq[j][ip] = 1;
			}
			else ++SubsFreq[j][ip];

			ip = lookup(&g2,SubsVal,SNal);
			if(ip == SNal){
				SubsVal[SNal] = g2;
				++SNal;
				SubsFreq[j][ip] = 1;
			}
			else ++SubsFreq[j][ip];

		} /* end of loop over samplesize */
/*		this check only works when we have neutrality
		if(irec){
			if(SubsVal[0].m == first_type){
				if(2*M_SubsFreq[j][0] > SubsFreq[j][0])printerr("sampdom error 1");
			}
			else if(SubsVal[1].m == first_type){
				if(2*M_SubsFreq[j][0] > SubsFreq[j][1])printerr("sampdom error 2");
			}
		}
		else{
			if(SubsVal[0].m == second_type){
				if(2*M_SubsFreq[j][0] > SubsFreq[j][0])printerr("sampdom error 3");
			}
			else if(SubsVal[1].m == second_type){
				if(2*M_SubsFreq[j][0] > SubsFreq[j][1])printerr("sampdom error 4");
			}
		}*/

	}/* end of loop over sampled subpopulations */

	if(temp_first == 0)printerr("subsample_dom: temp_first wrong");
	if(temp_second == 0)M_SNal = 1;
	else{
		for(j=0,hit0=0;j<NSubs;++j){
			if(M_SubsFreq[j][0] > 0)hit0 = 1;
			break;
		}
		for(j=0,hit1=0;j<NSubs;++j){
			if(M_SubsFreq[j][1] > 0)hit1 = 1;
			break;
		}
		if(hit0 && hit1)M_SNal = 2;
		else M_SNal = 1;
	}



    Maxf = 0;
    for(i=0;i<M_SNal;++i){
        basefreq[i] = 0;
        for(j=0;j<NSubs;++j){
            basefreq[i] += M_SubsFreq[j][i];
        }
        if(basefreq[i] > Maxf)Maxf = basefreq[i];
    }
    Maxf *= 2.0; /* just so we don't have to correct definition of Tot_Sampsize */
}


struct type_val freq_choose(int ig,int n,int freq[], struct type_val val[])
{
	int isum,j;
	isum = 0;
	for(j=0;j<n;++j){
		isum += freq[j];
		if(isum >= ig)return val[j];
	}
	printerr("freq_choose: fallen through loop");

}

void subsample()
{
	int j,ic,ss,i,k,freq[MAXPOP][MAXALL],vtable[MAXPOP][MAXALL],ip,basefreq[MAXALL];
	double done;
	SNal = 0;

	for(j=0;j<NSubs;++j){
		ic = SubsLookup[j];
		ss = Sampsize[j];
		done = 0.0;
		for(i=0;i<Nal[ic];++i){
            if(1.0-done == 0)printerr("subsample: error in denominator");
			freq[j][i] = bnldev((double)Freq[ic][i]/((double)Popsize[ic]*(1.0-done)),ss);
			done += Freq[ic][i]/((double)Popsize[ic]);
			ss = ss-freq[j][i];
			/* need to produce a vector of global allele types across populations */
			if(freq[j][i] > 0){
				ip = lookup(&Val[ic][i],SubsVal,SNal);
				if(ip == SNal){
					SubsVal[SNal] = Val[ic][i]; /* Assignment of structure! */
					++SNal;
				}
				vtable[j][i] = ip;
			}
		}
	}
	/* for computational efficiency have allowed each population to have its own
	   allele frequency table - but to print it out - we need to collate everything
	   together */
	for(j=0;j<NSubs;++j){
		ic = SubsLookup[j];
		for(i=0;i<SNal;++i){
			SubsFreq[j][i] = 0;
		}
		for(i=0;i<Nal[ic];++i){
			if(freq[j][i] > 0){
				ip = vtable[j][i];
				SubsFreq[j][ip] = freq[j][i];
			}
		}
	}

    /* in the case where the marker and selected loci are different
    we need to make an extra frequency and value table classified only
    by the marker alleles (which are assumed to be known) */
    M_SNal = 0; /* this is the number of distinct marker allelic types */
    for(k=0;k<NSubs;++k){
        for(j=0;j<SNal;++j){
            M_SubsFreq[k][j] = 0;
        }
    }
    for(i=0;i<SNal;++i){
        for(j=0;j<M_SNal;++j){
            if(SubsVal[i].m == M_SubsVal[j].m){
                for(k=0;k<NSubs;++k){
                    M_SubsFreq[k][j] += SubsFreq[k][i];
                }
                break;
            }
        }
        if(j == M_SNal){
            for(k=0;k<NSubs;++k){
                M_SubsFreq[k][j] += SubsFreq[k][i];
            }
            M_SubsVal[j].m = SubsVal[i].m;
            M_SubsVal[j].s = -1;
            ++M_SNal;

        }
    }
    if(Marker_is_selected){       /* just check things are OK */
        if(M_SNal != SNal)printerr("subsample: error 1");
        for(j=0;j<M_SNal;++j)if(M_SubsVal[j].m != SubsVal[j].m)
                                printerr("subsample: error 2");
        for(k=0;k<NSubs;++k){
            for(j=0;j<M_SNal;++j){
                if(M_SubsFreq[k][j] != SubsFreq[k][j])printerr("subsample: error 3");
            }
        }
    }


    Maxf = 0;
    for(i=0;i<M_SNal;++i){
        basefreq[i] = 0;
        for(j=0;j<NSubs;++j){
            basefreq[i] += M_SubsFreq[j][i];
        }
        if(basefreq[i] > Maxf)Maxf = basefreq[i];
    }
}


void initialise()
{
    int initfreq[MAXALL],sampled[MAXALL];
    struct type_val initval[MAXALL];
    int initnal,k,j,inurn,done,numberleft_k,il,nak;

/* Need to fill Freq,Val */

/* Current formulation assumes marker mutations are the same as selected
	mutations. Currently 3 classes of mutations - neutral, red, blue. */

/* Slight mental aberration here - could have just got
	dirifill to produce the base frequencies and then taken multinomial
	samples for each population. But present formulation is needed if I
	eventually use an urn scheme to generate intial frequences. This is
	needed if I want to make marker mutations independent of selected mutations */

    if(Marker_is_selected)dirifill(Tpopsize,initfreq,initval,&initnal);
    else urnfill(Tpopsize,initfreq,initval,&initnal);
    for(k=0;k<initnal;++k)sampled[k] = 0;
    inurn = Tpopsize;
    for(j=0;j<Npop;++j){
        done = 0;
        numberleft_k = 0;
        il = 0;
        for(k=0;k<initnal;++k){
            numberleft_k += initfreq[k]-sampled[k];
            nak = rhyper(numberleft_k,inurn - numberleft_k,Popsize[j]-done);
            if(nak > 0){
                Freq[j][il] = nak;
                setval(&(Val[j][il]),&(initval[k]));
                ++il;
            }
            done += nak;
            sampled[k] += nak;
        }
        inurn -= Popsize[j];
        Nal[j] = il;

    }
}

void urnfill(int n,int freq[],struct type_val val[],int *len)
{
	struct type_val *gvec;
	int num_genes;
	double rr,rr2,rr3,pmut;
	int ic,nlin,j,nal;

	num_genes = n;
	gvec = (struct type_val *)malloc(num_genes*sizeof(struct type_val));
	gvec[0].m = 0;
    if(Ltype_current == 0)rr = 0;
    else rr = gfsr4();
    if(rr <= P_neut)gvec[0].s = 0;
    else if(rr <= P_neut+P_red)gvec[0].s = 1;
    else gvec[0].s = 2;
	gvec[1] = gvec[0];
	nlin =2;
	while(1){
		rr = gfsr4();
		pmut = (Theta_M + Theta_S)/(Theta_M+Theta_S+nlin-1);
		ic = disrand(0,nlin-1);
		if(pmut > rr){
            rr2 = gfsr4()*(Theta_M+Theta_S);
            if(rr2 <= Theta_M ){
                gvec[ic].m = Nextmutval++;
            }
            else{
                if(Ltype_current == 0)rr3 = 0;
                else rr3 = gfsr4();
                if(rr3 <= P_neut)gvec[ic].s = 0;
                else if(rr3 <= P_neut+P_red)gvec[ic].s = 1;
                else gvec[ic].s = 2;
            }

		}
		else{
			if(nlin == num_genes)break;
			gvec[nlin] = gvec[ic];
			++nlin;
		}
	}
    nal = 0;
    for(j=0;j<num_genes;++j){
        ic = lookup(&(gvec[j]),val,nal);
        if(ic == nal){
            freq[ic] = 1;
            val[ic] = gvec[j];
            ++nal;
        }
        else ++freq[ic];
    }
    *len = nal;
    free(gvec);

}


void dirifill(int n,int freq[],struct type_val val[],int *len)
{
	double sum,done,rr,vec[1000];
	int j,ss,ktrue;
	if(K_diri >= 1000)printerr("dirifill: K_diri > 1000");

	sum = 0.0;
	for(j=0;j<K_diri;++j){
		vec[j] = rgamma(Theta_M/K_diri,1.0);
		sum += vec[j];
	}
	for(j=0;j<K_diri;++j)vec[j] /= sum;
	ss = n;
	done = 0.0;
	for(j=0;j<K_diri;++j){
        if(ss == 0){
            freq[j] = 0;
        }
        else{
            if(1.0 - done <= 0.0)printerr("dirifill: done is 1.0 ");
		    freq[j] = bnldev(vec[j]/(1.0-done),ss);
        }
		done += vec[j];
		ss = ss-freq[j];
	}
    if(ss != 0)printerr("dirifill: ss != 0");
	isort('d',K_diri,freq);
	for(j=0;j<K_diri;++j){
		if(freq[j] == 0)break;
	}
	ktrue = j;
	if(ktrue == 0)printerr("dirifill error 1");
	if(ktrue > K_diri)printerr("dirifill error 2");
	for(j=0;j<ktrue;++j){
		val[j].m = j;
		if(Ltype_current == 0)rr = 0; /* all alleles are neutral */
		else rr = gfsr4();
		if(rr <= P_neut)val[j].s = 0;
		else if (rr <= P_neut+P_red) val[j].s = 1;
		else val[j].s = 2;
	}
	Nextmutval = j;
	*len = ktrue;

}

void mfitcalc()
{
	int j,i,k;
    for(j=0;j<Npop;++j){
        Mfit[j] = 0.0;
        for(i=0;i<Nal[j];++i){
            for(k=0;k<Nal[j];++k){
                Mfit[j] += Freq[j][i]*Freq[j][k]*fitcalc(j,Val[j][i],Val[j][k]);
                                   /* don't bother to normalise */
            }
        }
    }
}

double fitcalc(int pop_id, struct type_val val_a, struct type_val val_b)
{
 	int ptype;

    ptype = Poptype[pop_id];
    if(ptype == 0) return 1.0;

    if(Ltype_current==0){
        return 1.0; /* neutral case */
    }
    else if(Ltype_current == 1){
	    if(val_a.s == val_b.s){
            if(ptype == val_a.s)return 1.0 + Sel_coeff_p;
	        else return 1.0;
            /* ptype won't = val_a.s if it is 0, because this case is
               dealt with above so this handles the neutral homozygote case */
        }
        else {
            if(val_a.s == ptype || val_b.s == ptype)return 0.5*(2.0 + Sel_coeff_p);
            else return 1.0;
        }
    }
    else{
        if(val_a.s == val_b.s)return 1.0;
        if(val_a.s == 0 || val_b.s == 0)return 1.0;
        return 1.0+Sel_coeff_b;
    }
}



void sample()
{
/* have Mfit as a double, but Freq is absolute freqs, and an integer */
	int j,i,k,rest,isum;
	double done,p,props[100];
    for(j=0;j<Npop;++j){
        if(Checkit){
            for(i=0;i<Nal[j];++i)
                if(Freq[j][i] <= 0)printerr("sample: Freq <= 0 (1)");
            for(i=0,isum=0;i<Nal[j];++i)isum += Freq[j][i];
            if(isum != Popsize[j]) printerr("sample: total freq != popsize");
        }
        done = 0.0;
        rest = Popsize[j];
        for(i=0;i<Nal[j];++i){
            for(k=0,p=0;k<Nal[j];++k){
                p += fitcalc(j,Val[j][i],Val[j][k])*
                    Freq[j][i]*Freq[j][k];
            }
            p /= Mfit[j];
            props[i] = p;
        }
        for(i=0;i<Nal[j]-1;++i){
            p = props[i];
            if(1.0-done <= 0.0 || 1.0-done > 1){
                printerr("sample: done wrong");
            }
            Freq[j][i] = bnldev(p/(1.0-done),rest);
            if(Freq[j][i] < 0)printerr("sample: Freq[j][i] < 0 ");
            rest = rest - Freq[j][i];
            done += p;
        }
        if(rest < 0 || rest > Popsize[j])printerr("sample: rest wrong");
        Freq[j][i] = rest;
        /* move to point where we are guaranteed that last allelic class
           is guaranteed to have frequency > 0 */
        for(i=Nal[j]-1;i >= 0;--i){
            if(Freq[j][i] == 0)--Nal[j];
            else break;
        }
        for(i=0;i<Nal[j];++i){ /* 10000 just arbitrary upper in case of bug */
            if(Freq[j][i] == 0){
                Freq[j][i] = Freq[j][Nal[j]-1];
                Val[j][i] = Val[j][Nal[j]-1];
                --Nal[j];
                /* move to point where we are guaranteed that last allelic class
                is guaranteed to have frequency > 0 */
                for(k=Nal[j]-1;k >= 0;--k){
                    if(Freq[j][k] == 0)--Nal[j];
                    else break;
                }
           }
        }
        if(Checkit){
            for(i=0;i<Nal[j];++i)
                if(Freq[j][i] <= 0)printerr("sample: Freq <= 0 (2)");
        }
    }
}

void migrate()
{
	int j,k,nmig,ic,all_class,imm_pop,ic2,all_class_imm,il;
	struct type_val new_val;
    for(j=0;j<Npop;++j){
        nmig = poidev(Mig_rate[j]*Popsize[j]);
        for(k=0;k<nmig;++k){
            ic = disrand(0,Popsize[j]-1);
            all_class = get_allclass(Freq[j],ic,Nal[j]);
            imm_pop = choose_pop(j); /* implies global migration matrix or other details */
            ic2 = disrand(0,Popsize[imm_pop]-1);
            all_class_imm = get_allclass(Freq[imm_pop],ic2,Nal[imm_pop]);
            new_val = Val[imm_pop][all_class_imm]; /* assignment of structure! */
            il = lookup(&new_val,Val[j],Nal[j]);
            if(il == Nal[j]){
                Freq[j][il] = 1;
                setval(&(Val[j][il]),&new_val);
                ++Nal[j];
            }
            else{
                ++Freq[j][il];
            }
            --Freq[j][all_class];
            if(Freq[j][all_class] < 0)printerr("migrate: freq < 0 (1)");
            if(Freq[j][all_class] == 0){
                if(all_class == Nal[j]-1)--Nal[j];
                else{
                    Freq[j][all_class] = Freq[j][Nal[j]-1];
                    Val[j][all_class] = Val[j][Nal[j]-1];
                    --Nal[j];
                }
            }
        }
    }

}

int lookup(struct type_val *v1,struct type_val val[],int len)
{
	int j;
	for(j = 0;j<len;++j){
		if(v1->m == val[j].m && v1->s == val[j].s)break;
	}
	return j;
}


int get_allclass(int vec[],int ic,int n)
{
	int j,sum=0;
	for(j=0;j<n;++j){
		sum += vec[j];
		if(ic <= sum) return j;
	}
	printerr("get_allclass: fallen through loop");
}

void setval(struct type_val *v1,struct type_val *v2)
{

	v1->m = v2->m;
	v1->s = v2->s;
}



int choose_pop(int ic)
{
	/* this is the simplest scenario - island model. But could
	have something more complicated - migration matrix */
	int ip;
	while(1){
		ip = disrand(0,Npop-1);
		if(ip != ic)return ip;
	}
}



void mutate_marker(struct type_val *old_val, struct type_val *new_val)
{
	/* carry on with simple infinite allele model for time being */
	double rr;
	new_val->m = Nextmutval++;
    if(!Marker_is_selected){
        new_val->s = old_val->s;
        return;
    }
	if(Ltype_current == 0)rr = 0;
	else rr = gfsr4();
	if(rr <= P_neut)new_val->s = 0;
	else if (rr <= P_neut+P_red) new_val->s = 1;
	else new_val->s = 2;
}



void mutate_selec(struct type_val *old_val, struct type_val *new_val)
{
/* this subroutine keeps the marker allele unchanged. It chooses a mutation
type for the selected allele according to the probability of it being neutral,
red, or blue, if it is a purifying selection locus, or the probability of it
being neutral or overdominant type a or overdominant type b, if it is an
overdominant locus */
	double rr;

	new_val->m = old_val->m;
	if(Ltype_current == 0)rr = 0;
    else rr = gfsr4();
	if(rr <= P_neut)new_val->s = 0;
	else if (rr <= P_neut+P_red) new_val->s = 1;
	else new_val->s = 2;
}




void mutate()
{
	int j,nmut_marker,nmut_selec,k,i,il,all_class,ic;
    struct type_val new_val;
    for(j=0;j<Npop;++j){
        nmut_marker = poidev(Mu_marker*Popsize[j]);
        if(Ltype_current == 0 || Marker_is_selected)nmut_selec = 0; /* neutral locus */
        else nmut_selec = poidev(Mu_selec*Popsize[j]);
        for(k=0;k<nmut_marker;++k){
            ic = disrand(0,Popsize[j]-1);
            all_class = get_allclass(Freq[j],ic,Nal[j]);
            mutate_marker(&(Val[j][all_class]),&new_val); /* Val[j] is a vector of type structure with a marker and selected component
                                                        new_val is a structure with a marker and selected component */
            il = lookup(&new_val,Val[j],Nal[j]);
            if(il == Nal[j]){
                Freq[j][il] = 1;
                setval(&(Val[j][il]),&new_val);
                ++Nal[j];
            }
            else{
                ++Freq[j][il];
            }
            --Freq[j][all_class];
            if(Freq[j][all_class] < 0)printerr("mutate: freq < 0 (1)");
            if(Freq[j][all_class] == 0){
                if(all_class == Nal[j]-1)--Nal[j];
                else{
                    Freq[j][all_class] = Freq[j][Nal[j]-1];
                    Val[j][all_class] = Val[j][Nal[j]-1];
                    --Nal[j];
                }
            }
        }
        for(k=0;k<nmut_selec;++k){
            ic = disrand(0,Popsize[j]-1);
            all_class = get_allclass(Freq[j],ic,Nal[j]);
            mutate_selec(&(Val[j][all_class]),&new_val); /* Val[j] is a vector of type structure with a marker and selected component
                                                        new_val is a structure with a marker and selected component */
            il = lookup(&new_val,Val[j],Nal[j]);
            if(il == Nal[j]){
                Freq[j][il] = 1;
                setval(&(Val[j][il]),&new_val);
                ++Nal[j];
            }
            else{
                ++Freq[j][il];
            }
            --Freq[j][all_class];
            if(Freq[j][all_class] < 0)printerr("mutate: freq < 0 (2)");
            if(Freq[j][all_class] == 0){
                if(all_class == Nal[j]-1)--Nal[j];
                else{
                    Freq[j][all_class] = Freq[j][Nal[j]-1];
                    Val[j][all_class] = Val[j][Nal[j]-1];
                    --Nal[j];
                }
            }
        }
    }
}



double betasim(double a[])
{
    double x1,x2;
    x1 = rgamma(a[0],1.0);
    x2 = rgamma(a[1],1.0);
    return x1/(x1+x2);
}


