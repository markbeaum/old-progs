#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#ifdef __BORLANDC__
        #include <float.h>
#endif
#include "myutil.h"

#define DO_LIK_BITTY 1.0e-6
#define MAXIT 200

void pargen2(double scale, double vec[], int n, double oldvec[], double *ftp,
double *rtp);
double rblock(double x,double win,int imin,int imax, double xmin,
    double xmax,double *tpf,double *tpr);
double seq2(double tn,int ntot,int ns,int gen[],int *nout,int *izero);
void read_data(int ****freq,int **noall,int *nloc,int *pops,int
***sums);
void read_state(char *name,int nloc,int pops,int *noall,double ***afreq,double
    ***new_afreq,double **tn,double **new_tn,int *succ,int *iter,
    int *itmax,double *lik,int *indic);
void write_state(char *name,int nloc,int pops,int *noall,double **afreq,double *tn,int
    succ,int iter,int itmax,double lik,int indic);
void printstuff(FILE *freqout,FILE *timeout,int iter,double lik,double
    *tn,double **afreq,int pops,int *noall,int nloc,int indic, double probdrift);
void accept(double *lik,double newlik,double **tn,double
    **new_tn,double ***afreq,double ***new_afreq);
double lmulti(int n,int *gen,int noall,double *parf);
void pargen(double scale, double vec[], int n, double oldvec[], double *ftp,
    double *rtp);
double ldiri(int n, double par[], double vec[]);
void twiddle(int nloc,int pops,double *tn,double *new_tn,int *noall,double
**afreq,double **new_afreq,double *return_ftrans,double *return_rtrans);
void lik_cal(int indic,double *tn,double **afreq,int pops,int *noall,int
**sums,int nloc,int ***freq,double *newlik);
double do_lik(double tn,double *afreq,int noall,int sum,int *freq);
double pc(int sum,int nc,double t);
double f1(int n,int m,double t);
double ancprob(int m,int n,double *afreq,int noall,int *freq);
void newvec(int *freq,int *tvec,int *pos,int noall,int *nc,int
*indic);
void fill_vec(int *pos,int len,int nc,int *vec,int *ref_vec,int
*indic);
double lgfunc(double a, double b, double x);
double do_lik_sim(double tn,double *afreq,int noall,int sum,int *freq);
double seq(double tn,int ntot,int ns,int gen[],int *nout,int *izero);
double do_mdlik(double f,double *afreq,int noall,int sum,int *freq);

int Illegal,Liktoosmall;

FILE *tout;

main()
{

    int ***freq,*noall,nloc,pops,**sums,iter,itmax,succ,indic,newindic;
    int j,k,i;
    double **afreq,*tn,**new_afreq,*new_tn,
                ftrans,rtrans,t_ftrans,t_rtrans,pval,lik,newlik;
    FILE *timeout,*freqout; 
    int testsum,testnc;
    double test_t,den;
    double keeplik,drift_lik,md_lik,probdrift;

 #ifdef __BORLANDC__

        _control87(MCW_EM,MCW_EM);
  #endif
        

    opengfsr();
    
    tout = fopen("test.out","w");
    
    read_data(&freq,&noall,&nloc,&pops,&sums);
    read_state("STATE",nloc,pops,noall,&afreq,&new_afreq,&tn,&new_tn,&succ,&iter,
            &itmax,&lik,&indic);
    
    if(iter == 0){
        for(i=0;i<nloc;++i){
            den = 0.0;
            for(j=0;j<noall[i];++j)afreq[i][j] = 0;
            for(k=0;k<pops;++k){
                for(j=0;j<noall[i];++j){
                    afreq[i][j] += (freq[i][k][j] + 1.0);
                }
                den += sums[i][k] + noall[i];
            }
            for(j=0;j<noall[i];++j){
                afreq[i][j] /= den;
            }
            
        }
        timeout = fopen("mh_tn.dat","w");
        freqout = fopen("mh_freqs.dat","w");
        indic = disrand(0,1); 
    /*  indic = 0; */
        if(indic == 0)lik_cal(0,tn,afreq,pops,noall,sums,nloc,freq,&lik);
        else lik_cal(1,tn,afreq,pops,noall,sums,nloc,freq,&lik); 
    }
    else{
        timeout = fopen("mh_tn.dat","a");
        freqout = fopen("mh_freqs.dat","a");
    }
        
    for(;iter<itmax;++iter){
        newindic = disrand(0,1); 
    /*  newindic = 0; */
        twiddle(nloc,pops,tn,new_tn,noall,afreq,new_afreq,&ftrans,&rtrans);
        if(newindic == 0){ /* drift model */
            lik_cal(0,new_tn,new_afreq,pops,noall,sums,nloc,freq,&newlik);
        }
        else{ /* md model */
            lik_cal(1,new_tn,new_afreq,pops,noall,sums,nloc,freq,&newlik); 
        }
            
        pval = newlik+rtrans-lik-ftrans;
        if(Illegal){
            fprintf(tout," %d Illegal %d\n",
                    iter+1,Illegal);
            fflush(tout);
            pval = -100.0;
        }
        if(pval >= 0 || (pval > -15.0 && gfsr4() < exp(pval))){
            accept(&lik,newlik,&tn,&new_tn,&afreq,&new_afreq);
            indic = newindic;
            ++succ;
        }
    //  probdrift = newindic ? exp(newlik)/(exp(newlik)+exp(
    //  if((iter+1)%100 == 0)printf("iteration %d\n",iter+1);
        if((iter+1)%5 == 0){
            if(indic == 0){
                drift_lik = lik;
                lik_cal(1,tn,afreq,pops,noall,sums,nloc,freq,&md_lik);
            }
            else{
                md_lik = lik;
                lik_cal(0,tn,afreq,pops,noall,sums,nloc,freq,&drift_lik);
            }
            probdrift = 1.0/(1.0+exp(md_lik-drift_lik));

            printstuff(freqout,timeout,iter+1,lik,tn,afreq,pops,noall,nloc,indic,probdrift);
        }
        if((iter+1)%5 == 0){
            write_state("STATE",nloc,pops,noall,afreq,tn,succ,iter+1,itmax,lik,indic);
            closegfsr();
            fflush(freqout);
            fflush(timeout);
            fflush(tout);
        }
            
    }
    closegfsr();
}

void twiddle(int nloc,int pops,double *tn,double *new_tn,int *noall,double
**afreq,double **new_afreq,double *return_ftrans,double *return_rtrans)
{
    static double Scale1 = 1000.0,Scale2 = 5000.0,Escale=0.5;
    int j,ip,k,changetn;
    double rtrans,ftrans,scale,dd;
    static double tvec1[2],tvec2[2];
    
    Illegal = 0; 
    rtrans = ftrans = 0.0;
    changetn = disrand(1,2);
    for(j=0;j<nloc;++j){
        for(k=0;k<noall[j];++k){
            new_afreq[j][k] = afreq[j][k];
        /*  if(changetn == 0)new_afreq[j][k] = afreq[j][k]; 
            else pargen(Scale1,new_afreq[j],noall[j],afreq[j],&ftrans,&rtrans);*/
        }
    }
    j = disrand(0,nloc-1);
    pargen(Scale1,new_afreq[j],noall[j],afreq[j],&ftrans,&rtrans); 
    for(j=0;j<pops;++j){
        tvec1[0] = tn[j];
        tvec1[1] = 1.0 - tn[j];
        if(changetn!=2)pargen(Scale2,tvec2,2,tvec1,&ftrans,&rtrans);
        else tvec2[0] = tvec1[0]; 
        new_tn[j] = tvec2[0]; 
    }
    *return_ftrans = ftrans;
    *return_rtrans = rtrans;
    return;
}



double lgfunc(double a, double b, double x)
{
    return (a-1.0)*log(x/b) - x/b - lgamma(a) - log(b);
}

void pargen(double scale, double vec[], int n, double oldvec[], double *ftp,
double *rtp)
{
    static double fpar[100],rpar[100],tvec[100];
    int j,flip;
    double cum,sumd;

    sumd = 0.0;
    for(j=0,flip=0;j<n;++j){
        tvec[j] = oldvec[j];
        if(tvec[j] < 1.0e-5){
            flip = 1;
            tvec[j] = 1.0e-5;
            sumd += oldvec[j] - tvec[j];
        }
    }
    if(flip)for(j=0;j<n;++j)tvec[j] /= 1.0 + sumd;
        
    for(j=0;j<n;++j){
        fpar[j] =  scale*tvec[j];
    }
    for(j=0,cum=0.0;j<n;++j){
        vec[j] = rgamma(fpar[j],1.0);
        if(vec[j] == 0.0){
            for(j=0;j<n;++j)vec[j] = oldvec[j];
            Illegal = 1;
            return;
        }
        cum += vec[j];
    }
    for(j=0;j<n;++j){
        vec[j] /= cum;
    }
    
    sumd = 0.0;
    for(j=0,flip=0;j<n;++j){
        tvec[j] = vec[j];
        if(tvec[j] < 1.0e-5){
            flip = 1;
            tvec[j] = 1.0e-5;
            sumd += vec[j] - tvec[j];
        }
    }
    if(flip)for(j=0;j<n;++j)tvec[j] /= 1.0 + sumd;
        
    for(j=0;j<n;++j){
        rpar[j] = scale*tvec[j];
    }
    *ftp += ldiri(n,fpar,vec);
    *rtp += ldiri(n,rpar,oldvec);
    return;
}


void pargen2(double scale, double vec[], int n, double oldvec[], double *ftp,
double *rtp)
{
    static double fpar[2],rpar[2],oldveca[2],veca[2];
    int j,ic;
    double cum,oldelem,sum;
    
    ic = disrand(0,n-1);
    oldelem = 1.0 - oldvec[ic];
    
    fpar[1] = 0.0;
    oldveca[1] = 0.0;
    for(j=0;j<n;++j){
        if(j==ic){
            fpar[0] =  oldvec[j];
            oldveca[0] = oldvec[j];
        }
        else{ 
            fpar[1] += oldvec[j];
            oldveca[1] += oldvec[j];
        }
    }
    if(fpar[0] < fpar[1])scale = 1.0/fpar[0];
    else scale = 1.0/fpar[1];
    fpar[0] *= scale;
    fpar[1] *= scale;
    for(j=0,cum=0.0;j<2;++j){
        if(fpar[j] <= 0.0)printerr("probs with fpar");
        veca[j] = rgamma(fpar[j],1.0);
        if(veca[j] <= 0.0)printerr("probs with fpar");
        cum += veca[j];
    }
    for(j=0;j<2;++j){
        veca[j] /= cum;
    }
    if(veca[0] < veca[1])scale = 1.0/veca[0];
    else scale = 1.0/veca[1];
    for(j=0;j<2;++j){
        rpar[j] = scale*veca[j];
    }
    *ftp += ldiri(2,fpar,veca);
    *rtp += ldiri(2,rpar,oldveca);
    sum = 0.0;
    for(j=0;j<n;++j){
        if(j==ic)vec[j] = veca[0];
        else vec[j] = oldvec[j]/oldelem*veca[1];
        if(vec[j] <= 0.0)Illegal = 1;
        sum += vec[j];
    }
    for(j=0;j<n;++j)vec[j] /= sum;
    return;
}


void lik_cal(int indic,double *tn,double **afreq,int pops,int *noall,int
**sums,int nloc,int ***freq,double *newlik)
{
    double lik;
    int j,k;
    
    Liktoosmall = 0;
    lik = 0.0;
    for(j=0;j<nloc;++j){
        for(k=0;k<pops;++k){
            if(indic==0){
                lik += do_lik_sim(tn[k],afreq[j],noall[j],sums[j][k],freq[j][k]);
                if(Liktoosmall){
                    *newlik = -1.0e9; /* trap problem cases */
                    return;
                }
            }
            else{
                lik += do_mdlik(tn[k],afreq[j],noall[j],sums[j][k],freq[j][k]);
            }
        }
    }
    *newlik = lik;
}


double do_mdlik(double f,double *afreq,int noall,int sum,int *freq)
{
    double psum,psum2,cof,a,mig;
    int j;
    if(sum == 0)return 0.0;
    mig = (1-f)/f;
    if(mig > 1.0e5){
        return lmulti(sum,freq,noall,afreq);
    }
    psum = lgamma((1-f)/f);
    for(j=0,cof=0.0;j<noall;++j){
        cof += lgamma(freq[j]+1.0);
        a = afreq[j]*(1-f)/f;
        psum += lgamma(freq[j]+a) - lgamma(a);
    }
    cof = lgamma(sum+1.0) - cof;
    psum += cof - lgamma(sum+(1-f)/f);
/*  psum2 = lmulti(sum,freq,noall,afreq);
    fprintf(tout,"%f %f %f\n",(1-f)/f,psum,psum2); */
    return psum;
}



double do_lik(double tn,double *afreq,int noall,int sum,int *freq)
{
    double p1,p2,pv,psum;
    int j;
    if(sum == 0)return 0.0;
    psum = 0.0;
    for(j=0;j<sum;++j){
        p1 = pc(sum,j,tn); /* this is probability */
        p2 = ancprob(j,sum,afreq,noall,freq); /* this is probability */
        pv = p1 * p2;
        psum += pv;
        if(pv < DO_LIK_BITTY*psum)break; 
    }
    return log(psum);
}


double ancprob(int m,int n,double *afreq,int noall,int *freq)
{
    int tvec[1000],j,pos,nc,indic;
    double konst,pt,pm,prod1,ptot;
    for(j=0;j<noall;++j){
        tvec[j] = freq[j];
    }
    konst = lfactl(m) + lfactl(n-m-1) - lfactl(n-1);
    for(j=0;j<noall;++j){
        if(freq[j] > 0)konst += lfactl(freq[j]-1);
    }
    pt = 0.0;
    nc = m;
    pos = 0;
    while(1){
        newvec(freq,tvec,&pos,noall,&nc,&indic);
        if(indic==1)continue;
        if(indic==2)break;
        
        pm = lmulti(n-m,tvec,noall,afreq);
        prod1 = konst;
        for(j=0;j<noall;++j){
            if(freq[j] > 0)
                prod1 -= lfactl(freq[j]-tvec[j]) + lfactl(tvec[j]-1);
        }
        pt += exp(pm + prod1);
    }
    return pt;
}   
        


void newvec(int *freq,int *tvec,int *pos,int noall,int *nc,int *indic)
{
    int j;
    *indic = 0;
    if(*nc == 0){
        if(*pos == 0){
            ++(*pos);
            return;
        }
        else{
            *indic = 2;
            return;
        }
    }
    if(*pos == noall){
        *nc = freq[*pos-1] - tvec[*pos-1]+1;
        tvec[*pos-1] = freq[*pos-1];
        *pos -= 2;
        for(;*pos>= 0 && tvec[*pos] == freq[*pos];--(*pos));
        if(*pos < 0){*indic = 2;return;}
        ++tvec[*pos];
        ++(*pos);
        fill_vec(pos,noall,*nc,tvec,freq,indic);
        if(*indic){
            tvec[noall-1] -= *nc;
            *pos = noall;
            return;
        }
    }
    else if(*pos > 0){
        *nc = 1;
        ++tvec[*pos-1];
        fill_vec(pos,noall,*nc,tvec,freq,indic);
        if(*indic){
            --tvec[*pos-1];
            tvec[noall-1] -= freq[*pos-1] - tvec[*pos-1];
            tvec[*pos-1] = freq[*pos-1];
            *pos = noall;
            return;
        }
    }
    else if (*pos == 0){
        fill_vec(pos,noall,*nc,tvec,freq,indic);
        if(*indic){
            *indic = 2;
            return;
        }
    }
}


void fill_vec(int *pos,int len,int nc,int *vec,int *ref_vec,int *indic)
{
    int j,ifill,temp_vec[1000],k;
    for(j=*pos;j<len;++j){
        temp_vec[j] = ref_vec[j];
        if((ifill = ref_vec[j] - 1) > 0){
            if(nc > ifill){
                nc -= ifill;
                temp_vec[j] = temp_vec[j] - ifill;
            }
            else{
                temp_vec[j] = temp_vec[j] - nc;
                for(k=*pos;k<=j;++k)vec[k] = temp_vec[k];
                *pos = j+1;
                return;
            }
        }
    }
    *indic = 1;
}
        


double pc(int sum,int nc,double t)
{
    static double oldf;
    double val;
    if(nc == 0){
        oldf = f1(sum,1,t);
        val = 1.0 - oldf;
        return val; 
    /*  return 1.0 - f1(sum,1,t);*/
    }
    else if(nc+1 == sum){
        return oldf; 
    /*  return f1(sum,nc,t);*/
    }
    else{
        val = oldf;
        oldf = f1(sum,nc+1,t);
        val = val - oldf;
        return  val;
    /*  return f1(sum,nc,t) - f1(sum,nc+1,t);  */
    }
}

double f1(int n,int m,double t)
{
    double t1,t2,prod,sum;
    int isig,i,j;
    
    sum = 0.0;
    if(m%2 == 1)isig = -1;
    else isig = 1;
    for(i=1;i<=m;++i){
        prod = 1.0;
        t2 = (n-i)*(n-i+1);
        for(j=1;j<=m;++j){
            if(j != i){
                t1 = (n-j)*(n-j+1);
                prod *= t1/(t2-t1);
            }
        }
        prod *= exp(-0.5*t2*t);
        sum += prod;
    }
    return 1 + isig * sum;
}
                
        
        
double ldiri(int n, double par[], double vec[])
{
    double sum;
    double konst;
    int j;
    sum = 0.0;
    konst = 0.0;
    for(j=0;j<n;++j){
        sum += (par[j]-1.0)*log(vec[j]);
        sum -= lgamma(par[j]);
        konst += par[j];
    }
    return sum + lgamma(konst);
}

double lmulti(int n,int *gen,int noall,double *parf)
{
    double tt;
    int j,icheck;
    tt = lgamma(n+1.0);
    for(j=0;j<noall;++j){
        if(parf[j] <= 0.0){
            if(gen[j] == 0)continue;
            else return -1000.0;
        }
        tt += gen[j]*log(parf[j]) - lgamma(gen[j]+1.0);
    }
    return tt;
}



void accept(double *lik,double newlik,double **tn,double
    **new_tn,double ***afreq,double ***new_afreq)
{
    double *tn_temp,**afreq_temp;
    tn_temp = *tn;
    *tn = *new_tn;
    *new_tn = tn_temp;
    
    afreq_temp = *afreq;
    *afreq = *new_afreq;
    *new_afreq = afreq_temp;
    
    *lik = newlik;
    
    return;
}
    
    



void printstuff(FILE *freqout,FILE *timeout,int iter,double lik,double
*tn,double **afreq,int pops,int *noall,int nloc,int indic, double probdrift)
{
    int j,k;
    fprintf(timeout,"%d ",iter);
    fprintf(timeout,"%f ",lik);
    fprintf(timeout,"%d ",indic);
    fprintf(timeout,"%f ",probdrift);
    for(j=0;j<pops;++j){
        fprintf(timeout,"%f ",tn[j]);
    }
    fprintf(timeout,"\n");
    
    fprintf(freqout,"%d  ",iter);
    for(j=0;j<nloc;++j){ 
        for(k=0;k<noall[j];++k){
            fprintf(freqout,"%f ",afreq[j][k]);
        }
    } 
    fprintf(freqout,"\n"); 
    
}

void read_state(char *name,int nloc,int pops,int *noall,double ***afreq,double
***new_afreq,double **tn,double **new_tn,int *succ,int *iter,int *itmax,double
*lik,int *indic)
{
    FILE *stf;
    int ic,k,j;
    stf = fopen(name,"r");
    if(stf == 0)printerr("error reading stf 1 - file not found");
    ic = fscanf(stf,"%d %d %d %lf %d",succ,iter,itmax,lik,indic);
    if(ic <= 4 || ic == EOF)printerr("error reading stf 2 (too short?)");
    (*afreq) = (double **)malloc(nloc*sizeof(double *));
    (*new_afreq) = (double **)malloc(nloc*sizeof(double *));
    for(j=0;j<nloc;++j){
        (*afreq)[j] = (double *)malloc(noall[j]*sizeof(double));
        (*new_afreq)[j] = (double *)malloc(noall[j]*sizeof(double));
        if(*iter == 0)continue;
        for(k=0;k<noall[j];++k){
            ic = fscanf(stf,"%le",&(*afreq)[j][k]);
            if(ic <= 0 || ic == EOF)printerr("error reading stf 3 (too short?)");
        }
    }
    (*tn) = (double *)malloc(pops*sizeof(double));
    (*new_tn) = (double *)malloc(pops*sizeof(double));
    if(*iter == 0){
        for(j=0;j<pops;++j)(*tn)[j] = gfsr4()*0.1;
        return;
    }
    for(j=0;j<pops;++j){
        ic = fscanf(stf,"%lf",&(*tn)[j]);
        if(ic <= 0 || ic == EOF)printerr("error reading stf 4 (too short?)");
    }
    ic = fscanf(stf,"%d",&j);
    if(ic != EOF)printerr("error reading stf 5 - too long");
    fclose(stf);
    return;
}
void write_state(char *name,int nloc,int pops,int *noall,double **afreq,double *tn,int
succ,int iter,int itmax,double lik,int indic)
{
    FILE *stf;
    int k,j;
    stf = fopen(name,"w");
    fprintf(stf,"%d %d %d %f %d\n",succ,iter,itmax,lik,indic);
    for(j=0;j<nloc;++j){
        for(k=0;k<noall[j];++k){
            fprintf(stf,"%e ",afreq[j][k]);
        }
        fprintf(stf,"\n");
    }
    for(j=0;j<pops;++j){
        fprintf(stf,"%f ",tn[j]);
    }
    fclose(stf);
    return;
}

void read_data(int ****freq,int **noall,int *nloc,int *pops,int ***sums)
{
    FILE *inp;  
    int byall,j,k,l,ic,i;
    char c;
    
    inp = fopen("infile","r");
    if(inp == 0){
        printf("no infile\n");
        exit(1);
    }
    fscanf(inp,"%d",&byall); /* 1 is by allele 0 is by population */
    while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
    fscanf(inp,"%d",pops);
    while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
    fscanf(inp,"%d",nloc);
    while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
    
    (*noall) = (int *)malloc((*nloc)*sizeof(int));
    (*sums) = (int **)malloc((*nloc)*sizeof(int *));
    (*freq) = (int ***)malloc((*nloc)*sizeof(int **));
    for(j=0;j<(*nloc);++j)(*freq)[j] = (int **)malloc((*pops)*sizeof(int *));
    for(j=0;j<(*nloc);++j)(*sums)[j] = (int *)malloc((*pops)*sizeof(int ));
    for(j=0;j<(*nloc);++j){
        fscanf(inp,"%d",&(*noall)[j]);
        while(!((c=getc(inp)) == '\n' || c == '\f' || c == '\r'));
        for(k=0;k<(*pops);++k)(*freq)[j][k] = (int
            *)malloc((*noall)[j]*sizeof(int));
        if(byall){
            for(k=0;k<(*noall)[j];++k){
                for(l=0;l<(*pops);++l){
                    ic = fscanf(inp,"%d",&(*freq)[j][l][k]);
                    if(ic <= 0 || ic == EOF){
                        printerr("error reading data");
                    }
                }
            }
        }
        else{
            for(k=0;k<(*pops);++k){
                for(l=0;l<(*noall)[j];++l){
                    ic = fscanf(inp,"%d",&(*freq)[j][k][l]);
                    if(ic <= 0 || ic == EOF){
                        printerr("error reading data");
                    }
                }
            }
        }
        for(k=0;k<(*pops);++k){
            (*sums)[j][k] = 0;
            for(i=0;i<(*noall)[j];++i){
                (*sums)[j][k] += (*freq)[j][k][i];
            }
        }
    }
    fclose(inp);
    return;
}

/*
------------------------------------------------------------------------------------
do_lik_sim and its helper function seq can be used in place of do_lik and
its helper functions to _simulate_ the likelihoods. These are now obsolete for 
the simple drift model, but may have to be used for population trees. I also
used these to check that the analytical and simulated likelihoods were the
same within sampling error */


double do_lik_sim(double tn,double *afreq,int noall,int sum,int *freq)
{
    int i,j,nout1,izero;
    double esum,prob1;
    static int tgen[100];

    tn = -log(1.0-tn);
    esum = 0.0;
    for(i=0;i<MAXIT;++i){
    
        for(j=0;j<noall;++j)tgen[j] = freq[j];
        prob1 = seq2(tn,sum,noall,tgen,&nout1,&izero);
        if(izero)continue;
        prob1 += lmulti(nout1,tgen,noall,afreq);
        
        esum += exp(prob1);
    }
    if(esum == 0.0)Liktoosmall = 1; /* This can happen when T/N is big
                                  so that highly improbable to get 
                                  this configuration - you'd get 
                                  monomorphic loci */
    esum /= MAXIT; /* estimate of probability */
    if(esum > 0.0)esum = log(esum);
    else esum = -1.0e9; /* set it to some miniscule value */
    return esum;
}

double seq(double tn,int ntot,int ns,int gen[],int *nout,int *izero)
{
    double lfunc,lfunc1,lfunc2,gams,w1,konst,tprob;
    double rt,ct,ctcum,sum;
    float colrate,mutrate,rni,rr;
    int ni,ip,j,k,nmut,ncol,icheck,ix[100],nvec,niter;
    ni = ntot;
    *izero = 0;
    nvec = 0;
    for(j=0;j<ns;++j){
        if(gen[j] != 0)++nvec;
    }
    if(ni < nvec)printerr("seq2: ni < nvec");
    isorti('d',ns,gen,ix);
    niter = 0;
    ctcum = 0.0;
    while(1){
        colrate = (ni*(ni-1)*0.5);/* This is the coalescence rate for
        constant population */
        ct = expdev()/colrate; /* coalescence time */
        ctcum += ct;
        if(ctcum >= tn)break;/*  stop and calculate multinomial probs */
        if(ni == nvec){
            *izero = 1;
            return 0.0;
        }
        ip = disrand(1,ni-nvec);
        sum = 0;
        for(j=0;j<nvec;++j){ /* this should ignore the zero ones at the end */
            sum += gen[ix[j]]-1;
            if(sum >= ip)break;
        }
        if(j==nvec)printerr("seq2: fallen through loop");
        --gen[ix[j]];
        if(gen[ix[j]] == 0)printerr("seq2: vec[j] == 0");
        if(j < ns-1 && gen[ix[j]] < gen[ix[j+1]])isorti('d',ns,gen,ix);
        --ni;
        ++niter;
    }
    lfunc1 = 1.0;
    lfunc2 = 1.0;
    if(niter >= nvec){
        for(j=niter+2-nvec;j<=niter;++j)lfunc1 *= ntot-(nvec+j-1);
        for(j=1;j<=nvec-1;++j)lfunc2 *= ntot - j;
    }
    else{
        for(j=1;j<=niter;++j)lfunc1 *= ntot - (nvec+j) + 1;
        for(j=1;j<=niter;++j)lfunc2 *= ntot-j;
    }
    lfunc = lfunc1/lfunc2;
        
    *nout = ni;
    return log(lfunc);
}

double seq2(double tn,int ntot,int ns,int gen[],int *nout,int *izero)
{
    double lfunc,lfunc1,lfunc2,gams,w1,konst,tprob;
    double rt,ct,ctcum;
    float colrate,mutrate,rni,rr;
    int ni,ip,j,k,nmut,ncol,icheck,nvec,niter,sum;
    static int ix[100],wspace[100];
    ni = ntot;
    *izero = 0;
    nvec = 0;
    for(j=0;j<ns;++j){
        if(gen[j] != 0)++nvec;
    }
    if(ni < nvec)printerr("seq2: ni < nvec");
    isorti2('d',ns,gen,wspace,ix);
    niter = 0;
    ctcum = 0.0;
    while(1){
        colrate = (ni*(ni-1)*0.5);/* This is the coalescence rate for
        constant population */
        ct = expdev()/colrate; /* coalescence time */
        ctcum += ct;
        if(ctcum >= tn)break;/*  stop and calculate multinomial probs */
        if(ni == nvec){
            *izero = 1;
            return 0.0;
        }
        ip = disrand(1,ni-nvec);
        sum = 0;
        for(j=0;j<nvec;++j){ /* this should ignore the zero ones at the end */
            sum += gen[ix[j]]-1;
            if(sum >= ip)break;
        }
        if(j==nvec)printerr("seq2: fallen through loop");
        --gen[ix[j]];
        if(gen[ix[j]] == 0)printerr("seq2: vec[j] == 0");
        if(j < ns-1 && gen[ix[j]] < gen[ix[j+1]])isorti2('d',ns,gen,wspace,ix);
        --ni;
        ++niter;
    }
    lfunc1 = 1.0;
    lfunc2 = 1.0;
    if(niter >= nvec){
        for(j=niter+2-nvec;j<=niter;++j)lfunc1 *= ntot-(nvec+j-1);
        for(j=1;j<=nvec-1;++j)lfunc2 *= ntot - j;
    }
    else{
        for(j=1;j<=niter;++j)lfunc1 *= ntot - (nvec+j) + 1;
        for(j=1;j<=niter;++j)lfunc2 *= ntot-j;
    }
    lfunc = lfunc1/lfunc2;
        
    *nout = ni;
    return log(lfunc);
}
            
/*
------------------------------------------------------------------------------------
*/

double rblock(double x,double win,int imin,int imax, double xmin,
    double xmax,double *tpf,double *tpr)
{
    double newx;
    if(!imin && !imax){ /* unlimited x */
        newx = x-win+gfsr4()*(2.0*win);
        *tpf = *tpr = -log(2.0*win);
    }
    else if(imin && !imax){ /* lower limit */
        if(x < xmin)printerr("rblock: x < xmin");
        if(x-win < xmin){
            newx = xmin + gfsr4()*(x-xmin + win);
            *tpf = -log(x-xmin + win);
        }
        else{
            newx = x-win + gfsr4()*(2*win);
            *tpf = -log(2.0*win);
        }
        if(newx-win < xmin){
            *tpr = -log(newx-xmin + win);
        }
        else *tpr = -log(2.0*win);
    }
    
    else if(!imin && imax){ /* upper limit */
        if(x > xmax)printerr("rblock: x < xmin");
        if(x+win > xmax){
            newx = x-win + gfsr4()*(win + xmax - x);
            *tpf = -log(win + xmax-x);
        }
        else{
            newx = x-win + gfsr4()*(2*win);
            *tpf = -log(2.0*win);
        }
        if(newx + win > xmax){
            *tpr = -log(win + xmax-newx);
        }
        else{
            *tpr = -log(2.0 * win);
        }
    }
    else if(imin && imax){ /* lower and upper limit */
        if(x < xmin || x > xmax )printerr("rblock: x out of bounds");
        if(2.0*win > xmax-xmin)
            printerr("rblock: win too large");
        if(x-win < xmin){
            newx = xmin + gfsr4()*(x-xmin + win);
            *tpf = -log(x-xmin + win);
        }
        else if(x+win > xmax){
            newx = x-win + gfsr4()*(win + xmax - x);
            *tpf = -log(win + xmax-x);
        }
        else{
            newx = x-win + gfsr4()*(2*win);
            *tpf = -log(2.0*win);
        }
        if(newx-win < xmin){
            *tpr = -log(newx-xmin + win);
        }
        if(newx + win > xmax){
            *tpr = -log(win + xmax-newx);
        }
        else *tpr = -log(2.0*win);
    }
    else printerr("rblock: weird?");
    return newx;
    
}
    
